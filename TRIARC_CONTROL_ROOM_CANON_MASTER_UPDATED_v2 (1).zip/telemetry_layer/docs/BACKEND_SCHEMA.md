# TriArc Control Room — Backend Schema (Supabase)

**Purpose:** Persist Nexus telemetry, compute/record Dynamic Authority Compression (Pathway + Load Authority), and provide an auditable feed for Fleet telemetry + Controller enforcement.

This schema is designed to support the TriArc vertical order:

**ENVIRONMENT → GOVERNANCE → LOAD → OPPORTUNITY → IDENTITY**

Commercial access (Stripe/Memberstack) is treated as **Access** only. Authority is governed by OSI + governance state.

---

## 1) Data Domains

### A) Identity & Access
- `operator_profiles`
  - `access_tier` = commercial ceiling (Academy / Infirmary / Gauntlet)
  - `active_pathway` = dynamic authority state (Academy / Infirmary / Gauntlet)
  - `osi_score` + `osi_band` = stability signal
  - `load_authority` = 0.5x / 1.0x / 2.0x (authority cap)
  - `current_state` = Reference / Aligned / Restricted / Caution / Critical

### B) Keys (Audit)
- `uplink_keys`
  - binds a human operator to a Nexus `uplink_key`
  - supports revocation, key-path validation, and forensics

### C) Telemetry
- `nexus_events`
  - raw envelope storage (for replay / debugging)
- `state_snapshots`
  - flattened, query-friendly dashboard feed extracted from `STATE_SNAPSHOT`

### D) Governance Outcomes
- `authority_events`
  - immutable audit trail whenever pathway/load/state changes

### E) Training & Audit
- `training_audit_events`
  - stores evidence used to compute OSI (Classifier accuracy, violations, compliance checks)

---

## 2) Authority Compression Rules (Baseline)

Compression respects **Access as ceiling**:

- **Academy access:** always `active_pathway = ACADEMY`, `load = 0.5x`
- **Infirmary access:** `INFIRMARY` when OSI ≥ 60, else compress to `ACADEMY`
- **Gauntlet access:**
  - OSI ≥ 80 → `GAUNTLET`
  - OSI 60–79 → `INFIRMARY`
  - OSI < 60 → `ACADEMY`

Load authority:
- `ACADEMY` → 0.5x
- `INFIRMARY` → 1.0x when OSI ≥ 70 else 0.5x
- `GAUNTLET` → 2.0x when OSI ≥ 85 else 1.0x

**Override:** `gov_state = CRITICAL` clamps load to **0.5x** (regardless of OSI).

These are implemented in:
- `supabase/migrations/010_authority_compression.sql`

---

## 3) Installation

1. Create a Supabase project.
2. Run migrations in order:
   - `000_init.sql`
   - `010_authority_compression.sql`

If using Supabase CLI:
- place these files in `supabase/migrations/` and run the CLI deploy.

---

## 4) Integration Notes

### Mapping uplink_key → user_id
The schema supports storing `user_id` on `state_snapshots`. How you set that depends on your stack:
- **Option A:** include user_id in the ingest function (server-side) after verifying the uplink_key.
- **Option B:** lookup `uplink_keys.uplink_key` and join to `user_id` during ingest.

### OSI updates
OSI should be computed from `training_audit_events` + controller overrides. Once updated, call:

- `triarc_apply_authority_compression(user_id, gov_state, osi, reason, evidence)`

to enforce the new pathway/load and to log the change in `authority_events`.

---

## 5) What this Enables

- Fleet dashboard = read `state_snapshots` (latest per operator)
- Operator dashboard = read own `operator_profiles` + latest snapshot
- Controller enforcement = investigate `authority_events` + `nexus_events` replay
- Dynamic Authority Compression = stable, auditable state machine
