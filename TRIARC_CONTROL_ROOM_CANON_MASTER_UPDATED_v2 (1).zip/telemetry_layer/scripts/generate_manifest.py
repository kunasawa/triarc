import hashlib, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

entries = []
for p in ROOT.rglob('*'):
    if p.is_dir():
        continue
    if p.name == 'MANIFEST.json':
        continue
    data = p.read_bytes()
    h = hashlib.sha256(data).hexdigest()
    entries.append({
        'path': str(p.relative_to(ROOT)).replace('\\','/'),
        'sha256': h,
        'bytes': len(data),
    })

manifest = {
    'schema': 'TRIARC_MANIFEST',
    'schema_version': '1.0',
    'root': str(ROOT.name),
    'file_count': len(entries),
    'files': sorted(entries, key=lambda x: x['path']),
}

out = ROOT / 'MANIFEST.json'
out.write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print('Wrote', out)
