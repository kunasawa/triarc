/**
 * pages.config.js — TriArc Sovereign Control Room routing
 *
 * This project intentionally uses a minimal navigation surface:
 * Portal, Weekly, Nexus, Pathway, Library, Governance.
 *
 * NOTE: Route keys become paths (e.g. key "weekly" => /weekly).
 */

import Portal from "./pages/portal";
import Landing from "./pages/landing";
import Permission from "./pages/permission";
import AccessRequest from "./pages/access_request";
import PublicDoctrine from "./pages/public_doctrine";
import PublicWhitepapers from "./pages/public_whitepapers";
import PublicWhitepaperView from "./pages/public_whitepaper_view";
import Onboarding from "./pages/onboarding";
import PathwayFilter from "./pages/pathway_filter";
import PathwayResult from "./pages/pathway_result";
import Academy from "./pages/academy";
import Infirmary from "./pages/infirmary";
import Gauntlet from "./pages/gauntlet";
import Weekly from "./pages/weekly";
import WeeklyArchive from "./pages/weekly_archive";
import Nexus from "./pages/nexus";
import Pathway from "./pages/pathway";
import Library from "./pages/library";
import Governance from "./pages/governance";
import GovernanceCompliance from "./pages/governance_compliance";
import GovernanceIntake from "./pages/governance_intake";
import GovernanceTrainingAudit from "./pages/governance_training_audit";
import GovernanceFleet from "./pages/governance_fleet";
import GovernanceStability from "./pages/governance_stability";
import GovernanceIncidents from "./pages/governance_incidents";
import GovernancePublishing from "./pages/governance_publishing";
import GovernanceAmendments from "./pages/governance_amendments";
import GovernanceRollout from "./pages/governance_rollout";
import Controller from "./pages/controller";
import Architecture from "./pages/architecture";
import NexusTelemetry from "./pages/nexus_telemetry";
import NexusAudit from "./pages/nexus_audit";
import GovernanceDataHardening from "./pages/governance_data_hardening.jsx";
import PortalBilling from "./pages/portal_billing.jsx";

export const PAGES = {
  // Public outreach (no auth required)
  landing: Landing,
  permission: Permission,
  "access-request": AccessRequest,
  "public/doctrine": PublicDoctrine,
  "public/whitepapers": PublicWhitepapers,
  "public/whitepapers/view": PublicWhitepaperView,

  "onboarding": Onboarding,
  "pathway/filter": PathwayFilter,
  "pathway/result": PathwayResult,

  // Pathway hubs (training spines)
  academy: Academy,
  infirmary: Infirmary,
  gauntlet: Gauntlet,

  portal: Portal,
  "portal/billing": PortalBilling,
  weekly: Weekly,
  "weekly/archive": WeeklyArchive,
  nexus: Nexus,
  "nexus/telemetry": NexusTelemetry,
  "nexus/audit": NexusAudit,
  pathway: Pathway,
  library: Library,
  governance: Governance,
  "governance/fleet": GovernanceFleet,
  "governance/stability": GovernanceStability,
  "governance/compliance": GovernanceCompliance,
  "governance/intake": GovernanceIntake,
  "governance/training-audit": GovernanceTrainingAudit,
  "governance/incidents": GovernanceIncidents,
  "governance/publishing": GovernancePublishing,
  "governance/rollout": GovernanceRollout,
  "governance/amendments": GovernanceAmendments,
  controller: Controller,
  architecture: Architecture,
};

export const pagesConfig = {
  // Main route is the public landing surface.
  mainPage: "landing",
  Pages: PAGES,
};