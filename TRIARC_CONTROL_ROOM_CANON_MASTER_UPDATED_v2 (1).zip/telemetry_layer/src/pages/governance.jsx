import React from "react";
import { Link } from "react-router-dom";
import RoleGate from "@/components/rbac/RoleGate";
import WeeklyPublisher from "@/components/governance/WeeklyPublisher";
import SentinelConsole from "@/components/governance/SentinelConsole";

export default function Governance() {
  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • GOVERNANCE SURFACE</div>
        <h1 className="mt-2 text-2xl font-semibold">Governance</h1>

        <RoleGate
          allow={["warden", "controller", "admin", "architect"]}
          fallback={
            <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-950 p-5 text-sm text-slate-300">
              Access restricted. This surface is reserved for governance roles.
            </div>
          }
        >
          <div className="mt-6 grid gap-4">
            <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5">
              <div className="text-xs tracking-widest text-slate-400">AUDIT SURFACES</div>
              <div className="mt-2 flex flex-wrap gap-2">
                <Link
                  to="/governance/fleet"
                  className="rounded-xl border border-slate-700 bg-black/30 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-black/50"
                >
                  FLEET TELEMETRY
                </Link>

<Link
  to="/governance/stability"
  className="rounded-xl border border-slate-700 bg-black/30 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-black/50"
>
  STABILITY INDEX
</Link>
                <Link
                  to="/governance/training-audit"
                  className="rounded-xl border border-slate-700 bg-black/30 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-black/50"
                >
                  TRAINING AUDIT
                </Link>
                <Link
                  to="/governance/compliance"
                  className="rounded-xl border border-slate-700 bg-black/30 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-black/50"
                >
                  COMPLIANCE
                </Link>
                <Link
                  to="/governance/incidents"
                  className="rounded-xl border border-slate-700 bg-black/30 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-black/50"
                >
                  INCIDENTS
                </Link>
                <Link
                  to="/governance/intake"
                  className="rounded-xl border border-slate-700 bg-black/30 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-black/50"
                >
                  INTAKE
                </Link>
                <Link
                  to="/governance/publishing"
                  className="rounded-xl border border-slate-700 bg-black/30 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-black/50"
                >
                  PUBLISHING
                </Link>
                <Link
                  to="/governance/rollout"
                  className="rounded-xl border border-slate-700 bg-black/30 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-black/50"
                >
                  CONTROLLED ROLLOUT
                </Link>
                <Link
                  to="/governance/amendments"
                  className="rounded-xl border border-slate-700 bg-black/30 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-black/50"
                >
                  AMENDMENTS
                </Link>
              </div>
            </div>
            <WeeklyPublisher />
            <SentinelConsole />
          </div>
        </RoleGate>
      </div>
    </div>
  );
}
