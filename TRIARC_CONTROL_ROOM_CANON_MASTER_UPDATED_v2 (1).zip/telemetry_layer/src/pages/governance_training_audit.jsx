import React, { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import RoleGate from '@/components/rbac/RoleGate';
import { listMemberRecords } from '@/data/api';
import { listTrainingSubmissions, listLocalTrainingSubmissions } from '@/data/trainingAudit';

export default function GovernanceTrainingAudit() {
  const [searchParams] = useSearchParams();
  const deepUplink = (searchParams.get('uplink') || '').trim();

  const [query, setQuery] = useState('');
  const [members, setMembers] = useState([]);
  const [activeEmail, setActiveEmail] = useState(null);
  const [remoteSubs, setRemoteSubs] = useState([]);
  const [loadingSubs, setLoadingSubs] = useState(false);

  useEffect(() => {
    if (deepUplink) setQuery(deepUplink);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deepUplink]);

  useEffect(() => {
    let alive = true;
    listMemberRecords({ q: query, limit: 25 })
      .then((rows) => {
        if (!alive) return;
        setMembers(Array.isArray(rows) ? rows : []);
      })
      .catch(() => {
        if (!alive) return;
        setMembers([]);
      });
    return () => {
      alive = false;
    };
  }, [query]);

  // If deep-linked by uplink, auto-select the first matching member (if available).
  useEffect(() => {
    if (!deepUplink) return;
    if (activeEmail) return;
    const hit = (members || []).find((m) => String(m.uplink_key || m.uplinkKey || '').toUpperCase() === deepUplink.toUpperCase());
    const em = hit?.email || hit?.operator_email || hit?.created_by || null;
    if (em) setActiveEmail(em);
  }, [deepUplink, members, activeEmail]);

  useEffect(() => {
    if (!activeEmail) {
      setRemoteSubs([]);
      return;
    }
    let alive = true;
    setLoadingSubs(true);
    listTrainingSubmissions({ operator_email: activeEmail, limit: 50 })
      .then((rows) => {
        if (!alive) return;
        setRemoteSubs(Array.isArray(rows) ? rows : []);
      })
      .catch(() => {
        if (!alive) return;
        setRemoteSubs([]);
      })
      .finally(() => {
        if (!alive) return;
        setLoadingSubs(false);
      });
    return () => {
      alive = false;
    };
  }, [activeEmail]);

  const localSubs = useMemo(() => {
    if (!activeEmail) return [];
    return listLocalTrainingSubmissions(activeEmail);
  }, [activeEmail]);

  const merged = useMemo(() => {
    // Prefer remote rows (audited). Keep local rows visible as "pending".
    const normRemote = (remoteSubs || []).map((r) => ({
      source: 'REMOTE',
      timestamp_ms: r.timestamp_ms ?? r.time ?? Date.now(),
      pathway: r.pathway,
      module_id: r.module_id ?? r.moduleId,
      module_title: r.module_title ?? r.moduleTitle,
      doc_id: r.doc_id ?? r.docId,
      text: r.text ?? '',
      status: r.status ?? 'SUBMITTED',
      id: r.id,
      raw: r,
    }));
    const normLocal = (localSubs || []).map((r, idx) => ({
      source: 'LOCAL',
      timestamp_ms: r.timestamp_ms ?? r.time ?? Date.now(),
      pathway: r.pathway,
      module_id: r.module_id ?? r.moduleId,
      module_title: r.module_title ?? r.moduleTitle,
      doc_id: r.doc_id ?? r.docId,
      text: r.text ?? '',
      status: 'PENDING_SYNC',
      id: `local-${idx}`,
      raw: r,
    }));

    const all = [...normRemote, ...normLocal];
    all.sort((a, b) => (b.timestamp_ms || 0) - (a.timestamp_ms || 0));
    return all.slice(0, 75);
  }, [remoteSubs, localSubs]);

  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • GOVERNANCE SURFACE</div>
        <h1 className="mt-2 text-2xl font-semibold">Training Audit</h1>
        <p className="mt-3 max-w-2xl text-sm text-slate-300">
          Review pathway checkpoint submissions. When Training entities are provisioned, submissions are written to the audit ledger automatically.
        </p>

        <RoleGate
          allow={['warden', 'controller', 'admin', 'architect']}
          fallback={
            <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-950 p-5 text-sm text-slate-300">
              Access restricted. This surface is reserved for governance roles.
            </div>
          }
        >
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5 md:col-span-1">
              <div className="text-xs uppercase tracking-widest text-slate-500">Operator</div>
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search email/name"
                className="mt-3 w-full rounded-xl border border-slate-800 bg-black/40 px-3 py-2 text-sm text-slate-100 outline-none"
              />
              <div className="mt-4 space-y-2">
                {(members || []).slice(0, 12).map((m) => {
                  const em = m.email || m.operator_email || m.created_by || null;
                  if (!em) return null;
                  const active = em === activeEmail;
                  return (
                    <button
                      key={m.id || em}
                      className={`w-full rounded-xl border px-3 py-2 text-left text-xs font-semibold ${
                        active
                          ? 'border-emerald-700 bg-emerald-950/40 text-emerald-200'
                          : 'border-slate-800 bg-black/30 text-slate-200 hover:bg-black/50'
                      }`}
                      onClick={() => setActiveEmail(em)}
                    >
                      <div className="truncate">{m.name || em}</div>
                      <div className="mt-1 truncate text-[11px] font-normal text-slate-400">{em}</div>
                    </button>
                  );
                })}
                {!members?.length ? (
                  <div className="rounded-xl border border-slate-800 bg-black/30 p-3 text-sm text-slate-300">No matches.</div>
                ) : null}
              </div>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5 md:col-span-2">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-xs uppercase tracking-widest text-slate-500">Submissions</div>
                  <div className="mt-1 text-sm text-slate-300">
                    {activeEmail ? activeEmail : 'Select an operator to review.'}
                  </div>
                </div>
                {loadingSubs ? (
                  <div className="text-xs text-slate-400">Loading…</div>
                ) : null}
              </div>

              <div className="mt-4 space-y-3">
                {activeEmail ? (
                  merged.length ? (
                    merged.map((s) => (
                      <div key={s.id} className="rounded-xl border border-slate-800 bg-black/30 p-4">
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div>
                            <div className="text-sm font-semibold">{s.module_title || s.module_id || 'Checkpoint'}</div>
                            <div className="mt-1 text-xs text-slate-400">
                              {s.pathway || '—'} • {new Date(s.timestamp_ms).toLocaleString()} • {s.source}
                            </div>
                          </div>
                          <div
                            className={`rounded-full border px-2 py-0.5 text-[11px] ${
                              s.status === 'PENDING_SYNC'
                                ? 'border-amber-700 bg-amber-950/30 text-amber-200'
                                : 'border-emerald-700 bg-emerald-950/30 text-emerald-200'
                            }`}
                          >
                            {s.status}
                          </div>
                        </div>
                        <div className="mt-3 whitespace-pre-wrap text-sm text-slate-200">
                          {s.text?.trim() ? s.text : <span className="text-slate-500">(empty)</span>}
                        </div>

                        {s.raw?.telemetry_context ? (
                          <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950/40 p-3">
                            <div className="text-[11px] tracking-widest text-slate-500">BOUND TELEMETRY CONTEXT</div>
                            <div className="mt-2 flex flex-wrap gap-2">
                              {(() => {
                                const c = s.raw.telemetry_context;
                                const chips = [
                                  c.symbol ? `SYMBOL: ${c.symbol}` : null,
                                  c.tf ? `TF: ${c.tf}` : null,
                                  c.gov_state ? `GOV: ${c.gov_state}` : null,
                                  c.wk_type ? `WK: ${c.wk_type} (${c.wk_confidence ?? '—'}%)` : null,
                                  c.sentinel_state !== null && c.sentinel_state !== undefined
                                    ? `SENT: ${c.sentinel_state}`
                                    : null,
                                  c.global_void ? 'VOID: TRUE' : null,
                                  c.probe_only ? 'PROBE: TRUE' : null,
                                  c.matrix_healthy === false ? 'MATRIX: FRACTURED' : (c.matrix_healthy === true ? 'MATRIX: OK' : null),
                                  c.navigator_bias ? `BIAS: ${c.navigator_bias}` : null,
                                  c.servo_decision ? `SERVO: ${c.servo_decision}` : null,
                                  c.risk_multiplier !== null && c.risk_multiplier !== undefined
                                    ? `LOAD: ${c.risk_multiplier}x (CAP ${c.env_cap ?? '—'}x)`
                                    : null,
                                ].filter(Boolean);
                                return chips.map((t) => (
                                  <span key={t} className="rounded-full border border-slate-800 bg-black/40 px-2 py-0.5 text-[11px] text-slate-200">
                                    {t}
                                  </span>
                                ));
                              })()}
                            </div>
                          </div>
                        ) : null}
                        {s.doc_id ? (
                          <div className="mt-3 text-xs text-slate-400">Doc: {s.doc_id}</div>
                        ) : null}
                      </div>
                    ))
                  ) : (
                    <div className="rounded-xl border border-slate-800 bg-black/30 p-4 text-sm text-slate-300">
                      No submissions found for this operator.
                    </div>
                  )
                ) : (
                  <div className="rounded-xl border border-slate-800 bg-black/30 p-4 text-sm text-slate-300">
                    Choose an operator on the left.
                  </div>
                )}
              </div>
            </div>
          </div>
        </RoleGate>
      </div>
    </div>
  );
}
