import React from 'react';
import { Link } from 'react-router-dom';

const Shell = ({ children }) => (
  <div className="min-h-screen bg-black text-slate-100">
    <div className="mx-auto max-w-5xl px-6 py-10">
      <header className="flex items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="text-xs tracking-widest text-slate-400">TRIARC ECOSYSTEMS</div>
          <h1 className="mt-1 text-2xl font-semibold text-slate-100">Sovereign Control Room</h1>
        </div>
        <nav className="flex flex-wrap items-center gap-3">
          <Link className="rounded-md border border-slate-700 px-3 py-2 text-sm text-slate-200 hover:bg-slate-900" to="/public/whitepapers">
            Whitepapers
          </Link>
          <Link className="rounded-md border border-slate-700 px-3 py-2 text-sm text-slate-200 hover:bg-slate-900" to="/permission">
            Permission
          </Link>
          <Link className="rounded-md bg-slate-100 px-3 py-2 text-sm font-medium text-black hover:bg-white" to="/portal">
            Enter Portal
          </Link>
        </nav>
      </header>
      {children}
      <footer className="mt-16 border-t border-slate-800 pt-6 text-xs text-slate-500">
        TriArc is an institutional governance environment for operators. No hype. No outcome promises. Permission governs participation.
      </footer>
    </div>
  </div>
);

export default function Landing() {
  return (
    <Shell>
      <main className="pt-10">
        <div className="grid gap-10 md:grid-cols-2">
          <section>
            <h2 className="text-xl font-semibold">What TriArc is</h2>
            <p className="mt-4 text-slate-300 leading-relaxed">
              TriArc is not a signal service. It is a governed environment that trains and constrains participation through a single operating law:
              <span className="text-slate-100 font-medium"> Permission &gt; Opportunity</span>.
            </p>
            <div className="mt-6 rounded-xl border border-slate-800 bg-slate-950 p-5">
              <div className="text-sm text-slate-200 font-medium">Whitepapers Axes</div>
              <ul className="mt-3 space-y-2 text-sm text-slate-300">
                <li><span className="text-slate-100">Time</span> &gt; Price</li>
                <li><span className="text-slate-100">Structure</span> &gt; Pattern</li>
                <li><span className="text-slate-100">Volatility</span> &gt; Direction</li>
                <li><span className="text-slate-100">Permission</span> &gt; Opportunity</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold">How access works</h2>
            <p className="mt-4 text-slate-300 leading-relaxed">
              Public pages explain the doctrine. The portal is gated. Role, pathway, and tool permissions are assigned after intake.
              Execution surfaces remain constrained until permission is earned.
            </p>

            <div className="mt-6 grid gap-4">
              <div className="rounded-xl border border-slate-800 bg-slate-950 p-5">
                <div className="text-sm font-medium text-slate-200">Step 1 — Whitepapers</div>
                <p className="mt-2 text-sm text-slate-300">Understand environment-first governance. Read before requesting access.</p>
                <div className="mt-4">
                  <Link className="inline-flex rounded-md border border-slate-700 px-3 py-2 text-sm text-slate-200 hover:bg-slate-900" to="/public/whitepapers">
                    Read Whitepapers
                  </Link>
                </div>
              </div>

              <div className="rounded-xl border border-slate-800 bg-slate-950 p-5">
                <div className="text-sm font-medium text-slate-200">Step 2 — Permission Intake</div>
                <p className="mt-2 text-sm text-slate-300">Request evaluation and routing to the correct pathway and tier.</p>
                <div className="mt-4 flex flex-wrap gap-3">
                  <Link className="inline-flex rounded-md border border-slate-700 px-3 py-2 text-sm text-slate-200 hover:bg-slate-900" to="/permission">
                    Permission Framework
                  </Link>
                  <Link className="inline-flex rounded-md bg-slate-100 px-3 py-2 text-sm font-medium text-black hover:bg-white" to="/access-request">
                    Request Access
                  </Link>
                </div>
              </div>

              <div className="rounded-xl border border-slate-800 bg-slate-950 p-5">
                <div className="text-sm font-medium text-slate-200">Step 3 — Portal</div>
                <p className="mt-2 text-sm text-slate-300">Once provisioned, the portal routes you to Pathway → Weekly → Nexus execution spine.</p>
                <div className="mt-4">
                  <Link className="inline-flex rounded-md border border-slate-700 px-3 py-2 text-sm text-slate-200 hover:bg-slate-900" to="/portal">
                    Enter Portal
                  </Link>
                </div>
              </div>
            </div>
          </section>
        </div>

        <section className="mt-12 rounded-2xl border border-slate-800 bg-gradient-to-b from-slate-950 to-black p-6">
          <div className="text-sm text-slate-400 tracking-widest">EXECUTION SPINE</div>
          <h3 className="mt-2 text-lg font-semibold">Weekly Classifier → Nexus → Compliance</h3>
          <p className="mt-3 text-sm text-slate-300 leading-relaxed">
            The Weekly Classifier defines environment. Nexus enforces permission and emits telemetry. Compliance governs continuation.
            This chain is non-negotiable.
          </p>
        </section>
      </main>
    </Shell>
  );
}
