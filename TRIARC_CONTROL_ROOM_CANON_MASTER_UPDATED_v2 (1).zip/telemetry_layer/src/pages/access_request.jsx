import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { submitAccessRequest } from '@/data/outreach';

const Field = ({ label, children, hint }) => (
  <div className="space-y-2">
    <div className="text-xs tracking-widest text-slate-400">{label}</div>
    {children}
    {hint ? <div className="text-xs text-slate-500">{hint}</div> : null}
  </div>
);

export default function AccessRequest() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    intent: '',
    pathway_hint: '',
    experience: '',
    notes: '',
  });
  const [status, setStatus] = useState('IDLE'); // IDLE | SENDING | SENT | ERROR
  const [error, setError] = useState('');

  const onChange = (k) => (e) => {
    const v = e?.target?.value ?? '';
    setForm((prev) => ({ ...prev, [k]: v }));
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    setStatus('SENDING');
    setError('');
    try {
      await submitAccessRequest(form);
      setStatus('SENT');
    } catch (err) {
      setStatus('ERROR');
      setError(err?.message || 'Request failed.');
    }
  };

  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-3xl px-6 py-10">
        <header className="flex items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <div>
            <div className="text-xs tracking-widest text-slate-400">ACCESS REQUEST</div>
            <h1 className="mt-1 text-2xl font-semibold">Permission Intake</h1>
          </div>
          <nav className="flex items-center gap-3">
            <Link className="rounded-md border border-slate-700 px-3 py-2 text-sm text-slate-200 hover:bg-slate-900" to="/landing">
              Landing
            </Link>
            <Link className="rounded-md border border-slate-700 px-3 py-2 text-sm text-slate-200 hover:bg-slate-900" to="/permission">
              Permission
            </Link>
          </nav>
        </header>

        <main className="pt-10">
          <p className="text-sm text-slate-300 leading-relaxed">
            This request is for evaluation and routing. Approval is not guaranteed. Execution access (Nexus) is always conditional.
          </p>

          <div className="mt-6 rounded-xl border border-slate-800 bg-slate-950 p-5">
            {status === 'SENT' ? (
              <div>
                <div className="text-sm font-medium text-slate-100">Request submitted.</div>
                <p className="mt-2 text-sm text-slate-300">
                  If accepted, you will be provisioned into the correct pathway and granted role-based access.
                </p>
                <div className="mt-4 flex flex-wrap gap-3">
                  <Link className="rounded-md border border-slate-700 px-4 py-2 text-sm text-slate-200 hover:bg-slate-900" to="/public/doctrine">
                    Read doctrine
                  </Link>
                  <Link className="rounded-md bg-slate-100 px-4 py-2 text-sm font-medium text-black hover:bg-white" to="/portal">
                    Enter portal
                  </Link>
                </div>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="space-y-5">
                <div className="grid gap-4 md:grid-cols-2">
                  <Field label="NAME">
                    <input
                      value={form.name}
                      onChange={onChange('name')}
                      className="w-full rounded-md border border-slate-700 bg-black px-3 py-2 text-sm text-slate-100 outline-none focus:border-slate-400"
                      placeholder="Operator name"
                      autoComplete="name"
                    />
                  </Field>

                  <Field label="EMAIL" hint="Required. Used only for provisioning and audit tracking.">
                    <input
                      value={form.email}
                      onChange={onChange('email')}
                      className="w-full rounded-md border border-slate-700 bg-black px-3 py-2 text-sm text-slate-100 outline-none focus:border-slate-400"
                      placeholder="operator@domain.com"
                      autoComplete="email"
                      required
                    />
                  </Field>
                </div>

                <Field label="INTENT" hint="What are you here to build? Keep it short.">
                  <input
                    value={form.intent}
                    onChange={onChange('intent')}
                    className="w-full rounded-md border border-slate-700 bg-black px-3 py-2 text-sm text-slate-100 outline-none focus:border-slate-400"
                    placeholder="E.g., disciplined intraday execution under governance"
                  />
                </Field>

                <div className="grid gap-4 md:grid-cols-2">
                  <Field label="PATHWAY HINT" hint="Optional. TriArc will route you by integrity, not preference.">
                    <select
                      value={form.pathway_hint}
                      onChange={onChange('pathway_hint')}
                      className="w-full rounded-md border border-slate-700 bg-black px-3 py-2 text-sm text-slate-100 outline-none focus:border-slate-400"
                    >
                      <option value="">Unspecified</option>
                      <option value="ACADEMY">Academy</option>
                      <option value="INFIRMARY">Infirmary</option>
                      <option value="ENGINEER">Engineer</option>
                    </select>
                  </Field>

                  <Field label="EXPERIENCE" hint="Optional. What best describes your current stage?">
                    <select
                      value={form.experience}
                      onChange={onChange('experience')}
                      className="w-full rounded-md border border-slate-700 bg-black px-3 py-2 text-sm text-slate-100 outline-none focus:border-slate-400"
                    >
                      <option value="">Unspecified</option>
                      <option value="ROOKIE">Rookie</option>
                      <option value="RETURNING">Returning / rebuilding</option>
                      <option value="DISCIPLINED">Disciplined operator</option>
                      <option value="SYSTEMS">Systems / engineer mindset</option>
                    </select>
                  </Field>
                </div>

                <Field label="NOTES" hint="Optional. Constraints, availability, or context that affects routing.">
                  <textarea
                    value={form.notes}
                    onChange={onChange('notes')}
                    className="min-h-[110px] w-full rounded-md border border-slate-700 bg-black px-3 py-2 text-sm text-slate-100 outline-none focus:border-slate-400"
                    placeholder="Constraints, tools you use, markets, etc."
                  />
                </Field>

                {status === 'ERROR' ? (
                  <div className="rounded-md border border-red-900 bg-red-950/40 px-3 py-2 text-sm text-red-200">
                    {error}
                  </div>
                ) : null}

                <div className="flex flex-wrap items-center gap-3">
                  <button
                    type="submit"
                    disabled={status === 'SENDING'}
                    className="rounded-md bg-slate-100 px-4 py-2 text-sm font-medium text-black hover:bg-white disabled:opacity-60"
                  >
                    {status === 'SENDING' ? 'Submitting…' : 'Submit request'}
                  </button>
                  <Link className="rounded-md border border-slate-700 px-4 py-2 text-sm text-slate-200 hover:bg-slate-900" to="/public/doctrine">
                    Review doctrine
                  </Link>
                </div>
              </form>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
