import React, { useMemo, useState } from 'react';
import RoleGate from '@/components/rbac/RoleGate';
import { RETENTION } from '../data/retentionPolicy.js';
import { exportAuditBundle } from '../data/auditExport.js';

// NOTE: This is a UI stub that assumes `window.base44Api` exists.
// Replace with your actual API client injection.

export default function GovernanceDataHardening() {
  const [uplink, setUplink] = useState('');
  const [days, setDays] = useState(30);
  const [status, setStatus] = useState('IDLE');
  const [report, setReport] = useState(null);

  const startMs = useMemo(() => Date.now() - Number(days || 30) * 86400000, [days]);
  const endMs = useMemo(() => Date.now(), []);

  async function runExport() {
    setStatus('EXPORTING');
    setReport(null);
    try {
      const api = window.base44Api;
      const bundle = await exportAuditBundle({ api, uplinkKey: uplink, startMs, endMs });
      setReport(bundle);
      setStatus('READY');

      const blob = new Blob([JSON.stringify(bundle, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `TRIARC_AUDIT_${uplink}_${Date.now()}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      setStatus('ERROR');
      setReport({ error: String(e?.message || e) });
    }
  }

  return (
    <RoleGate allow={['admin', 'architect', 'controller', 'warden']}>
      <div style={{ padding: 24, maxWidth: 980 }}>
        <h1>DATA HARDENING</h1>
        <p style={{ opacity: 0.8 }}>
          Governance-only tools for retention posture and audit export. Telemetry is bounded. Incidents are institutional record.
        </p>

        <div style={{ display: 'grid', gap: 12, gridTemplateColumns: '1fr 1fr' }}>
          <div style={{ border: '1px solid rgba(255,255,255,0.12)', padding: 16, borderRadius: 12 }}>
            <h3>Retention Defaults</h3>
            <ul>
              <li>Snapshots: {RETENTION.DEFAULT_SNAPSHOT_DAYS} days</li>
              <li>Opportunities: {RETENTION.DEFAULT_OPPORTUNITY_DAYS} days</li>
              <li>Incidents: indefinite</li>
              <li>Enforcement: indefinite</li>
              <li>Training submissions: {RETENTION.TRAINING_SUBMISSIONS_DAYS} days</li>
            </ul>
          </div>

          <div style={{ border: '1px solid rgba(255,255,255,0.12)', padding: 16, borderRadius: 12 }}>
            <h3>Audit Export</h3>
            <label style={{ display: 'block', marginBottom: 8 }}>Uplink Key</label>
            <input value={uplink} onChange={(e) => setUplink(e.target.value)} placeholder="TRIARC-PRM-..." style={{ width: '100%', padding: 10, borderRadius: 10 }} />

            <label style={{ display: 'block', marginTop: 12, marginBottom: 8 }}>Window (days)</label>
            <input type="number" value={days} onChange={(e) => setDays(e.target.value)} min={1} max={3650} style={{ width: '100%', padding: 10, borderRadius: 10 }} />

            <button
              onClick={runExport}
              disabled={!uplink || status === 'EXPORTING'}
              style={{ marginTop: 12, padding: '10px 14px', borderRadius: 10, cursor: 'pointer' }}
            >
              {status === 'EXPORTING' ? 'EXPORTING…' : 'EXPORT JSON BUNDLE'}
            </button>
          </div>
        </div>

        <div style={{ marginTop: 18, border: '1px solid rgba(255,255,255,0.12)', padding: 16, borderRadius: 12 }}>
          <h3>Status</h3>
          <div style={{ opacity: 0.85 }}>{status}</div>
          {report ? (
            <pre style={{ marginTop: 10, maxHeight: 360, overflow: 'auto', fontSize: 12, opacity: 0.9 }}>
              {JSON.stringify(report?.meta ? report.meta : report, null, 2)}
            </pre>
          ) : null}
        </div>
      </div>
    </RoleGate>
  );
}
