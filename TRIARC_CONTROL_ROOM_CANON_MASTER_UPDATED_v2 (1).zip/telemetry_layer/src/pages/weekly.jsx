import React from "react";
import WeeklyPanels from "@/components/controlroom/WeeklyPanels";
import EntitlementGate from "@/components/rbac/EntitlementGate";

export default function Weekly() {
  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • WEEKLY HUB</div>
        <h1 className="mt-2 text-2xl font-semibold">Weekly</h1>
        <p className="mt-3 max-w-2xl text-sm text-slate-300">
          The Weekly Artifact is the environment contract. Operators consume it. Wardens publish it.
          This surface stays read-only for Operators.
        </p>

        <div className="mt-4">
          <a className="rounded-xl border border-slate-800 bg-black px-4 py-2 text-sm text-slate-200 hover:bg-slate-900" href="/weekly/archive">
            View Archive
          </a>
        </div>

        <div className="mt-8">
          <EntitlementGate requireSubscription>
            <WeeklyPanels instrument="ES" />
          </EntitlementGate>
        </div>
      </div>
    </div>
  );
}
