import React from 'react';
import { Link } from 'react-router-dom';

const Panel = ({ title, children }) => (
  <div className="rounded-xl border border-slate-800 bg-slate-950 p-5">
    <div className="text-sm font-medium text-slate-200">{title}</div>
    <div className="mt-2 text-sm text-slate-300 leading-relaxed">{children}</div>
  </div>
);

export default function PublicDoctrine() {
  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-4xl px-6 py-10">
        <header className="flex items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <div>
            <div className="text-xs tracking-widest text-slate-400">PUBLIC DOCTRINE</div>
            <h1 className="mt-1 text-2xl font-semibold">Stop trading patterns. Start trading environments.</h1>
          </div>
          <nav className="flex items-center gap-3">
            <Link className="rounded-md border border-slate-700 px-3 py-2 text-sm text-slate-200 hover:bg-slate-900" to="/landing">
              Landing
            </Link>
            <Link className="rounded-md border border-slate-700 px-3 py-2 text-sm text-slate-200 hover:bg-slate-900" to="/permission">
              Permission
            </Link>
            <Link className="rounded-md bg-slate-100 px-3 py-2 text-sm font-medium text-black hover:bg-white" to="/access-request">
              Request Access
            </Link>
          </nav>
        </header>

        <main className="pt-10 space-y-6">
          <p className="text-slate-300 leading-relaxed">
            TriArc doctrine is built to remove narrative drift and prevent "pattern chasing".
            Environments are measured. Permission is enforced. Opportunity is a downstream artifact.
          </p>

          <div className="grid gap-4 md:grid-cols-2">
            <Panel title="The Four Laws">
              <ul className="mt-3 list-disc space-y-2 pl-5">
                <li><span className="text-slate-100">Time</span> &gt; Price</li>
                <li><span className="text-slate-100">Structure</span> &gt; Pattern</li>
                <li><span className="text-slate-100">Volatility</span> &gt; Direction</li>
                <li><span className="text-slate-100">Permission</span> &gt; Opportunity</li>
              </ul>
            </Panel>

            <Panel title="The Control Chain">
              <div className="mt-3 text-sm text-slate-300">
                <div><span className="text-slate-100">Weekly Classifier</span> defines environment + clarity.</div>
                <div className="mt-2"><span className="text-slate-100">Nexus</span> gates execution and emits telemetry.</div>
                <div className="mt-2"><span className="text-slate-100">Compliance</span> governs continuation, remediation, and escalation.</div>
              </div>
            </Panel>
          </div>

          <Panel title="Why environments beat patterns">
            Patterns are local and fragile. Environments are systemic.
            When the environment changes, the same pattern becomes a different bet.
            TriArc forces the operator to identify the environment first, then act only inside permission.
          </Panel>

          <Panel title="What TriArc refuses">
            <ul className="mt-3 list-disc space-y-2 pl-5">
              <li>Hype, testimonials, and profit language</li>
              <li>Unbounded leverage or "always-on" participation</li>
              <li>Execution without telemetry and audit</li>
              <li>Uncontrolled variance disguised as confidence</li>
            </ul>
          </Panel>

          <div className="rounded-2xl border border-slate-800 bg-gradient-to-b from-slate-950 to-black p-6">
            <div className="text-xs tracking-widest text-slate-400">NEXT STEP</div>
            <h2 className="mt-2 text-lg font-semibold">If you accept governance, request permission.</h2>
            <p className="mt-3 text-sm text-slate-300">
              Intake routes you to the correct pathway and constrains tool access. Execution remains conditional.
            </p>
            <div className="mt-4 flex flex-wrap gap-3">
              <Link className="rounded-md bg-slate-100 px-4 py-2 text-sm font-medium text-black hover:bg-white" to="/access-request">
                Request Access
              </Link>
              <Link className="rounded-md border border-slate-700 px-4 py-2 text-sm text-slate-200 hover:bg-slate-900" to="/portal">
                Enter Portal
              </Link>
            </div>
          </div>
        </main>

        <footer className="mt-16 border-t border-slate-800 pt-6 text-xs text-slate-500">
          Public doctrine is informational. TriArc provides governance and training. Nothing here is trading advice.
        </footer>
      </div>
    </div>
  );
}
