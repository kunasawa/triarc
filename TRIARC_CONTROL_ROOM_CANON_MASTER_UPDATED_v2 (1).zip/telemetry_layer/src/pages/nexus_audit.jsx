import React, { useMemo } from "react";
import { useIdentity, useOpportunityLedger, useNexusEvents } from "@/data/hooks";
import { TELEMETRY_EVENTS } from "@/data/contracts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

function safeJsonParse(v) {
  try {
    if (v == null) return null;
    if (typeof v === "object") return v;
    return JSON.parse(v);
  } catch {
    return null;
  }
}

function toAuditRow(ev) {
  const payload = ev?.payload ?? safeJsonParse(ev?.payload_json) ?? null;
  const meta = payload?.meta ?? {};
  const gov = payload?.governance ?? {};
  const opp = payload?.opportunity ?? {};
  const ts = ev?.event_time_ms ?? ev?.timestamp_ms ?? meta?.event_time_ms ?? null;

  return {
    id: ev?.id ?? `${ev?.uplink_key ?? "—"}:${ts ?? "—"}:${ev?.event_type ?? "—"}`,
    event_type: ev?.event_type ?? "—",
    event_time_ms: ts,
    symbol: ev?.symbol ?? meta?.symbol ?? "—",
    tf: ev?.tf ?? meta?.tf ?? "—",
    gov_state: gov?.gov_state ?? "—",
    denial_reason: gov?.denial_reason ?? "—",
    opp_active: opp?.active ?? null,
    opp_id: opp?.opportunity_id ?? null,
    opp_name: opp?.name ?? "—",
    opp_side: opp?.side ?? "—",
    opp_score: opp?.score ?? null,
  };
}

export default function NexusAudit() {
  const idQ = useIdentity();
  const uplink = idQ.data?.uplink_key ?? null;

  const ledgerQ = useOpportunityLedger(uplink, 40);
  const createdQ = useNexusEvents({ uplink_key: uplink, event_type: TELEMETRY_EVENTS.OPPORTUNITY_CREATED, limit: 50 });
  const clearedQ = useNexusEvents({ uplink_key: uplink, event_type: TELEMETRY_EVENTS.OPPORTUNITY_CLEARED, limit: 50 });

  const created = useMemo(() => (createdQ.data ?? []).map(toAuditRow), [createdQ.data]);
  const cleared = useMemo(() => (clearedQ.data ?? []).map(toAuditRow), [clearedQ.data]);

  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • EXECUTION SPINE</div>
        <h1 className="mt-2 text-2xl font-semibold">Nexus Audit</h1>
        <p className="mt-3 max-w-3xl text-sm text-slate-300">
          Audit trail for opportunity lifecycle events and the opportunity ledger. This surface is intended for
          reconciliation and governance reviews.
        </p>

        {!uplink ? (
          <div className="mt-8 rounded-2xl border border-slate-800 bg-slate-950 p-5 text-sm text-slate-300">
            No uplink key is bound to this identity yet.
          </div>
        ) : (
          <>
            <div className="mt-8 grid gap-4 md:grid-cols-2">
              <Card className="bg-slate-950 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-base">Opportunity Ledger</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-xs tracking-widest text-slate-500">UPLINK: {uplink}</div>

                  <div className="mt-3 overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="text-slate-400">
                        <tr className="border-b border-slate-800">
                          <th className="py-2 pr-3">Last Seen</th>
                          <th className="py-2 pr-3">State</th>
                          <th className="py-2 pr-3">Side</th>
                          <th className="py-2 pr-3">Name</th>
                          <th className="py-2 pr-3">Score</th>
                        </tr>
                      </thead>
                      <tbody className="text-slate-200">
                        {(ledgerQ.data ?? []).map((r) => (
                          <tr key={r.id} className="border-b border-slate-900">
                            <td className="py-2 pr-3 text-slate-400">{r.last_seen_timestamp_ms ?? r.event_time_ms ?? "—"}</td>
                            <td className="py-2 pr-3">{String(r.opp_active ?? r.active ?? "—")}</td>
                            <td className="py-2 pr-3">{r.opp_side ?? r.side ?? "—"}</td>
                            <td className="py-2 pr-3">{r.opp_name ?? r.name ?? "—"}</td>
                            <td className="py-2 pr-3">{r.opp_score ?? r.score ?? "—"}</td>
                          </tr>
                        ))}
                        {!ledgerQ.isLoading && !(ledgerQ.data ?? []).length && (
                          <tr>
                            <td colSpan={5} className="py-8 text-center text-slate-500">
                              No ledger rows yet.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-950 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-base">Lifecycle Reconciliation</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-xs text-slate-400">
                    Use these lists to confirm that opportunity creation and clearance events are flowing and ordered.
                  </div>

                  <div className="mt-4 grid gap-4 md:grid-cols-2">
                    <div className="rounded-2xl border border-slate-800 bg-black/30 p-4">
                      <div className="text-xs tracking-widest text-slate-500">CREATED (last 10)</div>
                      <div className="mt-2 space-y-2">
                        {created.slice(0, 10).map((r) => (
                          <div key={r.id} className="rounded-xl border border-slate-800 bg-black/20 p-3">
                            <div className="text-xs text-slate-300">{r.symbol} • {r.tf}</div>
                            <div className="mt-1 text-xs text-slate-500">{r.event_time_ms ?? "—"}</div>
                            <div className="mt-1 text-xs text-slate-200">{r.opp_side} • {r.opp_name}</div>
                          </div>
                        ))}
                        {!createdQ.isLoading && !created.length && (
                          <div className="text-xs text-slate-500">No created events yet.</div>
                        )}
                      </div>
                    </div>

                    <div className="rounded-2xl border border-slate-800 bg-black/30 p-4">
                      <div className="text-xs tracking-widest text-slate-500">CLEARED (last 10)</div>
                      <div className="mt-2 space-y-2">
                        {cleared.slice(0, 10).map((r) => (
                          <div key={r.id} className="rounded-xl border border-slate-800 bg-black/20 p-3">
                            <div className="text-xs text-slate-300">{r.symbol} • {r.tf}</div>
                            <div className="mt-1 text-xs text-slate-500">{r.event_time_ms ?? "—"}</div>
                            <div className="mt-1 text-xs text-slate-200">{r.opp_side} • {r.opp_name}</div>
                          </div>
                        ))}
                        {!clearedQ.isLoading && !cleared.length && (
                          <div className="text-xs text-slate-500">No cleared events yet.</div>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
