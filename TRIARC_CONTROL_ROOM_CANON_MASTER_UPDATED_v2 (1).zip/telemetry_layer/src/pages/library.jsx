import React from 'react';
import { useSearchParams } from 'react-router-dom';
import { LIBRARY_DOCS } from '@/data/libraryRegistry';
import RoleGate from '@/components/rbac/RoleGate';
import { useAuth } from '@/lib/AuthContext';
import { canViewArtifact, deriveRollout, SURFACE } from '@/data/rolloutPolicy';
import { canOpenArtifact, getPlaybookAccess, isPlaybookDoc, isSubscriptionActive } from '@/lib/entitlements';

export default function Library() {
  const [params] = useSearchParams();
  const focus = params.get('doc');
  const { user } = useAuth();

  const visible = LIBRARY_DOCS.filter((d) => canViewArtifact({ user, doc: d, surface: SURFACE.LIBRARY }));

  const playbookAccess = getPlaybookAccess(user);
  const subOk = isSubscriptionActive(user);

  return (
    <RoleGate>
      <div className="min-h-screen bg-black text-slate-100">
        <div className="mx-auto max-w-5xl px-6 py-10">
          <div className="text-xs tracking-widest text-slate-500">CONTROL ROOM</div>
          <h1 className="mt-2 text-2xl font-semibold">Library</h1>
          <p className="mt-2 max-w-2xl text-sm text-slate-300">
            Governed artifact index. “UNBOUND” items require a publishing link assigned by the Weekly Publishing Pipeline.
            Playbooks are tier-gated.
          </p>

          <div className="mt-4 rounded-2xl border border-slate-800 bg-black/40 p-4 text-xs text-slate-300">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <span className="text-slate-500">Subscription:</span>{' '}
                <span className={subOk ? 'text-emerald-400' : 'text-amber-300'}>{subOk ? 'ACTIVE / GRACE' : 'INACTIVE'}</span>
              </div>
              <div>
                <span className="text-slate-500">Playbook Access:</span>{' '}
                <span className="text-slate-200">{playbookAccess || '—'}</span>
              </div>
            </div>
          </div>

          <div className="mt-6 grid gap-3">
            {visible.map((d) => {
              const isFocus = focus && d.id === focus;
              const ro = deriveRollout(d);
              const openOk = canOpenArtifact(d, user);
              const isPB = isPlaybookDoc(d);

              let stateBadge = null;
              if (!d.url) stateBadge = <span className="text-slate-500">UNBOUND</span>;
              else if (!openOk) stateBadge = <span className="text-amber-300">LOCKED</span>;
              else stateBadge = <span className="text-emerald-400">READY</span>;

              let lockReason = '';
              if (d.url && !openOk) {
                if (isPB && !subOk) lockReason = 'Subscription inactive';
                else if (isPB) lockReason = 'Tier access gate';
                else lockReason = 'Governance gate';
              }

              return (
                <div
                  key={d.id}
                  className={`rounded-2xl border p-4 ${
                    isFocus ? 'border-emerald-700 bg-emerald-950/10' : 'border-slate-800 bg-black/40'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="text-xs text-slate-400">{d.id}</div>
                      <div className="mt-1 font-semibold">{d.title}</div>
                      <div className="mt-1 text-xs text-slate-500">
                        {String(d.category).toUpperCase()} • {d.status} • {ro.surface} • {ro.stage} • {stateBadge}
                        {lockReason ? <span className="text-slate-600"> — {lockReason}</span> : null}
                      </div>
                    </div>

                    {d.url ? (
                      openOk ? (
                        <a
                          className="rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-900"
                          href={d.url}
                          target="_blank"
                          rel="noreferrer"
                        >
                          OPEN
                        </a>
                      ) : (
                        <div className="rounded-xl border border-slate-800 bg-black/40 px-3 py-2 text-xs font-semibold text-amber-300">
                          LOCKED
                        </div>
                      )
                    ) : (
                      <div className="rounded-xl border border-slate-800 bg-black/40 px-3 py-2 text-xs font-semibold text-slate-500">
                        UNBOUND
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </RoleGate>
  );
}
