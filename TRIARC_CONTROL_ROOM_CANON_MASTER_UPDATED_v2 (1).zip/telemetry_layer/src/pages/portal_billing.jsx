import React from 'react';
import { PRICE_IDS, createCheckoutSession, createBillingPortalSession, syncBillingAuthority } from '@/data/billing';
import { useMemberRecord } from '@/data/hooks';

const Card = ({ title, price, desc, onAction, disabled, actionLabel = 'Select Tier' }) => (
  <div className="rounded-2xl border border-white/10 bg-black/40 p-5 shadow">
    <div className="text-lg font-semibold text-white">{title}</div>
    <div className="mt-1 text-2xl font-bold text-white">{price}</div>
    <div className="mt-2 text-sm text-white/70">{desc}</div>
    <button
      className={`mt-4 w-full rounded-xl px-4 py-2 text-sm font-semibold ${disabled ? 'bg-white/10 text-white/40' : 'bg-white text-black hover:bg-white/90'}`}
      onClick={onAction}
      disabled={disabled}
    >
      Open Checkout
    </button>
  </div>
);

export default function PortalBilling() {
  const { data: member } = useMemberRecord();

  const goCheckout = async (price_id) => {
    const out = await createCheckoutSession({ price_id, return_path: '/portal/billing' });
    const url = out?.url || out?.checkout_url;
    if (url) window.location.href = url;
  };


  const goPortal = async () => {
    const out = await createBillingPortalSession({ return_path: '/portal/billing' });
    const url = out?.url || out?.portal_url;
    if (url) window.location.href = url;
  };

  const sync = async () => {
    await syncBillingAuthority();
    window.location.reload();
  };

  const status = (member?.raw?.record?.subscription_status || member?.raw?.record?.billing_status || 'UNKNOWN').toString();
  const tier = (member?.tier || member?.raw?.record?.tier || 'UNDECLARED').toString();
  const gauntletApproved = !!(member?.raw?.record?.gauntlet_approved || member?.raw?.record?.gauntletApproved || member?.raw?.record?.gauntlet_access_approved || (member?.raw?.record?.gauntlet_status || '').toString().toUpperCase() === 'APPROVED');

  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      <div className="mx-auto max-w-5xl px-5 py-10">
        <div className="flex items-start justify-between gap-6">
          <div>
            <div className="text-2xl font-semibold">Billing Authority</div>
            <div className="mt-2 max-w-2xl text-sm text-white/70">
              Canon: access is governed by subscription authority. This surface exists only to establish or repair that authority.
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-black/40 p-4 text-sm">
            <div className="text-white/70">Identity</div>
            <div className="mt-1 font-semibold">{member?.email || '—'}</div>
            <div className="mt-3 grid grid-cols-2 gap-3">
              <div>
                <div className="text-white/50 text-xs">Tier</div>
                <div className="font-semibold">{tier}</div>
              </div>
              <div>
                <div className="text-white/50 text-xs">Status</div>
                <div className="font-semibold">{status}</div>
              </div>
            </div>
            <button
              className="mt-4 w-full rounded-xl bg-white/10 px-4 py-2 text-xs font-semibold text-white hover:bg-white/15"
              onClick={sync}
            >
              Sync Billing Authority
            </button>
            <button
              className="mt-2 w-full rounded-xl border border-white/10 bg-transparent px-4 py-2 text-xs font-semibold text-white/80 hover:bg-white/5"
              onClick={goPortal}
            >
              Manage Subscription (Stripe Portal)
            </button>
          </div>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-4 md:grid-cols-3">
          <Card
            title="TriArc Academy"
            price="$97 / month"
            desc="Training-only access + MES/ES playbook entitlement. Execution remains governed by Nexus permission."
            onAction={() => goCheckout(PRICE_IDS.ACADEMY)}
          />
          <Card
            title="TriArc Infirmary"
            price="$147 / month"
            desc="Rehabilitation pathway + MES/ES and MNQ/NQ playbook entitlement."
            onAction={() => goCheckout(PRICE_IDS.INFIRMARY)}
          />
          {gauntletApproved ? (
            <Card
              title="TriArc Gauntlet"
              price="$197 / month"
              desc="Operator pathway + full playbook library entitlement."
              onAction={() => goCheckout(PRICE_IDS.GAUNTLET)}
            />
          ) : (
            <Card
              title="TriArc Gauntlet"
              price="$197 / month"
              desc="Approval-gated. Governance review required before Gauntlet authority can be issued."
              actionLabel="Request Review"
              onAction={() => window.location.href = '/portal/governance'}
            />
          )}
        </div>

        <div className="mt-10 rounded-2xl border border-white/10 bg-black/40 p-5 text-sm text-white/70">
          <div className="font-semibold text-white">What happens after payment?</div>
          <ul className="mt-2 list-disc space-y-1 pl-5">
            <li>Stripe webhook updates your profile authority (tier, status, grace window).</li>
            <li>Library entitlements are recalculated (playbook access map).</li>
            <li>Execution permission remains governed by Nexus: Time → Sentinel → RBAC → Environment caps.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
