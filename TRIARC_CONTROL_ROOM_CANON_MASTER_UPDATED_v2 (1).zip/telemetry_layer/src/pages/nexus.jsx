import React from "react";
import { useIdentity } from "@/data/hooks";
import NexusPanels from "@/components/controlroom/NexusPanels";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import EntitlementGate from "@/components/rbac/EntitlementGate";

export default function Nexus() {
  const idQ = useIdentity();
  const uplink = idQ.data?.uplink_key;

  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • NEXUS HUB</div>
        <h1 className="mt-2 text-2xl font-semibold">Nexus</h1>
        <p className="mt-3 max-w-2xl text-sm text-slate-300">
          Nexus is an execution-governance engine. This hub visualizes telemetry and permission states.
          It does not issue advice.
        </p>

        <div className="mt-8">
          <EntitlementGate requireSubscription requireExecution>
            {!uplink ? (
              <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5 text-sm text-slate-300">
                No uplink key is bound to this identity yet.
                <div className="mt-2 text-xs text-slate-500">Controller must provision a key before telemetry can bind.</div>
              </div>
            ) : (
              <>
                <div className="mb-4 text-xs tracking-widest text-slate-500">UPLINK: {uplink}</div>

                <div className="mb-6 flex flex-wrap gap-2">
                  <Button asChild variant="outline">
                    <Link to="/nexus/telemetry">Telemetry Stream</Link>
                  </Button>
                  <Button asChild variant="outline">
                    <Link to="/nexus/audit">Audit & Ledger</Link>
                  </Button>
                </div>

                <NexusPanels uplink_key={uplink} />
              </>
            )}
          </EntitlementGate>
        </div>
      </div>
    </div>
  );
}
