import React, { useMemo, useState } from "react";
import { RoleGate } from "@/components/rbac/RoleGate";
import { useAuth } from "@/lib/AuthContext";
import {
  DOC_STATUS,
  transitionCanonDoc,
  upsertCanonDraft,
  validateAndPersistDoctrine,
} from "@/data/publishingPipeline";
import { WHITEPAPERS } from "@/data/whitepaperRegistry";

const StatusPill = ({ s }) => {
  const map = {
    DRAFT: "bg-neutral-800 text-neutral-100",
    REVIEW: "bg-yellow-900/60 text-yellow-200",
    APPROVED: "bg-blue-900/60 text-blue-200",
    PUBLISHED: "bg-green-900/60 text-green-200",
    ARCHIVED: "bg-neutral-900/60 text-neutral-300",
  };
  return (
    <span className={`px-2 py-1 rounded text-xs border border-neutral-700 ${map[s] || map.DRAFT}`}>
      {s}
    </span>
  );
};

const ValidationPill = ({ v }) => {
  const s = (v || "—").toUpperCase();
  const map = {
    PASS: "bg-green-900/60 text-green-200",
    FAIL: "bg-red-900/60 text-red-200",
    "—": "bg-neutral-900/60 text-neutral-300",
  };
  return (
    <span className={`px-2 py-1 rounded text-xs border border-neutral-700 ${map[s] || map["—"]}`}>
      {s}
    </span>
  );
};

export default function GovernancePublishing() {
  const { user } = useAuth();
  const actorRole = user?.role || "unknown";
  const canOverride = actorRole === "admin" || actorRole === "architect";

  const rows = useMemo(
    () =>
      WHITEPAPERS.map((w) => ({
        canon_id: w.id,
        title: w.title,
        tier: w.tier,
        canon_status: w.canon_status,
        canon_version: w.canon_version,
        canon_last_updated: w.canon_last_updated,
        summary: w.summary,
        changelog: w.changelog,
        operator_impact: w.operator_impact,
        canon_role_surface: w.canon_role_surface,
      })),
    []
  );

  const [busy, setBusy] = useState(null);
  const [validation, setValidation] = useState({}); // canon_id -> {status, violations}
  const [showReportFor, setShowReportFor] = useState(null);
  const [override, setOverride] = useState({}); // canon_id -> bool

  const doUpsert = async (r) => {
    setBusy(r.canon_id);
    try {
      await upsertCanonDraft({
        id: r.canon_id,
        title: r.title,
        tier: r.tier || "Public",
        roleSurface: r.canon_role_surface || "Governance",
        summary: r.summary || "",
        operatorImpact: r.operator_impact || "—",
        changelog: r.changelog || "—",
        tags: [],
      });
      alert("Draft synchronized into publishing entity.");
    } catch (e) {
      alert(e?.message || "Failed to upsert draft.");
    } finally {
      setBusy(null);
    }
  };

  const doValidate = async (r) => {
    setBusy(r.canon_id);
    try {
      const { result } = await validateAndPersistDoctrine({
        canon_id: r.canon_id,
        actor_role: actorRole,
        note: "Manual validation from Publishing Console",
      });
      setValidation((p) => ({ ...p, [r.canon_id]: result }));
      setShowReportFor(r.canon_id);
    } catch (e) {
      alert(e?.message || "Validation failed.");
    } finally {
      setBusy(null);
    }
  };

  const doTransition = async (r, toStatus) => {
    setBusy(r.canon_id);
    try {
      await transitionCanonDoc({
        canon_id: r.canon_id,
        toStatus,
        note: `Console transition → ${toStatus}`,
        actor_role: actorRole,
        override_doctrine_guard: Boolean(override?.[r.canon_id] && canOverride),
      });
      alert(`Transitioned to ${toStatus}.`);
    } catch (e) {
      alert(e?.message || "Transition failed.");
    } finally {
      setBusy(null);
    }
  };

  const activeReport = showReportFor ? validation?.[showReportFor] : null;

  return (
    <RoleGate allow={["admin", "architect", "controller"]}>
      <div className="p-6 text-neutral-100">
        <div className="mb-4">
          <h1 className="text-xl font-semibold">Governance — Canon Publishing Console</h1>
          <p className="text-sm text-neutral-300 mt-1">
            Controlled lifecycle + doctrine guardrails for public corridor artifacts.
          </p>
        </div>

        <div className="overflow-x-auto border border-neutral-800 rounded">
          <table className="min-w-full text-sm">
            <thead className="bg-neutral-900 text-neutral-200">
              <tr>
                <th className="text-left p-3">Canon</th>
                <th className="text-left p-3">Status</th>
                <th className="text-left p-3">Doctrine</th>
                <th className="text-left p-3">Last Updated</th>
                <th className="text-left p-3">Controls</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const isBusy = busy === r.canon_id;
                const v = validation?.[r.canon_id];
                return (
                  <tr key={r.canon_id} className="border-t border-neutral-800">
                    <td className="p-3">
                      <div className="font-medium">{r.title}</div>
                      <div className="text-xs text-neutral-400 mt-0.5">{r.canon_id} · {r.canon_version}</div>
                      <div className="text-xs text-neutral-400 mt-1">{r.summary}</div>
                    </td>
                    <td className="p-3"><StatusPill s={r.canon_status} /></td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <ValidationPill v={v?.status} />
                        {v?.status && (
                          <button
                            className="text-xs px-2 py-1 rounded border border-neutral-700 hover:bg-neutral-900"
                            onClick={() => setShowReportFor(r.canon_id)}
                          >
                            View
                          </button>
                        )}
                      </div>
                      {canOverride && (
                        <label className="mt-2 flex items-center gap-2 text-xs text-neutral-300">
                          <input
                            type="checkbox"
                            checked={Boolean(override?.[r.canon_id])}
                            onChange={(e) => setOverride((p) => ({ ...p, [r.canon_id]: e.target.checked }))}
                          />
                          Override doctrine guard (audit logged)
                        </label>
                      )}
                    </td>
                    <td className="p-3 text-neutral-300 text-xs">{r.canon_last_updated}</td>
                    <td className="p-3">
                      <div className="flex flex-wrap gap-2">
                        <button
                          disabled={isBusy}
                          onClick={() => doUpsert(r)}
                          className="px-3 py-1 rounded border border-neutral-700 hover:bg-neutral-900 disabled:opacity-50"
                        >
                          Sync Draft
                        </button>
                        <button
                          disabled={isBusy}
                          onClick={() => doValidate(r)}
                          className="px-3 py-1 rounded border border-neutral-700 hover:bg-neutral-900 disabled:opacity-50"
                        >
                          Validate
                        </button>
                        <button
                          disabled={isBusy}
                          onClick={() => doTransition(r, DOC_STATUS.REVIEW)}
                          className="px-3 py-1 rounded border border-neutral-700 hover:bg-neutral-900 disabled:opacity-50"
                        >
                          → Review
                        </button>
                        <button
                          disabled={isBusy}
                          onClick={() => doTransition(r, DOC_STATUS.APPROVED)}
                          className="px-3 py-1 rounded border border-neutral-700 hover:bg-neutral-900 disabled:opacity-50"
                        >
                          → Approved
                        </button>
                        <button
                          disabled={isBusy}
                          onClick={() => doTransition(r, DOC_STATUS.PUBLISHED)}
                          className="px-3 py-1 rounded border border-neutral-700 hover:bg-neutral-900 disabled:opacity-50"
                        >
                          → Publish
                        </button>
                        <button
                          disabled={isBusy}
                          onClick={() => doTransition(r, DOC_STATUS.ARCHIVED)}
                          className="px-3 py-1 rounded border border-neutral-700 hover:bg-neutral-900 disabled:opacity-50"
                        >
                          Archive
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {activeReport && (
          <div className="mt-6 border border-neutral-800 rounded p-4 bg-neutral-950">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-semibold">Doctrine Report — {showReportFor}</div>
                <div className="text-xs text-neutral-400 mt-1">Inspected preview: {activeReport.inspected_text_preview}</div>
              </div>
              <button
                className="text-xs px-2 py-1 rounded border border-neutral-700 hover:bg-neutral-900"
                onClick={() => setShowReportFor(null)}
              >
                Close
              </button>
            </div>
            <div className="mt-3 grid md:grid-cols-2 gap-3 text-xs">
              <div className="border border-neutral-800 rounded p-3">
                <div className="text-neutral-300 font-medium mb-2">Missing Fields</div>
                <pre className="whitespace-pre-wrap text-neutral-400">{JSON.stringify(activeReport.violations?.missing_fields || [], null, 2)}</pre>
              </div>
              <div className="border border-neutral-800 rounded p-3">
                <div className="text-neutral-300 font-medium mb-2">Missing Boundary</div>
                <pre className="whitespace-pre-wrap text-neutral-400">{JSON.stringify(activeReport.violations?.missing_boundary || [], null, 2)}</pre>
              </div>
              <div className="border border-neutral-800 rounded p-3">
                <div className="text-neutral-300 font-medium mb-2">Prohibited Terms</div>
                <pre className="whitespace-pre-wrap text-neutral-400">{JSON.stringify(activeReport.violations?.prohibited_terms || [], null, 2)}</pre>
              </div>
              <div className="border border-neutral-800 rounded p-3">
                <div className="text-neutral-300 font-medium mb-2">Prohibited Patterns</div>
                <pre className="whitespace-pre-wrap text-neutral-400">{JSON.stringify(activeReport.violations?.prohibited_patterns || [], null, 2)}</pre>
              </div>
            </div>
          </div>
        )}
      </div>
    </RoleGate>
  );
}
