import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function Onboarding() {
  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • ONBOARDING</div>
        <h1 className="mt-2 text-2xl font-semibold">Permission Intake</h1>
        <p className="mt-3 max-w-2xl text-sm text-slate-300">
          Onboarding is routing, not marketing. The objective is to determine the operator’s pathway discipline and
          open a permission request without exposing internal execution surfaces.
        </p>

        <div className="mt-8 grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5">
            <div className="text-xs uppercase tracking-widest text-slate-500">Step 1</div>
            <div className="mt-2 text-lg font-semibold">Pathway Filter</div>
            <p className="mt-2 text-sm text-slate-300">
              A short assessment that routes the operator into a discipline track:
              <span className="text-slate-200"> Academy • Infirmary • Gauntlet</span>.
            </p>
            <div className="mt-4">
              <Button asChild variant="outline">
                <Link to="/pathway/filter">Run Filter</Link>
              </Button>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5">
            <div className="text-xs uppercase tracking-widest text-slate-500">Step 2</div>
            <div className="mt-2 text-lg font-semibold">Request Permission</div>
            <p className="mt-2 text-sm text-slate-300">
              Submit identity + intent for review. Governance roles validate tier, assign role surfaces, and provision an
              uplink key.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button asChild variant="outline">
                <Link to="/access-request">Access Request</Link>
              </Button>
              <Button asChild variant="ghost">
                <Link to="/permission">Permission Framework</Link>
              </Button>
            </div>
          </div>
        </div>

        <div className="mt-10 rounded-2xl border border-slate-800 bg-black/40 p-5">
          <div className="text-xs uppercase tracking-widest text-slate-500">Doctrine</div>
          <div className="mt-2 text-sm text-slate-300">
            Time &gt; Price • Structure &gt; Pattern • Volatility &gt; Direction • Permission &gt; Opportunity
          </div>
        </div>
      </div>
    </div>
  );
}
