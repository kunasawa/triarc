import React from "react";
import { Link, useLocation } from "react-router-dom";
import { getWhitepaperById } from "@/data/whitepaperRegistry";
import CanonHeader from "@/components/canon/CanonHeader";
import { canViewArtifact, deriveRollout, SURFACE } from "@/data/rolloutPolicy";

function useQuery() {
  const { search } = useLocation();
  return React.useMemo(() => new URLSearchParams(search), [search]);
}

const Panel = ({ title, children }) => (
  <div className="rounded-xl border border-slate-800 bg-slate-950 p-5">
    <div className="text-sm font-medium text-slate-200">{title}</div>
    <div className="mt-2 text-sm text-slate-300 leading-relaxed">{children}</div>
  </div>
);

export default function PublicWhitepaperView() {
  const q = useQuery();
  const docId = q.get("doc") || "";
  const wp = getWhitepaperById(docId);
  const permitted = wp ? canViewArtifact({ user: null, doc: wp, surface: SURFACE.PUBLIC }) : false;

  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-4xl px-6 py-10">
        <header className="flex items-start justify-between gap-4 border-b border-slate-800 pb-6">
          <div>
            <div className="text-xs tracking-widest text-slate-400">TRIARC ECOSYSTEMS</div>
            <div className="mt-1 text-2xl font-semibold">{wp ? wp.title : "Whitepaper"}</div>
            <div className="mt-2 text-sm text-slate-300">
              {wp ? `Document ID: ${wp.id}` : "Document not found."}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link className="rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-200 hover:bg-slate-900" to="/public/whitepapers">
              Corridor
            </Link>
            <Link className="rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-200 hover:bg-slate-900" to="/permission">
              Permission
            </Link>
          </div>
        </header>

        {!wp || !permitted ? (
          <div className="mt-8 text-sm text-slate-300">Return to the corridor to select a valid document.</div>
        ) : (
          <div className="mt-8 grid gap-4">
            {(() => {
              const ro = deriveRollout({ ...wp, tier: wp.tier || "PUBLIC" });
              return (
            <CanonHeader
              name={wp.title}
              version={wp.canon_version || `${wp.id}.v1`}
              status={wp.canon_status || "PUBLISHED"}
              tier={wp.tier || "Public"}
              roleSurface={wp.canon_role_surface || "Public Corridor / Governance"}
              lastUpdated={wp.canon_last_updated || "—"}
              changelog={wp.changelog || "—"}
              operatorImpact={wp.operator_impact || "—"}
              rolloutSurface={ro.surface}
              rolloutStage={ro.stage}
            />
              );
            })()}

            <Panel title="Abstract">{wp.summary}</Panel>

            <Panel title="Doctrinal Boundaries">
              This whitepaper is published as institutional doctrine. It is not a signal service, does not contain trade instructions,
              and does not substitute for governed permission. Operators engage only when permission is active.
            </Panel>

            <Panel title="Key Claims (Non-Exhaustive)">
              <ul className="list-disc pl-5 space-y-2">
                <li>Markets are environments; structure is the map. Pattern recognition is secondary to context.</li>
                <li>Volatility defines range and risk; direction is a consequence, not a target.</li>
                <li>Permission precedes opportunity. Governance overrides impulse.</li>
                <li>Weekly classification governs posture; execution is conditional and auditable.</li>
              </ul>
            </Panel>

            <Panel title="Next Step">
              If you require operational access, proceed through the Permission surface.
              Access is gated by identity, pathway routing, and governance review.
              <div className="mt-3 flex gap-2">
                <Link className="rounded-lg border border-slate-800 bg-black px-3 py-2 text-xs text-slate-200 hover:bg-slate-900" to="/access-request">
                  Submit Access Request
                </Link>
                <Link className="rounded-lg border border-slate-800 bg-black px-3 py-2 text-xs text-slate-200 hover:bg-slate-900" to="/onboarding">
                  Begin Onboarding
                </Link>
              </div>
            </Panel>

            {wp.source_url ? (
              <Panel title="Canonical Source (When Available)">
                This corridor view is summarized. If a canonical source is published for this artifact, it will be served here:
                <div className="mt-3 break-all rounded-lg border border-slate-800 bg-black/30 p-3 text-xs text-slate-200">
                  {wp.source_url}
                </div>
              </Panel>
            ) : null}
          </div>
        )}

        <footer className="mt-10 border-t border-slate-800 pt-6 text-xs text-slate-500">
          TriArc doctrine is versioned. Internal artifacts are distributed through the controlled publishing pipeline.
        </footer>
      </div>
    </div>
  );
}
