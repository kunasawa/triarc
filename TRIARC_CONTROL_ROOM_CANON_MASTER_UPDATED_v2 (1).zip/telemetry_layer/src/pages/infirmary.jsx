import React from 'react';
import PathwayHub from '@/components/PathwayHub';

export default function Infirmary() {
  return <PathwayHub pathway="infirmary" />;
}
