import React from "react";
import { useAuth } from "@/lib/AuthContext";
import { Link } from "react-router-dom";

export default function Pathway() {
  const { user } = useAuth();
  const pathway = (user?.pathway || "").toString().toLowerCase();

  const label = pathway ? pathway.toUpperCase() : "UNDECLARED";

  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • PATHWAY SURFACE</div>
        <h1 className="mt-2 text-2xl font-semibold">Pathway</h1>
        <p className="mt-3 max-w-2xl text-sm text-slate-300">
          This surface routes the operator into their assigned discipline track. Pathways are training and governance.
        </p>

        <div className="mt-8 rounded-2xl border border-slate-800 bg-slate-950 p-5">
          <div className="text-xs uppercase tracking-widest text-slate-500">Assigned Pathway</div>
          <div className="mt-2 text-lg font-semibold">{label}</div>
          <div className="mt-2 text-sm text-slate-300">
            Academy • Infirmary • Gauntlet (Engineer). This page becomes the dispatcher into modules once the academy
            library is connected.
          </div>

          <div className="mt-5 flex flex-wrap gap-3">
            <Link
              to="/academy"
              className={`rounded-xl border px-4 py-2 text-xs font-semibold tracking-widest ${
                pathway === "academy"
                  ? "border-emerald-700 bg-emerald-950/40 text-emerald-200"
                  : "border-slate-700 bg-black/30 text-slate-200 hover:bg-slate-900"
              }`}
            >
              ACADEMY
            </Link>
            <Link
              to="/infirmary"
              className={`rounded-xl border px-4 py-2 text-xs font-semibold tracking-widest ${
                pathway === "infirmary"
                  ? "border-amber-700 bg-amber-950/30 text-amber-200"
                  : "border-slate-700 bg-black/30 text-slate-200 hover:bg-slate-900"
              }`}
            >
              INFIRMARY
            </Link>
            <Link
              to="/gauntlet"
              className={`rounded-xl border px-4 py-2 text-xs font-semibold tracking-widest ${
                pathway === "gauntlet"
                  ? "border-sky-700 bg-sky-950/30 text-sky-200"
                  : "border-slate-700 bg-black/30 text-slate-200 hover:bg-slate-900"
              }`}
            >
              GAUNTLET
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
