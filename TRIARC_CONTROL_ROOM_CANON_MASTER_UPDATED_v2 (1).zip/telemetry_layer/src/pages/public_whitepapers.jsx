import React from "react";
import { Link } from "react-router-dom";
import { WHITEPAPERS } from "@/data/whitepaperRegistry";
import { canViewArtifact, SURFACE } from "@/data/rolloutPolicy";

const Card = ({ title, summary, tags, canon_version, canon_status, tier }) => (
  <div className="rounded-xl border border-slate-800 bg-slate-950 p-5">
    <div className="flex flex-wrap items-start justify-between gap-3">
      <div className="text-sm font-medium text-slate-200">{title}</div>
      <div className="text-right text-[11px] text-slate-400">
        <div>{canon_status || "PUBLISHED"}</div>
        <div className="text-slate-500">{canon_version || "—"}</div>
        <div className="text-slate-600">{tier || "Public"}</div>
      </div>
    </div>
    <div className="mt-2 text-sm text-slate-300 leading-relaxed">{summary}</div>
    <div className="mt-3 flex flex-wrap gap-2">
      {tags?.map((t) => (
        <span key={t} className="rounded-full border border-slate-800 bg-black px-2 py-0.5 text-[11px] text-slate-400">
          {t}
        </span>
      ))}
    </div>
  </div>
);

export default function PublicWhitepapers() {
  const visible = WHITEPAPERS.filter((w) => canViewArtifact({ user: null, doc: w, surface: SURFACE.PUBLIC }));

  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-5xl px-6 py-10">
        <header className="flex items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <div>
            <div className="text-xs tracking-widest text-slate-400">TRIARC ECOSYSTEMS</div>
            <div className="mt-1 text-2xl font-semibold">Whitepaper Corridor</div>
            <div className="mt-2 max-w-3xl text-sm text-slate-300 leading-relaxed">
              Public doctrine distribution surface. These documents describe environmental governance.
              They do not provide execution instructions, signals, or trade advice.
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link className="rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-200 hover:bg-slate-900" to="/permission">
              Permission
            </Link>
            <Link className="rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-200 hover:bg-slate-900" to="/access-request">
              Access Request
            </Link>
          </div>
        </header>

        <div className="mt-8 grid gap-4">
          {visible.map((w) => (
            <Link key={w.id} to={`/public/whitepapers/view?doc=${encodeURIComponent(w.id)}`} className="block">
              <Card
                title={w.title}
                summary={w.summary}
                tags={w.tags}
                canon_version={w.canon_version}
                canon_status={w.canon_status}
                tier={w.tier}
              />
            </Link>
          ))}
        </div>

        <footer className="mt-10 border-t border-slate-800 pt-6 text-xs text-slate-500">
          TriArc publishes doctrine under version control. For operational access, proceed through Permission.
        </footer>
      </div>
    </div>
  );
}
