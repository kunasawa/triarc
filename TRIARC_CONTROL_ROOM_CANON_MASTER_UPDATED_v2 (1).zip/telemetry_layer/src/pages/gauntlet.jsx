import React from 'react';
import PathwayHub from '@/components/PathwayHub';

export default function Gauntlet() {
  return <PathwayHub pathway="gauntlet" />;
}
