import React, { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useIdentity, useNexusEvents, useNexusLiveFleet } from "@/data/hooks";
import { TELEMETRY_EVENTS } from "@/data/contracts";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

function safeJsonParse(v) {
  try {
    if (v == null) return null;
    if (typeof v === "object") return v;
    return JSON.parse(v);
  } catch {
    return null;
  }
}

function normalizeRawEvent(ev) {
  const payload =
    ev?.payload ??
    safeJsonParse(ev?.payload_json) ??
    safeJsonParse(ev?.payloadJson) ??
    null;

  const meta = payload?.meta ?? {};
  const gov = payload?.governance ?? {};
  const servo = payload?.servo ?? {};
  const opp = payload?.opportunity ?? {};

  const ts =
    ev?.event_time_ms ??
    ev?.timestamp_ms ??
    meta?.event_time_ms ??
    null;

  return {
    id: ev?.id ?? `${ev?.uplink_key ?? "—"}:${ts ?? "—"}:${ev?.event_type ?? "—"}`,
    uplink_key: ev?.uplink_key ?? "—",
    event_type: ev?.event_type ?? "—",
    event_time_ms: ts,
    symbol: ev?.symbol ?? meta?.symbol ?? "—",
    tf: ev?.tf ?? meta?.tf ?? "—",
    gov_state: gov?.gov_state ?? "—",
    is_permitted: gov?.is_permitted ?? null,
    denial_reason: gov?.denial_reason ?? "—",
    sentinel_state: gov?.sentinel_state ?? null,
    wk_type: gov?.wk_type ?? "—",
    wk_confidence: gov?.wk_confidence ?? null,
    matrix_healthy: gov?.matrix_healthy ?? null,
    navigator_bias: gov?.navigator_bias ?? "—",
    servo_decision: servo?.servo_decision ?? "—",
    servo_reason: servo?.servo_reason ?? "—",
    risk_multiplier: servo?.risk_multiplier ?? null,
    env_cap: servo?.env_cap ?? null,
    opp_active: opp?.active ?? null,
    opp_side: opp?.side ?? "—",
    opp_name: opp?.name ?? "—",
    opp_score: opp?.score ?? null,
  };
}

const roleAllowsFleet = (role) => {
  const r = String(role ?? "").toLowerCase();
  return ["admin", "controller", "architect", "warden"].some((k) => r.includes(k));
};

export default function NexusTelemetry() {
  const [searchParams] = useSearchParams();
  const idQ = useIdentity();
  const role = idQ.data?.role;
  const myUplink = idQ.data?.uplink_key ?? null;
  const canFleet = roleAllowsFleet(role);

  const [uplinkOverride, setUplinkOverride] = useState("");
  const [initDone, setInitDone] = useState(false);
  const uplink = canFleet ? (uplinkOverride.trim() || myUplink) : myUplink;

  const [eventType, setEventType] = useState(TELEMETRY_EVENTS.STATE_SNAPSHOT);

  // Optional deep-linking: /nexus/telemetry?uplink=...&event=STATE_SNAPSHOT
  useEffect(() => {
    if (initDone) return;
    const u = (searchParams.get("uplink") || "").trim();
    const ev = (searchParams.get("event") || "").trim();
    if (canFleet && u) setUplinkOverride(u);
    if (ev && TELEMETRY_EVENTS[ev]) setEventType(TELEMETRY_EVENTS[ev]);
    setInitDone(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initDone, canFleet]);

  const eventsQ = useNexusEvents({
    uplink_key: uplink,
    event_type: eventType,
    limit: 60,
  });

  const fleetQ = useNexusLiveFleet(200);

  const rows = useMemo(() => {
    const raw = eventsQ.data ?? [];
    return raw.map(normalizeRawEvent);
  }, [eventsQ.data]);

  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • EXECUTION SPINE</div>
        <h1 className="mt-2 text-2xl font-semibold">Nexus Telemetry</h1>
        <p className="mt-3 max-w-3xl text-sm text-slate-300">
          Live telemetry stream from Nexus alert envelopes (STATE_SNAPSHOT + opportunity events). This is a
          governance console, not an execution feed.
        </p>

        <div className="mt-8 grid gap-4 md:grid-cols-3">
          <Card className="bg-slate-950 border-slate-800 md:col-span-2">
            <CardHeader>
              <CardTitle className="text-base">Stream Controls</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={eventType === TELEMETRY_EVENTS.STATE_SNAPSHOT ? "default" : "outline"}
                  onClick={() => setEventType(TELEMETRY_EVENTS.STATE_SNAPSHOT)}
                >
                  STATE_SNAPSHOT
                </Button>
                <Button
                  variant={eventType === TELEMETRY_EVENTS.OPPORTUNITY_CREATED ? "default" : "outline"}
                  onClick={() => setEventType(TELEMETRY_EVENTS.OPPORTUNITY_CREATED)}
                >
                  OPPORTUNITY_CREATED
                </Button>
                <Button
                  variant={eventType === TELEMETRY_EVENTS.OPPORTUNITY_UPDATED ? "default" : "outline"}
                  onClick={() => setEventType(TELEMETRY_EVENTS.OPPORTUNITY_UPDATED)}
                >
                  OPPORTUNITY_UPDATED
                </Button>
                <Button
                  variant={eventType === TELEMETRY_EVENTS.OPPORTUNITY_CLEARED ? "default" : "outline"}
                  onClick={() => setEventType(TELEMETRY_EVENTS.OPPORTUNITY_CLEARED)}
                >
                  OPPORTUNITY_CLEARED
                </Button>
              </div>

              <div className="mt-4 grid gap-3 md:grid-cols-2">
                <div className="rounded-2xl border border-slate-800 bg-black/40 p-4">
                  <div className="text-xs tracking-widest text-slate-500">BOUND IDENTITY</div>
                  <div className="mt-2 text-sm text-slate-200">
                    <div>Role: <span className="text-slate-100">{role ?? "—"}</span></div>
                    <div className="mt-1">Uplink: <span className="text-slate-100">{myUplink ?? "—"}</span></div>
                  </div>
                </div>

                <div className="rounded-2xl border border-slate-800 bg-black/40 p-4">
                  <div className="text-xs tracking-widest text-slate-500">STREAM BINDING</div>
                  <div className="mt-2 text-sm text-slate-200">
                    {canFleet ? (
                      <>
                        <div className="text-xs text-slate-400">Fleet roles may bind to any uplink.</div>
                        <div className="mt-2 flex gap-2">
                          <Input
                            value={uplinkOverride}
                            onChange={(e) => setUplinkOverride(e.target.value)}
                            placeholder="Override uplink key (optional)"
                            className="bg-slate-950 border-slate-800"
                          />
                        </div>
                      </>
                    ) : (
                      <div className="text-xs text-slate-400">
                        Operator view is bound to your uplink only.
                      </div>
                    )}
                    <div className="mt-2 text-xs tracking-widest text-slate-500">ACTIVE BIND: {uplink ?? "—"}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-950 border-slate-800">
            <CardHeader>
              <CardTitle className="text-base">Fleet Pulse</CardTitle>
            </CardHeader>
            <CardContent>
              {!canFleet ? (
                <div className="text-xs text-slate-400">Restricted. Fleet pulse requires Controller/Warden/Architect.</div>
              ) : fleetQ.isLoading ? (
                <div className="text-xs text-slate-400">Loading…</div>
              ) : (
                <div className="space-y-2">
                  {(fleetQ.data ?? []).slice(0, 8).map((s) => (
                    <div key={s.id} className="rounded-xl border border-slate-800 bg-black/30 p-3">
                      <div className="text-xs text-slate-300">{s.uplink_key}</div>
                      <div className="mt-1 text-xs text-slate-500">{s.symbol_id ?? s.symbol ?? "—"} • {s.tf ?? "—"}</div>
                      <div className="mt-1 text-xs text-slate-400">{s.gov_state ?? "—"} • {String(s.is_permitted ?? "—")}</div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-950 p-5">
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="text-xs tracking-widest text-slate-500">EVENTS</div>
              <div className="mt-1 text-sm text-slate-200">{eventType}</div>
            </div>
            <div className="text-xs text-slate-400">
              {eventsQ.isFetching ? "Refreshing…" : rows.length ? `${rows.length} rows` : "—"}
            </div>
          </div>

          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="text-slate-400">
                <tr className="border-b border-slate-800">
                  <th className="py-2 pr-3">Time (ms)</th>
                  <th className="py-2 pr-3">Symbol</th>
                  <th className="py-2 pr-3">TF</th>
                  <th className="py-2 pr-3">Governance</th>
                  <th className="py-2 pr-3">Permission</th>
                  <th className="py-2 pr-3">Load</th>
                  <th className="py-2 pr-3">Opportunity</th>
                </tr>
              </thead>
              <tbody className="text-slate-200">
                {rows.map((r) => (
                  <tr key={r.id} className="border-b border-slate-900 align-top">
                    <td className="py-2 pr-3 text-slate-400">{r.event_time_ms ?? "—"}</td>
                    <td className="py-2 pr-3">{r.symbol}</td>
                    <td className="py-2 pr-3 text-slate-300">{r.tf}</td>
                    <td className="py-2 pr-3">
                      <div>{r.gov_state}</div>
                      <div className="text-slate-500">WK: {r.wk_type} {r.wk_confidence != null ? `(${r.wk_confidence}%)` : ""}</div>
                    </td>
                    <td className="py-2 pr-3">
                      <div>{r.is_permitted == null ? "—" : (r.is_permitted ? "PERMITTED" : "RESTRICTED")}</div>
                      <div className="text-slate-500">{r.denial_reason}</div>
                    </td>
                    <td className="py-2 pr-3">
                      <div>{r.servo_decision}</div>
                      <div className="text-slate-500">{r.risk_multiplier != null ? `${r.risk_multiplier}x` : "—"}</div>
                    </td>
                    <td className="py-2 pr-3">
                      <div>{r.opp_active ? `${r.opp_side} • ${r.opp_name}` : "—"}</div>
                      <div className="text-slate-500">{r.opp_score != null ? `Score: ${r.opp_score}%` : ""}</div>
                    </td>
                  </tr>
                ))}
                {!rows.length && (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-500">
                      No telemetry rows yet for this uplink/event type.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
