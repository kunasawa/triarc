import React, { useMemo, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { submitPathwayAssessment } from "@/data/outreach";

function labelRisk(risk) {
  switch ((risk || "").toString()) {
    case "PERFORMANCE_CHASER":
      return "Performance Chaser";
    case "ASPIRING_PRO":
      return "Aspiring Professional";
    case "BURNT_OUT_VETERAN":
      return "Burnt-out Veteran";
    case "ENGINEER":
      return "Engineer";
    case "DISCIPLINED_OPERATOR":
      return "Disciplined Operator";
    default:
      return "Unclassified";
  }
}

function labelPathway(pathway) {
  switch ((pathway || "").toString()) {
    case "ACADEMY":
      return "Academy";
    case "INFIRMARY":
      return "Infirmary";
    case "GAUNTLET":
      return "Gauntlet";
    default:
      return "Undeclared";
  }
}

export default function PathwayResult() {
  const loc = useLocation();
  const nav = useNavigate();

  const state = loc.state || {};
  const recommended_pathway = state.recommended_pathway || "ACADEMY";
  const risk_profile = state.risk_profile || "ASPIRING_PRO";
  const answers_json = state.answers_json || null;

  const [name, setName] = useState(state.name || "");
  const [email, setEmail] = useState(state.email || "");
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);
  const [ok, setOk] = useState(false);
  const [err, setErr] = useState("");

  const doctrine = useMemo(() => {
    if (recommended_pathway === "INFIRMARY") {
      return {
        headline: "Stability before expansion.",
        sub: "You are routed to rehabilitation doctrine: consistency, recovery, and permission discipline.",
      };
    }
    if (recommended_pathway === "GAUNTLET") {
      return {
        headline: "Systems, constraints, and accountability.",
        sub: "You are routed to engineered discipline: tooling, governance, and high-integrity repetition.",
      };
    }
    return {
      headline: "Foundation first.",
      sub: "You are routed to apprenticeship doctrine: environment mapping and permission discipline.",
    };
  }, [recommended_pathway]);

  async function submit() {
    setBusy(true);
    setErr("");
    setOk(false);
    try {
      await submitPathwayAssessment({
        name,
        email,
        experience: state.experience || "",
        pathway_hint: recommended_pathway,
        risk_profile,
        notes,
        answers_json,
      });
      setOk(true);
    } catch (e) {
      setErr(e?.message || "Unable to submit request.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • PATHWAY ASSESSMENT</div>
        <h1 className="mt-2 text-2xl font-semibold">Recommendation</h1>

        <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-950 p-5">
          <div className="text-xs uppercase tracking-widest text-slate-500">Assigned Pathway</div>
          <div className="mt-2 text-2xl font-semibold">{labelPathway(recommended_pathway)}</div>
          <div className="mt-2 text-sm text-slate-300">Risk profile: {labelRisk(risk_profile)}</div>
          <div className="mt-4 text-sm text-slate-200">
            <div className="font-semibold">{doctrine.headline}</div>
            <div className="mt-1 text-slate-300">{doctrine.sub}</div>
          </div>

          <div className="mt-6 grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-xs uppercase tracking-widest text-slate-500">Name</div>
              <Input className="mt-2" value={name} onChange={(e) => setName(e.target.value)} placeholder="Operator name" />
            </div>
            <div>
              <div className="text-xs uppercase tracking-widest text-slate-500">Email</div>
              <Input
                className="mt-2"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="operator@domain.com"
              />
            </div>
          </div>

          <div className="mt-4">
            <div className="text-xs uppercase tracking-widest text-slate-500">Notes (optional)</div>
            <Textarea
              className="mt-2"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Context, constraints, or concerns."
              rows={4}
            />
          </div>

          {err ? <div className="mt-4 text-sm text-red-300">{err}</div> : null}
          {ok ? (
            <div className="mt-4 rounded-xl border border-emerald-900 bg-emerald-950/40 p-3 text-sm text-emerald-200">
              Submitted. Governance will review and respond.
            </div>
          ) : null}

          <div className="mt-6 flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => nav("/pathway/filter")}>
              Re-run Filter
            </Button>
            <Button onClick={submit} disabled={busy || !email}>
              {busy ? "Submitting…" : "Request Permission"}
            </Button>
            <Button asChild variant="ghost">
              <Link to="/public/doctrine">Read Doctrine</Link>
            </Button>
          </div>
        </div>

        <div className="mt-10 text-xs text-slate-500">
          Time &gt; Price • Structure &gt; Pattern • Volatility &gt; Direction • Permission &gt; Opportunity
        </div>
      </div>
    </div>
  );
}
