import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { submitPathwayAssessment } from "@/data/outreach";

const PATHWAY = {
  ACADEMY: "ACADEMY",
  INFIRMARY: "INFIRMARY",
  GAUNTLET: "GAUNTLET",
};

const RISK_PROFILE = {
  PERFORMANCE_CHASER: "PERFORMANCE_CHASER",
  ASPIRING_PRO: "ASPIRING_PRO",
  BURNT_OUT_VETERAN: "BURNT_OUT_VETERAN",
  ENGINEER: "ENGINEER",
  DISCIPLINED_OPERATOR: "DISCIPLINED_OPERATOR",
};

function scoreToProfile(scores) {
  // Pick the max; ties prefer safer tracks (Infirmary > Academy > Gauntlet) only if close.
  const entries = Object.entries(scores);
  entries.sort((a, b) => (b[1] ?? 0) - (a[1] ?? 0));
  return entries?.[0]?.[0] ?? RISK_PROFILE.ASPIRING_PRO;
}

function profileToPathway(profile) {
  if (profile === RISK_PROFILE.BURNT_OUT_VETERAN) return PATHWAY.INFIRMARY;
  if (profile === RISK_PROFILE.ENGINEER || profile === RISK_PROFILE.DISCIPLINED_OPERATOR) return PATHWAY.GAUNTLET;
  return PATHWAY.ACADEMY;
}

export default function PathwayFilter() {
  const nav = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [experience, setExperience] = useState("");

  const [q1, setQ1] = useState("");
  const [q2, setQ2] = useState("");
  const [q3, setQ3] = useState("");
  const [q4, setQ4] = useState("");
  const [q5, setQ5] = useState("");

  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const scores = useMemo(() => {
    const s = {
      [RISK_PROFILE.PERFORMANCE_CHASER]: 0,
      [RISK_PROFILE.ASPIRING_PRO]: 0,
      [RISK_PROFILE.BURNT_OUT_VETERAN]: 0,
      [RISK_PROFILE.ENGINEER]: 0,
      [RISK_PROFILE.DISCIPLINED_OPERATOR]: 0,
    };

    // Q1: primary motive
    if (q1 === "fast") s[RISK_PROFILE.PERFORMANCE_CHASER] += 3;
    if (q1 === "professional") s[RISK_PROFILE.ASPIRING_PRO] += 3;
    if (q1 === "stability") s[RISK_PROFILE.DISCIPLINED_OPERATOR] += 2;
    if (q1 === "systems") s[RISK_PROFILE.ENGINEER] += 2;

    // Q2: current condition
    if (q2 === "burnout") s[RISK_PROFILE.BURNT_OUT_VETERAN] += 4;
    if (q2 === "inconsistent") s[RISK_PROFILE.ASPIRING_PRO] += 2;
    if (q2 === "consistent") s[RISK_PROFILE.DISCIPLINED_OPERATOR] += 2;

    // Q3: relationship with rules
    if (q3 === "ignore") s[RISK_PROFILE.PERFORMANCE_CHASER] += 3;
    if (q3 === "learning") s[RISK_PROFILE.ASPIRING_PRO] += 2;
    if (q3 === "follow") s[RISK_PROFILE.DISCIPLINED_OPERATOR] += 3;
    if (q3 === "design") s[RISK_PROFILE.ENGINEER] += 4;

    // Q4: response under volatility
    if (q4 === "push") s[RISK_PROFILE.PERFORMANCE_CHASER] += 3;
    if (q4 === "freeze") s[RISK_PROFILE.BURNT_OUT_VETERAN] += 3;
    if (q4 === "reduce") s[RISK_PROFILE.DISCIPLINED_OPERATOR] += 2;
    if (q4 === "measure") s[RISK_PROFILE.ENGINEER] += 2;

    // Q5: why TriArc
    if (q5 === "permission") s[RISK_PROFILE.DISCIPLINED_OPERATOR] += 2;
    if (q5 === "structure") s[RISK_PROFILE.ASPIRING_PRO] += 2;
    if (q5 === "edge") s[RISK_PROFILE.PERFORMANCE_CHASER] += 2;
    if (q5 === "engineering") s[RISK_PROFILE.ENGINEER] += 2;

    return s;
  }, [q1, q2, q3, q4, q5]);

  const risk_profile = useMemo(() => scoreToProfile(scores), [scores]);
  const pathway = useMemo(() => profileToPathway(risk_profile), [risk_profile]);

  const ready = email.trim().length > 3 && q1 && q2 && q3 && q4 && q5;

  async function onSubmit() {
    setErr("");
    if (!ready) {
      setErr("Complete the filter inputs before submitting.");
      return;
    }

    setBusy(true);
    try {
      const answers_json = {
        q1,
        q2,
        q3,
        q4,
        q5,
        computed: { risk_profile, pathway, scores },
      };

      await submitPathwayAssessment({
        name,
        email,
        experience,
        pathway_hint: pathway,
        risk_profile,
        notes,
        answers_json,
      });

      nav("/pathway/result", {
        state: {
          name,
          email,
          pathway,
          risk_profile,
          notes,
        },
      });
    } catch (e) {
      setErr(e?.message || "Submission failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-3xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • PATHWAY FILTER</div>
        <h1 className="mt-2 text-2xl font-semibold">Psychometric Routing</h1>
        <p className="mt-3 text-sm text-slate-300">
          This filter is not a sales funnel. It produces a discipline recommendation and creates a permission-intake
          record for governance review.
        </p>

        <div className="mt-8 grid gap-4 rounded-2xl border border-slate-800 bg-slate-950 p-5">
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-xs uppercase tracking-widest text-slate-500">Name (optional)</div>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Operator" />
            </div>
            <div>
              <div className="text-xs uppercase tracking-widest text-slate-500">Email</div>
              <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@domain.com" />
            </div>
          </div>

          <div>
            <div className="text-xs uppercase tracking-widest text-slate-500">Experience (optional)</div>
            <Input
              value={experience}
              onChange={(e) => setExperience(e.target.value)}
              placeholder="New • 1-2y • 3-5y • 5y+"
            />
          </div>

          <div className="mt-2 text-xs uppercase tracking-widest text-slate-500">Filter Questions</div>

          <div className="grid gap-3">
            <Question
              title="1) Primary motive"
              value={q1}
              onChange={setQ1}
              options={[
                ["fast", "Fast performance (I want results now)"],
                ["professional", "Professional mastery (I want a long-term craft)"],
                ["stability", "Stability (I want controlled exposure + consistency)"],
                ["systems", "Systems (I want to build and optimize a process)"],
              ]}
            />

            <Question
              title="2) Current condition"
              value={q2}
              onChange={setQ2}
              options={[
                ["inconsistent", "Inconsistent execution"],
                ["consistent", "Consistent but seeking higher precision"],
                ["burnout", "Burnt out / emotionally compromised"],
              ]}
            />

            <Question
              title="3) Relationship with rules"
              value={q3}
              onChange={setQ3}
              options={[
                ["ignore", "I override rules when I feel confident"],
                ["learning", "I want rules but I break them under stress"],
                ["follow", "I follow rules and want stronger governance"],
                ["design", "I design rules, instrumentation, and feedback loops"],
              ]}
            />

            <Question
              title="4) Response under volatility"
              value={q4}
              onChange={setQ4}
              options={[
                ["push", "I push harder and increase frequency"],
                ["freeze", "I freeze / revenge / spiral"],
                ["reduce", "I downshift and reduce load"],
                ["measure", "I observe, measure, and adapt systematically"],
              ]}
            />

            <Question
              title="5) Why TriArc"
              value={q5}
              onChange={setQ5}
              options={[
                ["permission", "Permission + governance constraints"],
                ["structure", "Structure and environment mapping"],
                ["edge", "Setups / edge (I want the play)"],
                ["engineering", "Instrumentation and system building"],
              ]}
            />
          </div>

          <div className="mt-3 grid gap-3 md:grid-cols-2">
            <div className="rounded-xl border border-slate-800 bg-black/40 p-4">
              <div className="text-xs uppercase tracking-widest text-slate-500">Computed Risk Profile</div>
              <div className="mt-2 text-lg font-semibold">{risk_profile.replaceAll("_", " ")}</div>
            </div>
            <div className="rounded-xl border border-slate-800 bg-black/40 p-4">
              <div className="text-xs uppercase tracking-widest text-slate-500">Recommended Pathway</div>
              <div className="mt-2 text-lg font-semibold">{pathway}</div>
            </div>
          </div>

          <div>
            <div className="text-xs uppercase tracking-widest text-slate-500">Notes (optional)</div>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Anything governance should know."
              rows={4}
            />
          </div>

          {err ? <div className="text-sm text-red-400">{err}</div> : null}

          <div className="mt-2 flex flex-wrap gap-2">
            <Button variant="outline" onClick={onSubmit} disabled={!ready || busy}>
              {busy ? "Submitting…" : "Submit Filter"}
            </Button>
            <Button variant="ghost" onClick={() => nav("/onboarding")}>
              Back
            </Button>
          </div>

          <div className="text-xs text-slate-500">
            Execution is never promised. This only creates an intake record for review.
          </div>
        </div>
      </div>
    </div>
  );
}

function Question({ title, value, onChange, options = [] }) {
  return (
    <div className="rounded-xl border border-slate-800 bg-black/30 p-4">
      <div className="text-sm font-semibold">{title}</div>
      <div className="mt-3 grid gap-2">
        {options.map(([k, label]) => (
          <label key={k} className="flex cursor-pointer items-start gap-2 text-sm text-slate-200">
            <input
              type="radio"
              name={title}
              value={k}
              checked={value === k}
              onChange={(e) => onChange(e.target.value)}
              className="mt-1"
            />
            <span className="leading-5">{label}</span>
          </label>
        ))}
      </div>
    </div>
  );
}
