import React from 'react';
import AppShell from '@/components/controlroom/AppShell';
import IncidentConsole from '@/components/governance/IncidentConsole';

export default function GovernanceIncidentsPage() {
  return (
    <AppShell>
      <div className="mx-auto w-full max-w-6xl px-4 py-8">
        <IncidentConsole />
      </div>
    </AppShell>
  );
}
