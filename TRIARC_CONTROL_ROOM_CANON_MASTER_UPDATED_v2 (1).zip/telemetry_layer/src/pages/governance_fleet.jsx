import React from "react";
import { Link } from "react-router-dom";
import RoleGate from "@/components/rbac/RoleGate";
import FleetTelemetryConsole from "@/components/governance/FleetTelemetryConsole";

export default function GovernanceFleet() {
  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • GOVERNANCE SURFACE</div>
        <h1 className="mt-2 text-2xl font-semibold">Fleet Telemetry</h1>
        <p className="mt-3 max-w-3xl text-sm text-slate-300">
          Fleet-level Nexus state snapshots. This surface is governance-only: visibility, audit context, and
          permission enforcement — never trade instruction.
        </p>

        <div className="mt-6 flex flex-wrap gap-2">
          <Link
            to="/governance"
            className="rounded-xl border border-slate-700 bg-black/30 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-black/50"
          >
            BACK TO GOVERNANCE
          </Link>
          <Link
            to="/nexus/telemetry"
            className="rounded-xl border border-slate-700 bg-black/30 px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-black/50"
          >
            NEXUS TELEMETRY
          </Link>
        </div>

        <RoleGate
          allow={["warden", "controller", "admin", "architect"]}
          fallback={
            <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-950 p-5 text-sm text-slate-300">
              Access restricted. Fleet telemetry is reserved for governance roles.
            </div>
          }
        >
          <div className="mt-6">
            <FleetTelemetryConsole />
          </div>
        </RoleGate>
      </div>
    </div>
  );
}
