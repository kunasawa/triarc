import React from "react";
import RoleGate from "@/components/rbac/RoleGate";
import ArchitectureConsole from "@/components/governance/ArchitectureConsole";

export default function Architecture() {
  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • ARCHITECTURE</div>
        <h1 className="mt-2 text-2xl font-semibold">Architecture</h1>
        <p className="mt-3 max-w-2xl text-sm text-slate-300">
          Canon vault: schemas, changelogs, and controlled rollouts. This is an engineering surface.
        </p>

        <RoleGate
          allow={["architect", "admin"]}
          fallback={
            <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-950 p-5 text-sm text-slate-300">
              Access restricted. Architecture surfaces are reserved for Architects.
            </div>
          }
        >
          <div className="mt-6">
            <ArchitectureConsole />
          </div>
        </RoleGate>
      </div>
    </div>
  );
}
