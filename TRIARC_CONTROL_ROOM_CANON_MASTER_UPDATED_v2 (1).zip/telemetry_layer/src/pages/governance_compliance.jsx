import React from "react";
import { useSearchParams } from "react-router-dom";
import RoleGate from "@/components/rbac/RoleGate";
import ComplianceConsole from "@/components/governance/ComplianceConsole";

export default function GovernanceCompliance() {
  const [searchParams] = useSearchParams();
  const uplink = (searchParams.get("uplink") || "").trim();

  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • GOVERNANCE SURFACE</div>
        <h1 className="mt-2 text-2xl font-semibold">Compliance</h1>

        <RoleGate
          allow={["warden", "controller", "admin", "architect"]}
          fallback={
            <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-950 p-5 text-sm text-slate-300">
              Access restricted. This surface is reserved for governance roles.
            </div>
          }
        >
          <div className="mt-6">
            <ComplianceConsole initialUplinkKey={uplink ? uplink : undefined} />
          </div>
        </RoleGate>
      </div>
    </div>
  );
}
