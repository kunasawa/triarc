import React from 'react';
import RoleGate from '@/components/rbac/RoleGate';
import { WHITEPAPERS } from '@/data/whitepaperRegistry';
import { LIBRARY_DOCS } from '@/data/libraryRegistry';
import { deriveRollout, ROLLOUT_STAGE, SURFACE } from '@/data/rolloutPolicy';

const Row = ({ id, title, category, status, ro }) => (
  <div className="grid grid-cols-12 gap-2 rounded-xl border border-slate-800 bg-black/40 p-3 text-xs">
    <div className="col-span-2 text-slate-400">{id}</div>
    <div className="col-span-5 text-slate-100 font-semibold">{title}</div>
    <div className="col-span-2 text-slate-300">{String(category).toUpperCase()}</div>
    <div className="col-span-1 text-slate-300">{status}</div>
    <div className="col-span-1 text-slate-200">{ro.surface}</div>
    <div className="col-span-1 text-slate-200">{ro.stage}</div>
  </div>
);

export default function GovernanceRollout() {
  const whitepapers = WHITEPAPERS.map((w) => ({
    id: w.id,
    title: w.title,
    category: 'whitepaper',
    status: w.canon_status || '—',
    ro: deriveRollout({ ...w, tier: w.tier || 'PUBLIC' }),
  }));

  const library = LIBRARY_DOCS.map((d) => ({
    id: d.id,
    title: d.title,
    category: d.category,
    status: d.status,
    ro: deriveRollout(d),
  }));

  const all = [...whitepapers, ...library].sort((a, b) => a.id.localeCompare(b.id));

  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • GOVERNANCE SURFACE</div>
        <h1 className="mt-2 text-2xl font-semibold">Controlled Rollout</h1>
        <p className="mt-3 max-w-3xl text-sm text-slate-300">
          This view verifies that Canon artifacts do not leak across surfaces by default.
          Public corridor shows only <span className="text-slate-100">{SURFACE.PUBLIC}</span> +{' '}
          <span className="text-slate-100">{ROLLOUT_STAGE.PUBLISHED}</span>. Internal Library shows{' '}
          <span className="text-slate-100">{SURFACE.LIBRARY}</span> +{' '}
          <span className="text-slate-100">{ROLLOUT_STAGE.APPROVED}</span> or higher.
        </p>

        <RoleGate
          allow={["warden", "controller", "admin", "architect"]}
          fallback={
            <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-950 p-5 text-sm text-slate-300">
              Access restricted. This surface is reserved for governance roles.
            </div>
          }
        >
          <div className="mt-8">
            <div className="grid grid-cols-12 gap-2 rounded-xl border border-slate-800 bg-slate-950 p-3 text-xs text-slate-400">
              <div className="col-span-2">ID</div>
              <div className="col-span-5">TITLE</div>
              <div className="col-span-2">CATEGORY</div>
              <div className="col-span-1">STATUS</div>
              <div className="col-span-1">SURFACE</div>
              <div className="col-span-1">STAGE</div>
            </div>
            <div className="mt-3 space-y-2">
              {all.map((x) => (
                <Row key={x.id} {...x} />
              ))}
            </div>
          </div>
        </RoleGate>
      </div>
    </div>
  );
}
