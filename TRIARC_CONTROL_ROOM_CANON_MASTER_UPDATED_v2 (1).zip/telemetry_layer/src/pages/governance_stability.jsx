import React, { useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import RoleGate from "@/components/rbac/RoleGate";
import { useNexusLiveFleet } from "@/data/hooks";
import { computeStabilityIndex, stabilityColor, stabilityLabel } from "@/data/stabilityIndex";

function sortByIndexDesc(a, b) {
  const av = a?.stability_index ?? -1;
  const bv = b?.stability_index ?? -1;
  return bv - av;
}

export default function GovernanceStability() {
  const { rows, loading, error } = useNexusLiveFleet();
  const [params] = useSearchParams();
  const focus = params.get("uplink") || null;

  const [map, setMap] = useState({});
  const uplinks = useMemo(() => {
    const raw = (rows || []).map((r) => r?.uplink_key).filter(Boolean);
    return Array.from(new Set(raw)).slice(0, 80);
  }, [rows]);

  useEffect(() => {
    const missing = uplinks.filter((k) => map[k] == null);
    if (!missing.length) return;

    let cancelled = false;

    const run = async () => {
      const next = {};
      const limit = 6;
      let idx = 0;

      const workers = Array.from({ length: Math.min(limit, missing.length) }).map(async () => {
        while (idx < missing.length) {
          const k = missing[idx++];
          try {
            next[k] = await computeStabilityIndex({ uplink_key: k });
          } catch {
            next[k] = null;
          }
        }
      });

      await Promise.all(workers);
      if (!cancelled) setMap((p) => ({ ...p, ...next }));
    };

    run();
    return () => {
      cancelled = true;
    };
  }, [uplinks, map]);

  const tableRows = useMemo(() => {
    const enriched = uplinks
      .map((k) => map[k])
      .filter(Boolean)
      .sort(sortByIndexDesc);
    return enriched;
  }, [uplinks, map]);

  const focused = focus ? map[focus] : null;

  return (
    <RoleGate allow={["ADMIN", "ARCHITECT", "CONTROLLER"]} fallback={
      <div className="min-h-screen bg-black text-slate-100">
        <div className="mx-auto max-w-5xl px-6 py-10">
          <div className="text-sm text-slate-300">Restricted. Governance-only surface.</div>
          <Link className="mt-4 inline-block text-xs text-slate-400 hover:text-slate-200" to="/governance">
            ← Back to Governance
          </Link>
        </div>
      </div>
    }>
      <div className="min-h-screen bg-black text-slate-100">
        <div className="mx-auto max-w-6xl px-6 py-10">
          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="text-xs tracking-widest text-slate-400">TRIARC • GOVERNANCE</div>
              <h1 className="mt-2 text-2xl font-semibold">Operator Stability Index</h1>
              <p className="mt-2 text-sm text-slate-400 max-w-3xl">
                Stability is a governance signal (0–100) derived from compliance posture, incident history, remediation load,
                and training maturity. It is not performance and it is not advice. Use it to prioritize review.
              </p>
            </div>
            <Link className="text-xs text-slate-300 hover:text-white" to="/governance">
              ← Governance
            </Link>
          </div>

          <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="rounded-2xl border border-slate-800 bg-black/40 p-4 lg:col-span-2">
              <div className="flex items-center justify-between">
                <div className="text-xs tracking-widest text-slate-400">FLEET (TOP 80)</div>
                <div className="text-xs text-slate-500">
                  {loading ? "Loading…" : error ? "Telemetry unavailable" : `${tableRows.length} indexed`}
                </div>
              </div>

              <div className="mt-3 overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="text-slate-400">
                    <tr className="border-b border-slate-800">
                      <th className="py-2 pr-4 font-semibold">Uplink</th>
                      <th className="py-2 pr-4 font-semibold">Index</th>
                      <th className="py-2 pr-4 font-semibold">Label</th>
                      <th className="py-2 pr-4 font-semibold">Open Cases</th>
                      <th className="py-2 pr-4 font-semibold">Incidents (30d)</th>
                      <th className="py-2 pr-4 font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="text-slate-200">
                    {tableRows.map((r) => (
                      <tr key={r.uplink_key} className="border-b border-slate-900/70">
                        <td className="py-2 pr-4 font-mono">{r.uplink_key}</td>
                        <td className="py-2 pr-4">
                          <span className={`inline-flex items-center rounded-full border border-slate-800 px-2 py-0.5 ${stabilityColor(r.stability_index)}`}>
                            {r.stability_index}
                          </span>
                        </td>
                        <td className="py-2 pr-4">{stabilityLabel(r.stability_index)}</td>
                        <td className="py-2 pr-4">{r.remediation_open ?? "—"}</td>
                        <td className="py-2 pr-4">{r.incident_count_30d ?? "—"}</td>
                        <td className="py-2 pr-4">
                          <div className="flex flex-wrap gap-2">
                            <Link
                              to={`/governance/stability?uplink=${encodeURIComponent(r.uplink_key)}`}
                              className="rounded-lg border border-slate-800 bg-black/30 px-2 py-1 text-[11px] text-slate-200 hover:bg-black/50"
                            >
                              DETAILS
                            </Link>
                            <Link
                              to={`/governance/compliance?uplink=${encodeURIComponent(r.uplink_key)}`}
                              className="rounded-lg border border-slate-800 bg-black/30 px-2 py-1 text-[11px] text-slate-200 hover:bg-black/50"
                            >
                              COMPLIANCE
                            </Link>
                            <Link
                              to={`/governance/incidents?uplink=${encodeURIComponent(r.uplink_key)}`}
                              className="rounded-lg border border-slate-800 bg-black/30 px-2 py-1 text-[11px] text-slate-200 hover:bg-black/50"
                            >
                              INCIDENTS
                            </Link>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {!tableRows.length ? (
                      <tr>
                        <td colSpan={6} className="py-6 text-slate-500">
                          No indexed operators yet.
                        </td>
                      </tr>
                    ) : null}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-black/40 p-4">
              <div className="text-xs tracking-widest text-slate-400">DETAILS</div>
              {!focused ? (
                <div className="mt-3 text-sm text-slate-500">
                  Select an uplink to view deductions and contributing signals.
                </div>
              ) : (
                <div className="mt-3">
                  <div className="flex items-center justify-between gap-3">
                    <div className="font-mono text-xs text-slate-300">{focused.uplink_key}</div>
                    <span className={`inline-flex items-center rounded-full border border-slate-800 px-2 py-0.5 text-xs ${stabilityColor(focused.stability_index)}`}>
                      {focused.stability_index} • {stabilityLabel(focused.stability_index)}
                    </span>
                  </div>

                  <div className="mt-3 space-y-2 text-xs text-slate-300">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Compliance score</span>
                      <span>{focused.compliance?.score ?? "—"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Open remediation</span>
                      <span>{focused.remediation_open ?? "—"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Incidents (30d)</span>
                      <span>{focused.incident_count_30d ?? "—"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Training boost</span>
                      <span>{focused.training_boost ?? 0}</span>
                    </div>
                  </div>

                  <div className="mt-4">
                    <div className="text-xs tracking-widest text-slate-400">DEDUCTIONS</div>
                    <div className="mt-2 space-y-1">
                      {(focused.deductions || []).length ? (
                        focused.deductions.map((d, idx) => (
                          <div key={idx} className="flex items-center justify-between rounded-xl border border-slate-800 bg-black/30 px-3 py-2 text-xs">
                            <span className="text-slate-300">{d.label}</span>
                            <span className="text-slate-200">-{d.pts}</span>
                          </div>
                        ))
                      ) : (
                        <div className="text-xs text-slate-500">No deductions recorded.</div>
                      )}
                    </div>
                  </div>

                  <div className="mt-4">
                    <div className="text-xs tracking-widest text-slate-400">NEXT ACTION</div>
                    <div className="mt-2 text-xs text-slate-300">
                      If stability is below <span className="text-slate-100 font-semibold">60</span>, prioritize remediation review
                      and verify Permission alignment (Time/Events/Locks) before any execution window.
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="mt-6 text-xs text-slate-500">
            Canon note: stability is a governance classifier for fleet health — not a signal, not a forecast, not a promise.
          </div>
        </div>
      </div>
    </RoleGate>
  );
}
