import React from "react";
import { useAuth } from "@/lib/AuthContext";
import { useIdentity } from "@/data/hooks";
import { isSubscriptionActive, getSubscriptionStatus } from "@/lib/entitlements";

export default function Portal() {
  const { user, logout } = useAuth();
  const idQ = useIdentity();
  const identity = idQ.data;

  const subStatus = getSubscriptionStatus(identity);
  const subOk = isSubscriptionActive(identity);

  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="flex items-start justify-between gap-6">
          <div>
            <div className="text-xs tracking-widest text-slate-400">TRIARC • SOVEREIGN CONTROL ROOM</div>
            <h1 className="mt-2 text-2xl font-semibold">Portal</h1>
            <div className="mt-2 text-sm text-slate-300">
              Permission &gt; Opportunity • Time &gt; Price • Structure &gt; Pattern • Volatility &gt; Direction
            </div>
          </div>
          <button
            onClick={() => logout(true)}
            className="rounded-xl border border-slate-700 px-4 py-2 text-sm text-slate-200 hover:bg-slate-900"
          >
            Logout
          </button>
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5">
            <div className="text-xs uppercase tracking-widest text-slate-500">Identity</div>
            <div className="mt-3 space-y-1 text-sm">
              <div><span className="text-slate-500">Operator:</span> {identity?.name || identity?.email || user?.email || "—"}</div>
              <div><span className="text-slate-500">Role:</span> {identity?.role || "—"}</div>
              <div><span className="text-slate-500">Tier:</span> {identity?.tier || "—"}</div>
              <div><span className="text-slate-500">Pathway:</span> {identity?.pathway || "—"}</div>
              <div><span className="text-slate-500">Uplink:</span> {identity?.uplink_key || "—"}</div>
              <div><span className="text-slate-500">Billing:</span> {subStatus || "—"} {subOk ? <span className="text-emerald-300">(ACTIVE)</span> : <span className="text-amber-300">(RESTRICTED)</span>}</div>
              <div><span className="text-slate-500">Execution:</span> {identity?.execution_entitled ? <span className="text-emerald-300">ENTITLED</span> : <span className="text-slate-400">HOLD</span>}</div>
            </div>
            {idQ.isLoading ? <div className="mt-3 text-xs text-slate-500">Loading identity…</div> : null}

            {!subOk ? (
              <div className="mt-4 rounded-xl border border-amber-700 bg-amber-950/10 px-4 py-3 text-xs text-slate-200">
                Suite access is restricted until billing returns to ACTIVE / GRACE.
                <a className="ml-2 underline text-amber-300" href="/portal/billing">Open Billing</a>
              </div>
            ) : null}
          </div>

          <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5">
            <div className="text-xs uppercase tracking-widest text-slate-500">Quick Surfaces</div>
            <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <a className="rounded-xl border border-slate-800 bg-black px-4 py-3 hover:bg-slate-900" href="/weekly">Weekly</a>
              <a className="rounded-xl border border-slate-800 bg-black px-4 py-3 hover:bg-slate-900" href="/weekly/archive">Weekly Archive</a>
              <a className="rounded-xl border border-slate-800 bg-black px-4 py-3 hover:bg-slate-900" href="/nexus">Nexus</a>
              <a className="rounded-xl border border-slate-800 bg-black px-4 py-3 hover:bg-slate-900" href="/pathway">Pathway</a>
              <a className="rounded-xl border border-slate-800 bg-black px-4 py-3 hover:bg-slate-900" href="/library">Library</a>
            </div>
            <div className="mt-4 text-xs text-slate-500">
              Governance mutation surfaces are role-gated.
            </div>
          </div>
        </div>

        <div className="mt-4 grid gap-4 md:grid-cols-3">
          <a className="rounded-2xl border border-slate-800 bg-slate-950 p-5 hover:bg-slate-900" href="/governance">
            <div className="text-xs uppercase tracking-widest text-slate-500">Governance</div>
            <div className="mt-2 text-sm text-slate-200">Warden console (briefs, incidents, remediation).</div>
          </a>
          <a className="rounded-2xl border border-slate-800 bg-slate-950 p-5 hover:bg-slate-900" href="/controller">
            <div className="text-xs uppercase tracking-widest text-slate-500">Controller</div>
            <div className="mt-2 text-sm text-slate-200">Provisioning, roles, uplink keys, audits.</div>
          </a>
          <a className="rounded-2xl border border-slate-800 bg-slate-950 p-5 hover:bg-slate-900" href="/architecture">
            <div className="text-xs uppercase tracking-widest text-slate-500">Architecture</div>
            <div className="mt-2 text-sm text-slate-200">Doctrine vault, schema registry, changelogs.</div>
          </a>
        </div>
      </div>
    </div>
  );
}
