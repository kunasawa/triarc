import React from "react";
import RoleGate from "@/components/rbac/RoleGate";
import FleetConsole from "@/components/governance/FleetConsole";

export default function Controller() {
  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • CONTROLLER CONSOLE</div>
        <h1 className="mt-2 text-2xl font-semibold">Controller</h1>

        <RoleGate
          allow={["controller", "admin", "architect"]}
          fallback={
            <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-950 p-5 text-sm text-slate-300">
              Access restricted. Provisioning and audit surfaces are controller-only.
            </div>
          }
        >
          <div className="mt-6">
            <FleetConsole />
          </div>
        </RoleGate>
      </div>
    </div>
  );
}
