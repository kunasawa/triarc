import React, { useMemo, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useWeeklyArchive } from '@/data/hooks';

const INSTRUMENTS = ['ES','MES','NQ','MNQ','GC','MGC','CL','MCL'];

function ArtifactCard({ row }) {
  if (!row) return null;
  return (
    <Card className="bg-slate-950 border-slate-800 rounded-2xl">
      <CardContent className="p-5">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <div className="text-sm text-slate-100">{row.canon_name ?? 'Weekly Artifact'}</div>
          <div className="text-xs text-slate-500">{row.canon_version ?? `v${row.version_num ?? '—'}`}</div>
        </div>

        <div className="mt-1 text-xs text-slate-500">
          Instrument: <span className="text-slate-200">{row.instrument ?? '—'}</span> • Week of:{' '}
          <span className="text-slate-200">{row.week_of ?? '—'}</span> • Status:{' '}
          <span className="text-slate-200">{row.status ?? '—'}</span>
        </div>

        <div className="mt-4 grid gap-3 md:grid-cols-3">
          <div className="rounded-2xl border border-slate-800 bg-black p-4">
            <div className="text-xs uppercase tracking-widest text-slate-500">Classification</div>
            <div className="mt-2 text-sm text-slate-200">{row.wk_type ?? '—'}</div>
            <div className="mt-1 text-xs text-slate-500">Confidence: {row.wk_confidence ?? '—'}</div>
          </div>
          <div className="rounded-2xl border border-slate-800 bg-black p-4">
            <div className="text-xs uppercase tracking-widest text-slate-500">Focus</div>
            <div className="mt-2 text-sm text-slate-200 whitespace-pre-wrap">{row.focus ?? '—'}</div>
          </div>
          <div className="rounded-2xl border border-slate-800 bg-black p-4">
            <div className="text-xs uppercase tracking-widest text-slate-500">Warning</div>
            <div className="mt-2 text-sm text-slate-200 whitespace-pre-wrap">{row.warning ?? '—'}</div>
          </div>
        </div>

        {(row.changelog || row.operator_impact || row.notes) && (
          <div className="mt-4 grid gap-3 md:grid-cols-3">
            <div className="rounded-2xl border border-slate-800 bg-black p-4">
              <div className="text-xs uppercase tracking-widest text-slate-500">Changelog</div>
              <div className="mt-2 text-sm text-slate-200 whitespace-pre-wrap">{row.changelog ?? '—'}</div>
            </div>
            <div className="rounded-2xl border border-slate-800 bg-black p-4">
              <div className="text-xs uppercase tracking-widest text-slate-500">Operator Impact</div>
              <div className="mt-2 text-sm text-slate-200 whitespace-pre-wrap">{row.operator_impact ?? '—'}</div>
            </div>
            <div className="rounded-2xl border border-slate-800 bg-black p-4">
              <div className="text-xs uppercase tracking-widest text-slate-500">Governance Notes</div>
              <div className="mt-2 text-sm text-slate-200 whitespace-pre-wrap">{row.notes ?? '—'}</div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function WeeklyArchive() {
  const [instrument, setInstrument] = useState('ES');
  const q = useWeeklyArchive(instrument, 50);

  const rows = useMemo(() => {
    const out = Array.isArray(q.data) ? q.data : [];
    // Prefer most recent week_of, then version.
    return [...out].sort((a, b) => {
      const wa = a?.week_of ?? '';
      const wb = b?.week_of ?? '';
      if (wa !== wb) return wb.localeCompare(wa);
      return Number(b?.version_num ?? 0) - Number(a?.version_num ?? 0);
    });
  }, [q.data]);

  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • WEEKLY ARCHIVE</div>
        <h1 className="mt-2 text-2xl font-semibold">Weekly Archive</h1>
        <p className="mt-3 max-w-2xl text-sm text-slate-300">
          Read-only record of published environment contracts. Drafts are not displayed here.
        </p>

        <div className="mt-8 max-w-5xl">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <div className="text-xs uppercase tracking-widest text-slate-500">Instrument</div>
            <Select value={instrument} onValueChange={setInstrument}>
              <SelectTrigger className="mt-1 w-[220px] bg-black border-slate-800">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {INSTRUMENTS.map((i) => (
                  <SelectItem key={i} value={i}>{i}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="text-xs text-slate-500">
            Showing {rows.length} artifact(s)
          </div>
        </div>

        <div className="mt-5 grid gap-4">
          {rows.map((r) => (
            <ArtifactCard key={r.id} row={r} />
          ))}
          {!rows.length && (
            <Card className="bg-slate-950 border-slate-800 rounded-2xl">
              <CardContent className="p-5 text-sm text-slate-300">
                No published artifacts found for this instrument.
              </CardContent>
            </Card>
          )}
        </div>
        </div>
      </div>
    </div>
  );
}
