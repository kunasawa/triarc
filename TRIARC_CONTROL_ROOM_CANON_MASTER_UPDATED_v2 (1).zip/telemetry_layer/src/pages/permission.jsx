import React from 'react';
import { Link } from 'react-router-dom';

const Shell = ({ children }) => (
  <div className="min-h-screen bg-black text-slate-100">
    <div className="mx-auto max-w-4xl px-6 py-10">
      <header className="flex items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="text-xs tracking-widest text-slate-400">PERMISSION SURFACE</div>
          <h1 className="mt-1 text-2xl font-semibold">Permission &gt; Opportunity</h1>
        </div>
        <nav className="flex items-center gap-3">
          <Link className="rounded-md border border-slate-700 px-3 py-2 text-sm text-slate-200 hover:bg-slate-900" to="/landing">
            Landing
          </Link>
          <Link className="rounded-md border border-slate-700 px-3 py-2 text-sm text-slate-200 hover:bg-slate-900" to="/public/doctrine">
            Doctrine
          </Link>
          <Link className="rounded-md bg-slate-100 px-3 py-2 text-sm font-medium text-black hover:bg-white" to="/access-request">
            Request Access
          </Link>
        </nav>
      </header>
      {children}
    </div>
  </div>
);

const Block = ({ title, children }) => (
  <div className="rounded-xl border border-slate-800 bg-slate-950 p-5">
    <div className="text-sm font-medium text-slate-200">{title}</div>
    <div className="mt-2 text-sm text-slate-300 leading-relaxed">{children}</div>
  </div>
);

export default function Permission() {
  return (
    <Shell>
      <main className="pt-10">
        <p className="text-slate-300 leading-relaxed">
          Permission is not marketing language. It is the governing mechanism that controls when an operator is allowed to participate,
          how much load is permitted, and which tools can be used.
        </p>

        <div className="mt-8 grid gap-4 md:grid-cols-2">
          <Block title="Governance Inputs">
            Permission is derived from environment and constraint:
            <ul className="mt-3 list-disc space-y-2 pl-5">
              <li>Time-of-Interest alignment (session windows)</li>
              <li>Sentinel event state (stand down / probe)</li>
              <li>Weekly regime classification (environment)</li>
              <li>Trinity matrix health (cross-market integrity)</li>
              <li>Role + Tier + Pathway authorization</li>
            </ul>
          </Block>

          <Block title="Enforcement Surfaces">
            Permission is enforced at the execution edge:
            <ul className="mt-3 list-disc space-y-2 pl-5">
              <li><span className="text-slate-100">Nexus</span> gates participation and emits telemetry</li>
              <li><span className="text-slate-100">Weekly Classifier</span> defines regime + clarity + macro caps</li>
              <li><span className="text-slate-100">Compliance</span> governs continuation and remediation</li>
            </ul>
          </Block>
        </div>

        <div className="mt-8 grid gap-4">
          <Block title="Pathway Routing">
            Access requests are routed into one of three pathways:
            <ul className="mt-3 list-disc space-y-2 pl-5">
              <li><span className="text-slate-100">Academy</span> — apprenticeship discipline and mapping</li>
              <li><span className="text-slate-100">Infirmary</span> — rehabilitation and constraint repair</li>
              <li><span className="text-slate-100">Engineer</span> — systems-grade operators and governance alignment</li>
            </ul>
            Routing is not preference-based. It is integrity-based.
          </Block>

          <Block title="What happens after approval">
            Once approved, the portal becomes your control room surface:
            <div className="mt-3 text-sm text-slate-300">
              <span className="text-slate-100">Portal</span> → <span className="text-slate-100">Pathway</span> → <span className="text-slate-100">Weekly</span> → <span className="text-slate-100">Nexus</span>
            </div>
            Execution permission remains conditional. Every session is audited.
          </Block>
        </div>

        <div className="mt-10 flex flex-wrap gap-3">
          <Link className="rounded-md border border-slate-700 px-4 py-2 text-sm text-slate-200 hover:bg-slate-900" to="/public/doctrine">
            Read doctrine
          </Link>
          <Link className="rounded-md bg-slate-100 px-4 py-2 text-sm font-medium text-black hover:bg-white" to="/access-request">
            Request access
          </Link>
        </div>
      </main>
    </Shell>
  );
}
