import React, { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import RoleGate from "@/components/rbac/RoleGate";
import { approveAccessRequest, listAccessRequests, updateAccessRequest } from "@/data/governance";

function pill(col, txt) {
  const base = "inline-flex items-center rounded-full px-2 py-0.5 text-xs";
  const map = {
    gray: `${base} bg-slate-800 text-slate-200`,
    green: `${base} bg-emerald-900 text-emerald-200`,
    orange: `${base} bg-amber-900 text-amber-200`,
    red: `${base} bg-red-900 text-red-200`,
    blue: `${base} bg-sky-900 text-sky-200`,
  };
  return <span className={map[col] ?? map.gray}>{txt}</span>;
}

export default function GovernanceIntake() {
  const [rows, setRows] = useState([]);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  const filtered = useMemo(() => {
    const t = (q || "").toLowerCase().trim();
    if (!t) return rows;
    return rows.filter((r) =>
      [r.name, r.email, r.intent, r.pathway_hint, r.risk_profile, r.status].some((x) =>
        (x || "").toString().toLowerCase().includes(t)
      )
    );
  }, [rows, q]);

  async function refresh() {
    setBusy(true);
    setMsg("");
    try {
      const pending = await listAccessRequests({ status: "PENDING", limit: 200 });
      const review = await listAccessRequests({ status: "REVIEW", limit: 200 });
      const merged = [...(pending || []), ...(review || [])];
      // De-dupe by id
      const byId = new Map();
      merged.forEach((r) => byId.set(r.id, r));
      setRows(Array.from(byId.values()).sort((a, b) => (b.created_date || 0) - (a.created_date || 0)));
    } catch (e) {
      setMsg(e?.message || "Failed to load intake requests.");
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function setReview(r) {
    setBusy(true);
    setMsg("");
    try {
      await updateAccessRequest(r.id, { status: "REVIEW" });
      await refresh();
    } catch (e) {
      setMsg(e?.message || "Unable to set REVIEW.");
    } finally {
      setBusy(false);
    }
  }

  async function approve(r) {
    setBusy(true);
    setMsg("");
    try {
      const hint = (r.pathway_hint || "").toString().toUpperCase();
      const tier = hint === "GAUNTLET" ? "GAUNTLET" : hint === "INFIRMARY" ? "INFIRMARY" : "ACADEMY";
      await approveAccessRequest({ request: r, tier, role: "operator", provision_key: true });
      await refresh();
    } catch (e) {
      setMsg(e?.message || "Approve failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <RoleGate allow={["admin", "controller", "architect", "governance", "warden"]}>
      <div className="min-h-screen bg-black text-slate-100">
        <div className="mx-auto max-w-7xl px-6 py-10">
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <div>
              <div className="text-xs tracking-widest text-slate-400">GOVERNANCE • INTAKE</div>
              <h1 className="mt-2 text-2xl font-semibold">Permission Requests</h1>
              <p className="mt-2 max-w-3xl text-sm text-slate-300">
                Review inbound access requests and route operators into the correct Pathway. This is governance — not
                marketing.
              </p>
            </div>

            <div className="flex flex-col gap-2 md:w-[420px]">
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search: email, name, intent, pathway…"
                className="bg-slate-950 border-slate-800"
              />
              <div className="flex gap-2">
                <Button onClick={refresh} disabled={busy} className="w-full">
                  Refresh
                </Button>
              </div>
            </div>
          </div>

          {msg ? <div className="mt-4 text-sm text-amber-300">{msg}</div> : null}

          <div className="mt-8 overflow-hidden rounded-2xl border border-slate-800">
            <div className="grid grid-cols-12 gap-0 bg-slate-950 px-4 py-3 text-xs text-slate-400">
              <div className="col-span-3">Operator</div>
              <div className="col-span-2">Intent</div>
              <div className="col-span-2">Pathway</div>
              <div className="col-span-2">Risk Profile</div>
              <div className="col-span-1">Status</div>
              <div className="col-span-2 text-right">Actions</div>
            </div>

            {filtered.length === 0 ? (
              <div className="px-4 py-10 text-center text-sm text-slate-400">No matching intake items.</div>
            ) : (
              filtered.map((r) => (
                <div key={r.id} className="grid grid-cols-12 gap-0 border-t border-slate-800 px-4 py-3 text-sm">
                  <div className="col-span-3">
                    <div className="font-medium text-slate-100">{r.name || "—"}</div>
                    <div className="text-xs text-slate-400">{r.email || "—"}</div>
                  </div>

                  <div className="col-span-2 text-slate-200">{r.intent || "—"}</div>

                  <div className="col-span-2">
                    {r.pathway_hint ? pill("blue", r.pathway_hint) : pill("gray", "—")}
                  </div>

                  <div className="col-span-2 text-slate-200">{r.risk_profile || "—"}</div>

                  <div className="col-span-1">
                    {r.status === "PENDING"
                      ? pill("orange", "PENDING")
                      : r.status === "REVIEW"
                      ? pill("blue", "REVIEW")
                      : r.status === "APPROVED"
                      ? pill("green", "APPROVED")
                      : pill("gray", r.status || "—")}
                  </div>

                  <div className="col-span-2 flex justify-end gap-2">
                    <Button
                      variant="secondary"
                      disabled={busy || r.status === "APPROVED"}
                      onClick={() => setReview(r)}
                    >
                      Review
                    </Button>
                    <Button disabled={busy || r.status === "APPROVED"} onClick={() => approve(r)}>
                      Approve
                    </Button>
                  </div>

                  {r.message ? (
                    <div className="col-span-12 mt-2 rounded-xl bg-slate-950 px-3 py-2 text-xs text-slate-300">
                      {r.message}
                    </div>
                  ) : null}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </RoleGate>
  );
}
