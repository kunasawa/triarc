import React from 'react';
import { useIdentity } from '@/data/hooks';
import { isSubscriptionActive, getTier } from '@/lib/entitlements';

// TriArc: capability gates are determined by entitlements coming from the billing sync.
// We do NOT infer access from UI routing, client-side profile guesses, or page names.

const isStaffRole = (role) => ['admin', 'architect', 'controller', 'controller_ops', 'warden'].includes((role || '').toLowerCase());

export default function EntitlementGate({
  requireSubscription = false,
  requireExecution = false,
  children,
}) {
  const idQ = useIdentity();
  const identity = idQ.data;

  const role = identity?.role;
  const isStaff = isStaffRole(role);
  const subOk = isSubscriptionActive(identity);
  const execOk = !!identity?.execution_entitled;
  const tier = getTier(identity);

  if (idQ.isLoading) {
    return (
      <div className="rounded-2xl border border-slate-800 bg-black/40 p-5 text-sm text-slate-300">
        Verifying entitlement surface…
      </div>
    );
  }

  // Staff surfaces bypass subscription gates (governance/ops continuity).
  if (isStaff) return children;

  if (requireSubscription && !subOk) {
    return (
      <div className="rounded-2xl border border-amber-700 bg-amber-950/10 p-6">
        <div className="text-xs tracking-widest text-amber-300">RESTRICTED</div>
        <div className="mt-2 text-lg font-semibold text-slate-100">Subscription required</div>
        <div className="mt-2 max-w-xl text-sm text-slate-300">
          This surface is part of the product suite. Your identity is not currently in ACTIVE / GRACE billing state.
          Doctrine remains visible via the Library, but suite telemetry and weekly artifacts are locked.
        </div>
        <div className="mt-4 text-xs text-slate-500">
          Tier: <span className="text-slate-200">{tier || '—'}</span>
        </div>
        <div className="mt-4">
          <a
            className="inline-flex rounded-xl border border-slate-700 bg-black px-4 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-900"
            href="/portal/billing"
          >
            OPEN BILLING
          </a>
        </div>
      </div>
    );
  }

  if (requireExecution && !execOk) {
    return (
      <div className="rounded-2xl border border-slate-800 bg-black/40 p-6">
        <div className="text-xs tracking-widest text-slate-500">GOVERNANCE HOLD</div>
        <div className="mt-2 text-lg font-semibold text-slate-100">Execution not entitled</div>
        <div className="mt-2 max-w-xl text-sm text-slate-300">
          This identity has not been granted execution entitlement. Controllers must provision an uplink and enable
          execution for Nexus telemetry surfaces.
        </div>
        <div className="mt-4 text-xs text-slate-500">
          Tier: <span className="text-slate-200">{tier || '—'}</span>
        </div>
      </div>
    );
  }

  return children;
}
