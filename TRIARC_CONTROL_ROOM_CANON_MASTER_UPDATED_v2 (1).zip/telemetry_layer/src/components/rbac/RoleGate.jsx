import React from "react";
import { useAuth } from "@/lib/AuthContext";

/**
 * RoleGate — Control-Room RBAC primitive.
 *
 * Notes:
 * - This is a UI gate (to prevent accidental exposure).
 * - Server-side permissions remain the source of truth.
 */
export default function RoleGate({ allow = [], fallback = null, children }) {
  const { user } = useAuth();

  const role = (user?.role || "").toString().toLowerCase();
  const allowed = allow.map(r => r.toLowerCase());

  if (allowed.length === 0) return <>{children}</>;
  if (!role || !allowed.includes(role)) return <>{fallback}</>;
  return <>{children}</>;
}
