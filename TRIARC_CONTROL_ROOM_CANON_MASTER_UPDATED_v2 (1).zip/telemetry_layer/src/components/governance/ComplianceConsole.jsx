import React, { useEffect, useMemo, useState } from 'react';
import PanelCard from '@/components/controlroom/PanelCard';
import { useComplianceEvents, useComplianceSummary, useRemediationCases, useNexusLiveFleet } from '@/data/hooks';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { createEnforcementAction, createIncident, setExecutionHold } from '@/data/api';

const sevBadge = (sev) => {
  const s = (sev || '—').toString().toUpperCase();
  if (s === 'CRITICAL') return <Badge variant="destructive">CRITICAL</Badge>;
  if (s === 'MAJOR') return <Badge variant="secondary">MAJOR</Badge>;
  if (s === 'MINOR') return <Badge variant="outline">MINOR</Badge>;
  return <Badge variant="outline">—</Badge>;
};

export default function ComplianceConsole({ initialUplinkKey } = {}) {
  const [uplink, setUplink] = useState(initialUplinkKey ? String(initialUplinkKey) : 'ALL');
  const [busy, setBusy] = useState(false);
  const [opMsg, setOpMsg] = useState('');

  // Keep selector in sync when deep-linked.
  useEffect(() => {
    if (initialUplinkKey) setUplink(String(initialUplinkKey));
  }, [initialUplinkKey]);

  // Use fleet live rows as an easy selector source (warden/controller).
  const fleet = useNexusLiveFleet(200);
  const uplinkOptions = useMemo(() => {
    const rows = Array.isArray(fleet.data) ? fleet.data : [];
    const keys = Array.from(new Set(rows.map((r) => r?.uplink_key).filter(Boolean)));
    keys.sort();
    return keys;
  }, [fleet.data]);

  const uplink_key = uplink === 'ALL' ? undefined : uplink;

  const summary = useComplianceSummary({ uplink_key });
  const events = useComplianceEvents({ uplink_key, limit: 100 });
  const cases = useRemediationCases({ uplink_key, status: 'OPEN', limit: 100 });

  const holdActive = !!summary.data?.execution_hold;
  const holdReason = summary.data?.hold_reason || summary.data?.last_violation_type || '—';

  const applyHold = async (hold) => {
    if (!uplink_key) return;
    setBusy(true);
    setOpMsg('');
    try {
      // Role source: server populates `role` on fleet records; UI is already role-gated.
      const actor_role = 'governance';
      const reason = hold ? (holdReason || 'GOVERNANCE HOLD') : 'RELEASED';

      await setExecutionHold({ uplink_key, hold, reason, until_iso: null, actor_role });

      await createEnforcementAction({
        uplink_key,
        action_type: hold ? 'EXECUTION_HOLD' : 'HOLD_RELEASED',
        reason,
        actor_role,
        result: 'LOGGED',
        created_at: new Date().toISOString()
      });

      await createIncident({
        uplink_key,
        status: 'OPEN',
        incident_type: hold ? 'PERMISSION_RESTRICTION' : 'PERMISSION_RESTORED',
        title: hold ? 'Execution Hold Applied' : 'Execution Hold Released',
        summary: reason,
        created_at: new Date().toISOString()
      });

      setOpMsg(hold ? 'Execution hold applied.' : 'Execution hold released.');
      await Promise.all([summary.refetch(), events.refetch(), cases.refetch()]);
    } catch (e) {
      setOpMsg(e?.message || 'Operation failed.');
    } finally {
      setBusy(false);
    }
  };

  const topViolations = useMemo(() => {
    const rows = Array.isArray(events.data) ? events.data : [];
    return rows.slice(0, 12);
  }, [events.data]);

  const openCases = useMemo(() => (Array.isArray(cases.data) ? cases.data : []), [cases.data]);

  return (
    <PanelCard
      title="GOVERNANCE • COMPLIANCE"
      subtitle="Breach detection, remediation tracking, and operator stability monitoring."
      right={
        <div className="flex items-center gap-2">
          <select
            value={uplink}
            onChange={(e) => setUplink(e.target.value)}
            className="rounded-xl border border-slate-800 bg-black px-3 py-2 text-xs text-slate-100"
          >
            <option value="ALL">ALL UPLINKS</option>
            {uplinkOptions.map((k) => (
              <option key={k} value={k}>
                {k}
              </option>
            ))}
          </select>
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              summary.refetch();
              events.refetch();
              cases.refetch();
            }}
          >
            Refresh
          </Button>
        </div>
      }
    >
      <div className="mb-4 rounded-2xl border border-slate-800 bg-black/30 p-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="text-xs uppercase tracking-widest text-slate-500">Permission Status</div>
            <div className="mt-2 flex items-center gap-2">
              {holdActive ? <Badge variant="destructive">EXECUTION HOLD</Badge> : <Badge variant="secondary">ACTIVE</Badge>}
              <div className="text-xs text-slate-400">{uplink_key ? `Uplink: ${uplink_key}` : 'Select an uplink key.'}</div>
            </div>
            <div className="mt-2 text-xs text-slate-500">
              Reason: <span className="text-slate-300">{holdReason}</span>
            </div>
            {opMsg ? <div className="mt-2 text-xs text-slate-300">{opMsg}</div> : null}
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant={holdActive ? 'outline' : 'destructive'} disabled={!uplink_key || busy} onClick={() => applyHold(true)}>
              Apply Hold
            </Button>
            <Button size="sm" variant="secondary" disabled={!uplink_key || busy} onClick={() => applyHold(false)}>
              Release
            </Button>
          </div>
        </div>
        <div className="mt-3 rounded-xl border border-slate-800 bg-black p-3 text-xs text-slate-400">
          Holds are governance permission controls. Pair them with remediation directives and training audit entries.
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        <div className="rounded-2xl border border-slate-800 bg-black/40 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500">Compliance Score</div>
          <div className="mt-2 text-3xl font-semibold">
            {summary.isLoading ? '—' : (summary.data?.score ?? summary.data?.compliance_score ?? '—')}
          </div>
          <div className="mt-2 text-xs text-slate-400">
            Last violation: {summary.data?.last_violation_type ?? '—'}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-black/40 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500">Open Remediation</div>
          <div className="mt-2 text-3xl font-semibold">{cases.isLoading ? '—' : openCases.length}</div>
          <div className="mt-2 text-xs text-slate-400">Cases require governance acknowledgement + closure notes.</div>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-black/40 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500">Signal Quality</div>
          <div className="mt-2 text-sm text-slate-200">This surface is for governance only.</div>
          <div className="mt-2 text-xs text-slate-400">
            Do not use violations as public-facing proof. Use them to tighten permission.
          </div>
        </div>
      </div>

      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <div className="rounded-2xl border border-slate-800 bg-black/30 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500">Recent Violations</div>
          <div className="mt-3 space-y-2">
            {events.isLoading ? (
              <div className="text-xs text-slate-400">Loading…</div>
            ) : topViolations.length ? (
              topViolations.map((e) => (
                <div key={e?.id || `${e?.timestamp_ms}-${e?.violation_type}`} className="flex items-start justify-between gap-3 rounded-xl border border-slate-800 bg-slate-950 p-3">
                  <div>
                    <div className="text-sm text-slate-100">{e?.violation_type ?? 'VIOLATION'}</div>
                    <div className="mt-1 text-xs text-slate-400">
                      {e?.uplink_key ? `Uplink: ${e.uplink_key}` : '—'}
                      {e?.symbol ? ` • ${e.symbol}` : ''}
                    </div>
                    {e?.notes ? <div className="mt-1 text-xs text-slate-500">{e.notes}</div> : null}
                  </div>
                  <div className="shrink-0">{sevBadge(e?.severity)}</div>
                </div>
              ))
            ) : (
              <div className="text-xs text-slate-400">No violations recorded for this filter.</div>
            )}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-black/30 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500">Open Remediation Cases</div>
          <div className="mt-3 space-y-2">
            {cases.isLoading ? (
              <div className="text-xs text-slate-400">Loading…</div>
            ) : openCases.length ? (
              openCases.slice(0, 12).map((c) => (
                <div key={c?.id} className="rounded-xl border border-slate-800 bg-slate-950 p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-sm text-slate-100">{c?.title ?? c?.case_type ?? 'REMEDIATION'}</div>
                      <div className="mt-1 text-xs text-slate-400">
                        {c?.uplink_key ? `Uplink: ${c.uplink_key}` : '—'}
                        {c?.deadline ? ` • Deadline: ${c.deadline}` : ''}
                      </div>
                    </div>
                    {sevBadge(c?.severity)}
                  </div>
                  {c?.description ? <div className="mt-2 text-xs text-slate-500">{c.description}</div> : null}
                </div>
              ))
            ) : (
              <div className="text-xs text-slate-400">No open cases for this filter.</div>
            )}
          </div>
        </div>
      </div>
    </PanelCard>
  );
}
