import React, { useMemo, useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { publishWeeklyArtifact, upsertWeeklyDraft, lockWeeklyArtifact, archiveWeeklyArtifact, amendWeeklyArtifact, WEEKLY_STATUS } from '@/data/governance';
import { useWeeklyArchive, useWeeklyByWeek } from '@/data/hooks';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

const INSTRUMENTS = ['ES', 'MES', 'NQ', 'MNQ', 'GC', 'MGC', 'CL', 'MCL'];
const WK_TYPES = ['UPSIDE', 'DOWNSIDE', 'REVERSAL', 'INSIDE', 'OUTSIDE', 'BALANCED', 'ACCUMULATION', 'DISTRIBUTION', 'UNDECLARED'];

export default function WeeklyPublisher() {
  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);
  const [instrument, setInstrument] = useState('ES');
  const [weekOf, setWeekOf] = useState(today);
  const [wkType, setWkType] = useState('UNDECLARED');
  const [wkConfidence, setWkConfidence] = useState('0');
  const [focus, setFocus] = useState('');
  const [warning, setWarning] = useState('');
  const [macroCap, setMacroCap] = useState('1.0');
  const [notes, setNotes] = useState('');
  const [changelog, setChangelog] = useState('');
  const [operatorImpact, setOperatorImpact] = useState('');
  const [selectedId, setSelectedId] = useState('');

  const qc = useQueryClient();

  const archiveQ = useWeeklyArchive(instrument, 25);
  const selectedRow = useMemo(() => {
    const rows = archiveQ.data ?? [];
    return rows.find((r) => r?.id === selectedId) ?? null;
  }, [archiveQ.data, selectedId]);

  // If the operator picks a week_of, surface the latest record for that week.
  const byWeekQ = useWeeklyByWeek(instrument, weekOf);

  const draftM = useMutation({
    mutationFn: async () => {
      const wk_confidence = Number.isFinite(Number(wkConfidence)) ? Number(wkConfidence) : 0;
      const macro_cap = Number.isFinite(Number(macroCap)) ? Number(macroCap) : 1.0;
      return await upsertWeeklyDraft({
        instrument,
        week_of: weekOf,
        wk_type: wkType,
        wk_confidence,
        focus,
        warning,
        macro_cap,
        notes,
        changelog,
        operator_impact: operatorImpact,
      });
    },
    onSuccess: () => {
      toast.success('Draft saved');
      qc.invalidateQueries();
    },
    onError: (e) => toast.error(e?.message || 'Draft save failed'),
  });

  const pubM = useMutation({
    mutationFn: async () => {
      const wk_confidence = Number.isFinite(Number(wkConfidence)) ? Number(wkConfidence) : 0;
      const macro_cap = Number.isFinite(Number(macroCap)) ? Number(macroCap) : 1.0;
      return await publishWeeklyArtifact({
        instrument,
        week_of: weekOf,
        wk_type: wkType,
        wk_confidence,
        focus,
        warning,
        macro_cap,
        notes,
        changelog: changelog || 'Publication.',
        operator_impact: operatorImpact,
      });
    },
    onSuccess: () => {
      toast.success('Weekly artifact published');
      setChangelog('');
      setOperatorImpact('');
      qc.invalidateQueries();
    },
    onError: (e) => toast.error(e?.message || 'Publish failed'),
  });

  const lockM = useMutation({
    mutationFn: async () => {
      if (!selectedRow?.id) throw new Error('Select a published artifact to lock.');
      return await lockWeeklyArtifact({ id: selectedRow.id });
    },
    onSuccess: () => {
      toast.success('Artifact locked');
      qc.invalidateQueries();
    },
    onError: (e) => toast.error(e?.message || 'Lock failed'),
  });

  const archiveM = useMutation({
    mutationFn: async () => {
      if (!selectedRow?.id) throw new Error('Select an artifact to archive.');
      return await archiveWeeklyArtifact({ id: selectedRow.id });
    },
    onSuccess: () => {
      toast.success('Artifact archived');
      qc.invalidateQueries();
    },
    onError: (e) => toast.error(e?.message || 'Archive failed'),
  });

  const amendM = useMutation({
    mutationFn: async () => {
      if (!selectedRow?.id) throw new Error('Select a published artifact to amend.');
      const wk_confidence = Number.isFinite(Number(wkConfidence)) ? Number(wkConfidence) : 0;
      const macro_cap = Number.isFinite(Number(macroCap)) ? Number(macroCap) : 1.0;
      return await amendWeeklyArtifact({
        parent_id: selectedRow.id,
        instrument,
        week_of: weekOf,
        patch: {
          wk_type: wkType,
          wk_confidence,
          focus,
          warning,
          macro_cap,
          notes,
        },
        changelog: changelog || 'Amendment.',
        operator_impact: operatorImpact,
      });
    },
    onSuccess: () => {
      toast.success('Amendment published');
      setChangelog('');
      setOperatorImpact('');
      qc.invalidateQueries();
    },
    onError: (e) => toast.error(e?.message || 'Amend failed'),
  });

  return (
    <Card className="bg-slate-950 border-slate-800 rounded-2xl">
      <CardContent className="p-5">
        <div className="text-xs uppercase tracking-widest text-slate-500">Weekly Artifact — Publishing Pipeline</div>
        <div className="mt-1 text-sm text-slate-300">
          Draft → Publish → Lock → Archive. Amendments create a new published version.
          Operators consume only <span className="text-slate-100">PUBLISHED / LOCKED</span> artifacts.
        </div>

        <div className="mt-5 grid gap-4 md:grid-cols-4">
          <div>
            <Label className="text-slate-300">Instrument</Label>
            <Select value={instrument} onValueChange={setInstrument}>
              <SelectTrigger className="mt-1 bg-black border-slate-800">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {INSTRUMENTS.map((i) => (
                  <SelectItem key={i} value={i}>{i}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-slate-300">Week Of (YYYY-MM-DD)</Label>
            <Input className="mt-1 bg-black border-slate-800" value={weekOf} onChange={(e) => setWeekOf(e.target.value)} />
          </div>
          <div>
            <Label className="text-slate-300">Week Type</Label>
            <Select value={wkType} onValueChange={setWkType}>
              <SelectTrigger className="mt-1 bg-black border-slate-800">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {WK_TYPES.map((t) => (
                  <SelectItem key={t} value={t}>{t}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-slate-300">Confidence (0-100)</Label>
            <Input className="mt-1 bg-black border-slate-800" value={wkConfidence} onChange={(e) => setWkConfidence(e.target.value)} />
          </div>
        </div>

        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <div>
            <Label className="text-slate-300">Focus</Label>
            <Textarea className="mt-1 bg-black border-slate-800 min-h-[96px]" value={focus} onChange={(e) => setFocus(e.target.value)} placeholder="What the operator is permitted to prioritize this week." />
          </div>
          <div>
            <Label className="text-slate-300">Warning</Label>
            <Textarea className="mt-1 bg-black border-slate-800 min-h-[96px]" value={warning} onChange={(e) => setWarning(e.target.value)} placeholder="Primary failure mode / restriction note." />
          </div>
        </div>

        <div className="mt-4 grid gap-4 md:grid-cols-3">
          <div>
            <Label className="text-slate-300">Macro Cap (e.g. 0.5 / 1.0 / 2.0)</Label>
            <Input className="mt-1 bg-black border-slate-800" value={macroCap} onChange={(e) => setMacroCap(e.target.value)} />
          </div>
          <div className="md:col-span-2">
            <Label className="text-slate-300">Notes (Sentinel / macro / governance commentary)</Label>
            <Textarea className="mt-1 bg-black border-slate-800 min-h-[96px]" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Strictly governance. No trade calls." />
          </div>
        </div>

        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <div>
            <Label className="text-slate-300">Changelog Entry</Label>
            <Textarea className="mt-1 bg-black border-slate-800 min-h-[80px]" value={changelog} onChange={(e) => setChangelog(e.target.value)} placeholder="What changed since last version (plain language)." />
          </div>
          <div>
            <Label className="text-slate-300">Operator Impact</Label>
            <Textarea className="mt-1 bg-black border-slate-800 min-h-[80px]" value={operatorImpact} onChange={(e) => setOperatorImpact(e.target.value)} placeholder="What operators must do differently this week (or due to amendment)." />
          </div>
        </div>

        <div className="mt-5 grid gap-3 md:grid-cols-2">
          <div className="rounded-2xl border border-slate-800 bg-black p-4">
            <div className="text-xs uppercase tracking-widest text-slate-500">Week Context</div>
            <div className="mt-2 text-sm text-slate-300">
              Latest for this week_of: <span className="text-slate-100">{byWeekQ.data?.canon_version ?? byWeekQ.data?.version_num ?? '—'}</span>
            </div>
            <div className="mt-1 text-xs text-slate-500">
              Status: {byWeekQ.data?.status ?? '—'} • Last updated: {byWeekQ.data?.canon_last_updated ?? byWeekQ.data?.published_at ?? '—'}
            </div>
          </div>

          <div className="rounded-2xl border border-slate-800 bg-black p-4">
            <div className="text-xs uppercase tracking-widest text-slate-500">Select Published Artifact</div>
            <div className="mt-2">
              <select
                className="w-full rounded-xl border border-slate-800 bg-black px-3 py-2 text-sm text-slate-100"
                value={selectedId}
                onChange={(e) => setSelectedId(e.target.value)}
              >
                <option value="">—</option>
                {(archiveQ.data ?? []).
                  filter((r) => r?.status !== WEEKLY_STATUS.DRAFT).
                  map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.canon_version ?? `v${r.version_num ?? '?'}`} • {r.week_of ?? '—'} • {r.status ?? '—'}
                    </option>
                  ))}
              </select>
            </div>
            <div className="mt-2 text-xs text-slate-500">
              Lock freezes the artifact. Archive removes it from the active chain (still visible in archive view).
            </div>
          </div>
        </div>

        <div className="mt-5 flex flex-wrap gap-2">
          <Button variant="secondary" onClick={() => draftM.mutate()} disabled={draftM.isPending}>
            {draftM.isPending ? 'Saving…' : 'Save Draft'}
          </Button>
          <Button onClick={() => pubM.mutate()} disabled={pubM.isPending}>
            {pubM.isPending ? 'Publishing…' : 'Publish'}
          </Button>
          <Button variant="outline" onClick={() => amendM.mutate()} disabled={amendM.isPending || !selectedRow?.id}>
            {amendM.isPending ? 'Amending…' : 'Publish Amendment'}
          </Button>
          <Button variant="destructive" onClick={() => lockM.mutate()} disabled={lockM.isPending || !selectedRow?.id}>
            {lockM.isPending ? 'Locking…' : 'Lock'}
          </Button>
          <Button variant="destructive" onClick={() => archiveM.mutate()} disabled={archiveM.isPending || !selectedRow?.id}>
            {archiveM.isPending ? 'Archiving…' : 'Archive'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
