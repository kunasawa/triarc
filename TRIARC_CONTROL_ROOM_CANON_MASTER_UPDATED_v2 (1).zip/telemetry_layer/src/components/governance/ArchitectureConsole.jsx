import React, { useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';

export default function ArchitectureConsole() {
  const entities = useMemo(() => {
    const e = base44.entities || {};
    return Object.keys(e).sort((a, b) => a.localeCompare(b));
  }, []);

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card className="bg-slate-950 border-slate-800 rounded-2xl">
        <CardContent className="p-5">
          <div className="text-xs uppercase tracking-widest text-slate-500">Canonical Spine</div>
          <div className="mt-3 text-sm text-slate-300">
            Environment → Governance → Load → Opportunity → Identity
          </div>
          <div className="mt-4 rounded-xl border border-slate-800 bg-black p-4 text-sm text-slate-300">
            <div className="text-slate-100 font-medium">Telemetry contracts</div>
            <ul className="mt-2 list-disc pl-5 text-slate-400">
              <li>STATE_SNAPSHOT (Nexus) is the authoritative live-state feed.</li>
              <li>OPPORTUNITY_CREATED / UPDATED / CLEARED are ledger events (audit-grade).</li>
              <li>WeeklyClassifier produces a governance posture (week type, confidence, macro cap).</li>
              <li>Sentinel windows override execution permission (global void / probe-only).</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-slate-950 border-slate-800 rounded-2xl">
        <CardContent className="p-5">
          <div className="text-xs uppercase tracking-widest text-slate-500">Environment Inventory</div>
          <div className="mt-2 text-sm text-slate-400">Detected Base44 entities in this environment.</div>
          <div className="mt-4 max-h-[520px] overflow-auto rounded-xl border border-slate-800 bg-black">
            {entities.length === 0 ? (
              <div className="p-4 text-sm text-slate-400">No entities detected.</div>
            ) : (
              <ul className="divide-y divide-slate-800">
                {entities.map((name) => (
                  <li key={name} className="p-3 text-sm text-slate-200">{name}</li>
                ))}
              </ul>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
