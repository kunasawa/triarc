import React, { useMemo, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  listFleet,
  updateFleetMember,
  provisionUplinkKey,
  rotateUplinkKey,
  revokeUplinkKey,
  writeAudit,
} from '@/data/governance';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';

const ROLE_OPTIONS = ['operator', 'warden', 'controller', 'architect', 'admin'];
const PATH_OPTIONS = ['THE_ACADEMY', 'THE_INFIRMARY', 'THE_GAUNTLET', 'PRIME'];
const TIER_OPTIONS = ['TIER_0_AIRLOCK', 'TIER_1_CADET', 'TIER_2_REHAB', 'TIER_3_OPERATOR', 'TIER_4_PRIME'];
const PLAYBOOK_ACCESS_OPTIONS = ['ES_ONLY', 'ES_NQ', 'ALL'];

function getEmail(row) {
  return row?.email || row?.created_by || row?.operator_email || row?.operator_id || '';
}

export default function FleetConsole() {
  const qc = useQueryClient();
  const [q, setQ] = useState('');
  const [selectedId, setSelectedId] = useState(null);

  const fleetQ = useQuery({
    queryKey: ['fleet', q],
    queryFn: () => listFleet({ q, limit: 50 }),
  });

  const rows = fleetQ.data || [];
  const selected = useMemo(() => rows.find((r) => r.id === selectedId) || null, [rows, selectedId]);

  const [patch, setPatch] = useState({ role: '', tier: '', assigned_path: '', execution_entitled: '', playbook_access: '' });

  React.useEffect(() => {
    if (!selected) return;
    setPatch({
      role: (selected.role || '').toString(),
      tier: (selected.tier || '').toString(),
      assigned_path: (selected.assigned_path || selected.pathway || '').toString(),
      execution_entitled: selected.execution_entitled === true ? 'true' : selected.execution_entitled === false ? 'false' : '',
      playbook_access: (selected.playbook_access || '').toString(),
    });
  }, [selectedId]);

  const updateM = useMutation({
    mutationFn: async () => {
      if (!selected?.id) throw new Error('No operator selected');

      const p = {};
      if (patch.role) p.role = patch.role;
      if (patch.tier) p.tier = patch.tier;
      if (patch.assigned_path) p.assigned_path = patch.assigned_path;
      if (patch.execution_entitled) p.execution_entitled = patch.execution_entitled === 'true';
      if (patch.playbook_access) p.playbook_access = patch.playbook_access;

      const out = await updateFleetMember(selected.id, p);
      const email = getEmail(selected);
      await writeAudit({
        operator_email: email,
        action_type: 'FLEET_MEMBER_UPDATE',
        entity_type: 'Profile',
        details: p,
      });
      return out;
    },
    onSuccess: () => {
      toast.success('Profile updated');
      qc.invalidateQueries({ queryKey: ['fleet'] });
    },
    onError: (e) => toast.error(e?.message || 'Update failed'),
  });

  const provisionM = useMutation({
    mutationFn: async ({ rotate = false } = {}) => {
      if (!selected?.id) throw new Error('No operator selected');
      const operator_email = getEmail(selected);
      const path = patch.assigned_path || selected.assigned_path || 'THE_ACADEMY';
      const tier = patch.tier || selected.tier || 'TIER_1_CADET';

      if (rotate) {
        return await rotateUplinkKey({
          operator_email,
          new_tier: tier,
          new_path: path,
          trigger_event: 'Manual rotation (console)',
        });
      }

      return await provisionUplinkKey({ operator_email, path, tier, profile_id: selected.id, revoke_previous: false });
    },
    onSuccess: () => {
      toast.success('Uplink key issued');
      qc.invalidateQueries({ queryKey: ['fleet'] });
    },
    onError: (e) => toast.error(e?.message || 'Uplink action failed'),
  });

  const revokeM = useMutation({
    mutationFn: async () => {
      const email = getEmail(selected);
      if (!email) throw new Error('No operator email found');
      const out = await revokeUplinkKey({ operator_email: email, trigger_event: 'Manual revoke (console)' });
      await writeAudit({
        operator_email: email,
        action_type: 'UPLINK_REVOKE',
        entity_type: 'UplinkKey',
        details: { operator_email: email },
      });
      return out;
    },
    onSuccess: () => {
      toast.success('Uplink revoked');
      qc.invalidateQueries({ queryKey: ['fleet'] });
    },
    onError: (e) => toast.error(e?.message || 'Revoke failed'),
  });

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card className="bg-slate-950 border-slate-800 rounded-2xl">
        <CardContent className="p-5">
          <div className="text-xs uppercase tracking-widest text-slate-500">Fleet</div>
          <div className="mt-3 flex gap-2">
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search by email (best-effort)"
              className="bg-black border-slate-800"
            />
            <Button variant="secondary" onClick={() => fleetQ.refetch()}>
              Refresh
            </Button>
          </div>

          <div className="mt-4 max-h-[520px] overflow-auto rounded-xl border border-slate-800">
            {rows.length === 0 ? (
              <div className="p-4 text-sm text-slate-400">No operators found.</div>
            ) : (
              <ul className="divide-y divide-slate-800">
                {rows.map((r) => {
                  const email = getEmail(r);
                  const active = r.id === selectedId;
                  return (
                    <li key={r.id}>
                      <button
                        className={`w-full text-left p-3 hover:bg-slate-900 ${active ? 'bg-slate-900' : ''}`}
                        onClick={() => setSelectedId(r.id)}
                      >
                        <div className="text-sm text-slate-100 truncate">{email || '(unknown email)'}</div>
                        <div className="mt-1 text-xs text-slate-500">
                          role: {(r.role || '—').toString()} • tier: {(r.tier || '—').toString()} • path:{' '}
                          {(r.assigned_path || r.pathway || '—').toString()}
                        </div>
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-slate-950 border-slate-800 rounded-2xl lg:col-span-2">
        <CardContent className="p-5">
          <div className="text-xs uppercase tracking-widest text-slate-500">Controller Console</div>

          {!selected ? (
            <div className="mt-4 rounded-xl border border-slate-800 bg-black p-4 text-sm text-slate-400">
              Select an operator from the Fleet list.
            </div>
          ) : (
            <>
              <div className="mt-4 grid gap-4 md:grid-cols-3">
                <div>
                  <Label className="text-slate-300">Role</Label>
                  <Select value={patch.role || ''} onValueChange={(v) => setPatch((p) => ({ ...p, role: v }))}>
                    <SelectTrigger className="mt-1 bg-black border-slate-800">
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      {ROLE_OPTIONS.map((r) => (
                        <SelectItem key={r} value={r}>
                          {r}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-slate-300">Tier</Label>
                  <Select value={patch.tier || ''} onValueChange={(v) => setPatch((p) => ({ ...p, tier: v }))}>
                    <SelectTrigger className="mt-1 bg-black border-slate-800">
                      <SelectValue placeholder="Select tier" />
                    </SelectTrigger>
                    <SelectContent>
                      {TIER_OPTIONS.map((t) => (
                        <SelectItem key={t} value={t}>
                          {t}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-slate-300">Pathway</Label>
                  <Select
                    value={patch.assigned_path || ''}
                    onValueChange={(v) => setPatch((p) => ({ ...p, assigned_path: v }))}
                  >
                    <SelectTrigger className="mt-1 bg-black border-slate-800">
                      <SelectValue placeholder="Select pathway" />
                    </SelectTrigger>
                    <SelectContent>
                      {PATH_OPTIONS.map((p) => (
                        <SelectItem key={p} value={p}>
                          {p}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <div>
                  <Label className="text-slate-300">Execution Entitled</Label>
                  <Select
                    value={patch.execution_entitled || ''}
                    onValueChange={(v) => setPatch((p) => ({ ...p, execution_entitled: v }))}
                  >
                    <SelectTrigger className="mt-1 bg-black border-slate-800">
                      <SelectValue placeholder="(no change)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="true">true</SelectItem>
                      <SelectItem value="false">false</SelectItem>
                    </SelectContent>
                  </Select>
                  <div className="mt-1 text-xs text-slate-500">Governance gate for Execution surfaces.</div>
                </div>

                <div>
                  <Label className="text-slate-300">Playbook Access</Label>
                  <Select
                    value={patch.playbook_access || ''}
                    onValueChange={(v) => setPatch((p) => ({ ...p, playbook_access: v }))}
                  >
                    <SelectTrigger className="mt-1 bg-black border-slate-800">
                      <SelectValue placeholder="(no change)" />
                    </SelectTrigger>
                    <SelectContent>
                      {PLAYBOOK_ACCESS_OPTIONS.map((a) => (
                        <SelectItem key={a} value={a}>
                          {a}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div className="mt-1 text-xs text-slate-500">ES_ONLY (Academy), ES_NQ (Infirmary), ALL (Gauntlet).</div>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                <Button onClick={() => updateM.mutate()} disabled={updateM.isPending}>
                  {updateM.isPending ? 'Updating…' : 'Apply Profile Patch'}
                </Button>
                <Button variant="secondary" onClick={() => provisionM.mutate({ rotate: false })} disabled={provisionM.isPending}>
                  Issue Uplink Key
                </Button>
                <Button variant="destructive" onClick={() => provisionM.mutate({ rotate: true })} disabled={provisionM.isPending}>
                  Rotate Key (Revoke Prior)
                </Button>
                <Button
                  variant="outline"
                  onClick={() => revokeM.mutate()}
                  disabled={revokeM.isPending}
                  className="border-slate-700 text-slate-200"
                >
                  {revokeM.isPending ? 'Revoking…' : 'Revoke Key'}
                </Button>
              </div>

              <Separator className="my-5 bg-slate-800" />

              <div className="grid gap-3 md:grid-cols-2">
                <div className="rounded-xl border border-slate-800 bg-black p-4">
                  <div className="text-xs uppercase tracking-widest text-slate-500">Identity</div>
                  <div className="mt-2 text-sm text-slate-200">{getEmail(selected)}</div>
                  <div className="mt-2 text-xs text-slate-500">Profile ID: {selected.id}</div>
                  <div className="mt-2 text-xs text-slate-500">
                    execution_entitled: {selected.execution_entitled === true ? 'true' : selected.execution_entitled === false ? 'false' : '—'}
                  </div>
                  <div className="mt-1 text-xs text-slate-500">playbook_access: {selected.playbook_access || '—'}</div>
                </div>
                <div className="rounded-xl border border-slate-800 bg-black p-4">
                  <div className="text-xs uppercase tracking-widest text-slate-500">Uplink</div>
                  <div className="mt-2 text-sm text-slate-200 break-all">{selected.uplink_key || '—'}</div>
                  <div className="mt-2 text-xs text-slate-500">Key is stored on Profile when supported by schema.</div>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
