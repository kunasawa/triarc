import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useNexusLiveFleet } from "@/data/hooks";
import { getComplianceSummary } from "@/data/api";
import { computeStabilityIndex, stabilityColor, stabilityLabel } from "@/data/stabilityIndex";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";

const asNum = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

const fmtTs = (ms) => {
  const n = asNum(ms);
  if (!n) return "—";
  try {
    return new Date(n).toLocaleString();
  } catch {
    return String(n);
  }
};

function pick(row, keys, fallback = "—") {
  for (const k of keys) {
    const v = row?.[k];
    if (v !== undefined && v !== null && String(v).length) return v;
  }
  return fallback;
}

function normalizeState(row) {
  // NexusStateLive schema varies; normalize into a minimal doctrine-aligned surface.
  const uplink_key = pick(row, ["uplink_key", "uplinkKey", "uplink"], "—");
  const symbol = pick(row, ["symbol_id", "symbol", "meta_symbol"], "—");
  const tf = pick(row, ["tf", "timeframe", "meta_tf"], "—");

  const gov_state = pick(row, ["gov_state", "governance_state", "state"], "—");
  const is_permitted = row?.is_permitted ?? row?.permitted ?? null;
  const denial_reason = pick(row, ["denial_reason", "reason", "deny_reason"], "—");
  const sentinel_state = row?.sentinel_state ?? row?.sentinel ?? null;
  const wk_type = pick(row, ["wk_type", "week_type", "weekly_type"], "—");
  const wk_confidence = row?.wk_confidence ?? row?.week_confidence ?? null;
  const matrix_healthy = row?.matrix_healthy ?? row?.matrix_ok ?? null;
  const navigator_bias = pick(row, ["navigator_bias", "bias"], "—");

  const servo_decision = pick(row, ["servo_decision", "load_decision"], "—");
  const servo_reason = pick(row, ["servo_reason", "load_reason"], "—");
  const risk_multiplier = row?.risk_multiplier ?? row?.risk_mult ?? null;
  const env_cap = row?.env_cap ?? row?.cap ?? null;

  const last_seen =
    row?.last_seen_timestamp_ms ??
    row?.event_time_ms ??
    row?.timestamp_ms ??
    row?.updated_at ??
    row?.created_date ??
    null;

  const opp_active = row?.opp_active ?? row?.opportunity_active ?? null;
  const opp_side = pick(row, ["opp_side", "opportunity_side"], "—");
  const opp_name = pick(row, ["opp_name", "opportunity_name"], "—");
  const opp_score = row?.opp_score ?? row?.opportunity_score ?? null;

  return {
    id: row?.id ?? `${uplink_key}:${String(last_seen ?? "—")}`,
    uplink_key,
    symbol,
    tf,
    last_seen,
    gov_state,
    is_permitted,
    denial_reason,
    sentinel_state,
    wk_type,
    wk_confidence,
    matrix_healthy,
    navigator_bias,
    servo_decision,
    servo_reason,
    risk_multiplier,
    env_cap,
    opp_active,
    opp_side,
    opp_name,
    opp_score,
  };
}

function chipClass(kind) {
  if (kind === "OK") return "bg-emerald-900/30 border-emerald-800 text-emerald-200";
  if (kind === "WARN") return "bg-amber-900/30 border-amber-800 text-amber-200";
  if (kind === "BLOCK") return "bg-red-900/30 border-red-800 text-red-200";
  return "bg-slate-900/30 border-slate-800 text-slate-200";
}

function permKind(r) {
  if (r == null) return "NEUTRAL";
  return r ? "OK" : "BLOCK";
}

export default function FleetTelemetryConsole() {
  const fleetQ = useNexusLiveFleet(250);
  const [q, setQ] = useState("");
  const [selectedId, setSelectedId] = useState(null);
  const [complianceMap, setComplianceMap] = useState({});
  const [stabilityMap, setStabilityMap] = useState({});

  const rows = useMemo(() => {
    const raw = fleetQ.data ?? [];
    const norm = raw.map(normalizeState);
    const query = q.trim().toLowerCase();
    const filtered = !query
      ? norm
      : norm.filter((r) =>
          [r.uplink_key, r.symbol, r.gov_state, r.wk_type, r.navigator_bias]
            .join(" ")
            .toLowerCase()
            .includes(query)
        );

    // Prefer freshest first.
    return filtered.sort((a, b) => {
      const ta = asNum(a.last_seen) ?? 0;
      const tb = asNum(b.last_seen) ?? 0;
      return tb - ta;
    });
  }, [fleetQ.data, q]);

  const selected = useMemo(() => rows.find((r) => r.id === selectedId) ?? null, [rows, selectedId]);

  // Best-effort compliance badges for the currently visible set.
  // Governance-only: used to prioritize remediation and review.
  useEffect(() => {
    const visible = rows.slice(0, 40).map((r) => r.uplink_key).filter((k) => k && k !== "—");
    const unique = Array.from(new Set(visible));

    const missingCompliance = unique.filter((k) => complianceMap[k] == null);
    const missingStability  = unique.filter((k) => stabilityMap[k] == null);

    if (!missingCompliance.length && !missingStability.length) return;

    let cancelled = false;

    const run = async () => {
      const nextCompliance = {};
      const nextStability  = {};
      const limit = 6;

      // Build a unified work queue so we don't double-hit the same uplink key.
      const queue = Array.from(new Set([...missingCompliance, ...missingStability]));
      let idx = 0;

      const workers = Array.from({ length: Math.min(limit, queue.length) }).map(async () => {
        while (idx < queue.length) {
          const k = queue[idx++];
          // Compliance
          if (missingCompliance.includes(k)) {
            try {
              const s = await getComplianceSummary({ uplink_key: k });
              nextCompliance[k] = s ?? null;
            } catch {
              nextCompliance[k] = null;
            }
          }
          // Stability
          if (missingStability.includes(k)) {
            try {
              const st = await computeStabilityIndex({ uplink_key: k });
              nextStability[k] = st ?? null;
            } catch {
              nextStability[k] = null;
            }
          }
        }
      });

      await Promise.all(workers);

      if (cancelled) return;
      if (Object.keys(nextCompliance).length) {
        setComplianceMap((prev) => ({ ...prev, ...nextCompliance }));
      }
      if (Object.keys(nextStability).length) {
        setStabilityMap((prev) => ({ ...prev, ...nextStability }));
      }
    };

    run();
    return () => {
      cancelled = true;
    };
  }, [rows, complianceMap, stabilityMap]);

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card className="bg-slate-950 border-slate-800 rounded-2xl">
        <CardContent className="p-5">
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="text-xs uppercase tracking-widest text-slate-500">Fleet Pulse</div>
              <div className="mt-1 text-xs text-slate-400">Live state snapshots (best-effort schema)</div>
            </div>
            <Button variant="secondary" onClick={() => fleetQ.refetch()}>
              Refresh
            </Button>
          </div>

          <div className="mt-3">
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Filter (uplink, symbol, week type, bias…)"
              className="bg-black border-slate-800"
            />
          </div>

          <div className="mt-4 max-h-[520px] overflow-auto rounded-xl border border-slate-800">
            {fleetQ.isLoading ? (
              <div className="p-4 text-sm text-slate-400">Loading…</div>
            ) : rows.length === 0 ? (
              <div className="p-4 text-sm text-slate-400">No fleet state records found.</div>
            ) : (
              <ul className="divide-y divide-slate-800">
                {rows.map((r) => {
                  const active = r.id === selectedId;
                  const kind = permKind(r.is_permitted);
                  const comp = complianceMap[r.uplink_key];
                  const compScore = comp?.score ?? comp?.compliance_score ?? null;
                  const openCases = comp?.open_cases ?? comp?.open_remediation ?? null;
                  const execHold = !!(comp?.execution_hold ?? comp?.hold ?? false);
                  const st = stabilityMap[r.uplink_key];
                  const stIndex = st?.stability_index ?? null;
                  return (
                    <li key={r.id}>
                      <button
                        className={`w-full text-left p-3 hover:bg-slate-900 ${active ? "bg-slate-900" : ""}`}
                        onClick={() => setSelectedId(r.id)}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="text-xs text-slate-300 truncate">{r.uplink_key}</div>
                          <div className="flex items-center gap-2">
                            {execHold ? (
                              <div className="rounded-full border border-red-900 bg-red-950/40 px-2 py-0.5 text-[10px] text-red-200">
                                HOLD
                              </div>
                            ) : null}
                            {compScore != null ? (
                              <div className="rounded-full border border-slate-800 bg-slate-900/30 px-2 py-0.5 text-[10px] text-slate-200">
                                COMP {String(compScore)}
                                {openCases != null ? ` • OPEN ${String(openCases)}` : ""}
                              
{stIndex != null ? (
  <div className={`rounded-full border border-slate-800 px-2 py-0.5 text-[10px] text-slate-100 ${stabilityColor(stIndex)}`}>
    STABILITY {String(stIndex)} • {stabilityLabel(stIndex)}
  </div>
) : null}
                            <div className={`rounded-full border px-2 py-0.5 text-[10px] ${chipClass(kind)}`}>
                              {r.is_permitted == null ? "—" : r.is_permitted ? "PERMITTED" : "RESTRICTED"}
                            </div>
                          </div>
                        </div>
                        <div className="mt-1 text-xs text-slate-500">
                          {r.symbol} • {r.tf} • {r.gov_state}
                        </div>
                        <div className="mt-1 text-xs text-slate-600">
                          {r.wk_type} • bias: {r.navigator_bias} • seen: {fmtTs(r.last_seen)}
                        </div>
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-slate-950 border-slate-800 rounded-2xl lg:col-span-2">
        <CardContent className="p-5">
          <div className="text-xs uppercase tracking-widest text-slate-500">State Detail</div>

          {!selected ? (
            <div className="mt-4 rounded-xl border border-slate-800 bg-black p-4 text-sm text-slate-400">
              Select an uplink from the Fleet list.
            </div>
          ) : (
            <>
              <div className="mt-4 grid gap-3 md:grid-cols-2">
                <div className="rounded-xl border border-slate-800 bg-black p-4">
                  <div className="text-xs uppercase tracking-widest text-slate-500">Identity</div>
                  <div className="mt-2 text-sm text-slate-200 break-all">{selected.uplink_key}</div>
                  <div className="mt-1 text-xs text-slate-500">Last seen: {fmtTs(selected.last_seen)}</div>
                  <div className="mt-1 text-xs text-slate-500">Symbol: {selected.symbol} • TF: {selected.tf}</div>

                  <div className="mt-3 flex flex-wrap gap-2">
                    <Link
                      to={`/nexus/telemetry?uplink=${encodeURIComponent(selected.uplink_key)}`}
                      className="rounded-xl border border-slate-800 bg-black/30 px-3 py-2 text-[10px] font-semibold text-slate-200 hover:bg-black/50"
                    >
                      OPEN TELEMETRY
                    </Link>
                    <Link
                      to={`/governance/compliance?uplink=${encodeURIComponent(selected.uplink_key)}`}
                      className="rounded-xl border border-slate-800 bg-black/30 px-3 py-2 text-[10px] font-semibold text-slate-200 hover:bg-black/50"
                    >
                      OPEN COMPLIANCE
                    </Link>
                    <Link
                      to={`/governance/training-audit?uplink=${encodeURIComponent(selected.uplink_key)}`}
                      className="rounded-xl border border-slate-800 bg-black/30 px-3 py-2 text-[10px] font-semibold text-slate-200 hover:bg-black/50"
                    >
                      OPEN TRAINING
                    </Link>
                  </div>
                </div>
                <div className="rounded-xl border border-slate-800 bg-black p-4">
                  <div className="text-xs uppercase tracking-widest text-slate-500">Governance</div>
                  <div className="mt-2 text-sm text-slate-200">{selected.gov_state}</div>
                  <div className="mt-1 text-xs text-slate-500">
                    Permission: {selected.is_permitted == null ? "—" : selected.is_permitted ? "ACTIVE" : "RESTRICTED"}
                  </div>
                  <div className="mt-1 text-xs text-slate-500">Denial: {selected.denial_reason}</div>
                  <div className="mt-1 text-xs text-slate-500">Sentinel: {String(selected.sentinel_state ?? "—")}</div>
                </div>
              </div>

              <Separator className="my-5 bg-slate-800" />

              <div className="grid gap-3 md:grid-cols-3">
                <div className="rounded-xl border border-slate-800 bg-black p-4">
                  <div className="text-xs uppercase tracking-widest text-slate-500">Weekly</div>
                  <div className="mt-2 text-sm text-slate-200">{selected.wk_type}</div>
                  <div className="mt-1 text-xs text-slate-500">Confidence: {String(selected.wk_confidence ?? "—")}</div>
                  <div className="mt-1 text-xs text-slate-500">Bias: {selected.navigator_bias}</div>
                </div>
                <div className="rounded-xl border border-slate-800 bg-black p-4">
                  <div className="text-xs uppercase tracking-widest text-slate-500">Matrix</div>
                  <div className="mt-2 text-sm text-slate-200">{String(selected.matrix_healthy ?? "—")}</div>
                  <div className="mt-1 text-xs text-slate-500">(health gate for Vector)</div>
                </div>
                <div className="rounded-xl border border-slate-800 bg-black p-4">
                  <div className="text-xs uppercase tracking-widest text-slate-500">Servo</div>
                  <div className="mt-2 text-sm text-slate-200">{selected.servo_decision}</div>
                  <div className="mt-1 text-xs text-slate-500">Reason: {selected.servo_reason}</div>
                  <div className="mt-1 text-xs text-slate-500">Load: {String(selected.risk_multiplier ?? "—")}x • Cap: {String(selected.env_cap ?? "—")}x</div>
                </div>
              </div>

              <Separator className="my-5 bg-slate-800" />

              <div className="rounded-xl border border-slate-800 bg-black p-4">
                <div className="text-xs uppercase tracking-widest text-slate-500">Opportunity (Governed)</div>
                <div className="mt-2 text-sm text-slate-200">
                  {selected.opp_active == null ? "—" : selected.opp_active ? "ACTIVE" : "INACTIVE"}
                </div>
                <div className="mt-1 text-xs text-slate-500">
                  {selected.opp_side} • {selected.opp_name} • score: {String(selected.opp_score ?? "—")}
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
