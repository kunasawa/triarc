import React, { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { listSentinelEvents, upsertSentinelEvent } from '@/data/governance';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';

const TYPES = ['FOMC', 'NFP', 'CPI', 'PPI', 'EIA', 'OTHER'];

export default function SentinelConsole() {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ['sentinel-events'],
    queryFn: () => listSentinelEvents({ activeOnly: false, limit: 50 }),
  });

  const [active, setActive] = useState(true);
  const [type, setType] = useState('FOMC');
  const [timeUtc, setTimeUtc] = useState('');
  const [minsBefore, setMinsBefore] = useState('');
  const [minsAfter, setMinsAfter] = useState('');

  const saveM = useMutation({
    mutationFn: async () => {
      if (!timeUtc) throw new Error('Event time is required');
      const patch = {
        active,
        event_type: type,
        event_time_utc: timeUtc,
        mins_before: minsBefore ? Number(minsBefore) : 0,
        mins_after: minsAfter ? Number(minsAfter) : 0,
      };
      return await upsertSentinelEvent({ patch });
    },
    onSuccess: () => {
      toast.success('Sentinel event saved');
      qc.invalidateQueries({ queryKey: ['sentinel-events'] });
    },
    onError: (e) => toast.error(e?.message || 'Save failed'),
  });

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card className="bg-slate-950 border-slate-800 rounded-2xl">
        <CardContent className="p-5">
          <div className="text-xs uppercase tracking-widest text-slate-500">Sentinel Events</div>
          <div className="mt-1 text-sm text-slate-300">Manual event registry (fallback). Primary source is the Sentinel engine inside Nexus.</div>

          <div className="mt-4 grid gap-4 md:grid-cols-2">
            <div>
              <Label className="text-slate-300">Type</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger className="mt-1 bg-black border-slate-800"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-slate-300">Active</Label>
              <div className="mt-2 flex items-center gap-3">
                <Switch checked={active} onCheckedChange={setActive} />
                <span className="text-sm text-slate-300">{active ? 'Active' : 'Inactive'}</span>
              </div>
            </div>
            <div className="md:col-span-2">
              <Label className="text-slate-300">Event Time (UTC, ISO)</Label>
              <Input className="mt-1 bg-black border-slate-800" value={timeUtc} onChange={(e) => setTimeUtc(e.target.value)} placeholder="2026-02-18T19:00:00Z" />
            </div>
            <div>
              <Label className="text-slate-300">Minutes Before (optional)</Label>
              <Input className="mt-1 bg-black border-slate-800" value={minsBefore} onChange={(e) => setMinsBefore(e.target.value)} placeholder="30" />
            </div>
            <div>
              <Label className="text-slate-300">Minutes After (optional)</Label>
              <Input className="mt-1 bg-black border-slate-800" value={minsAfter} onChange={(e) => setMinsAfter(e.target.value)} placeholder="60" />
            </div>
          </div>

          <div className="mt-5">
            <Button onClick={() => saveM.mutate()} disabled={saveM.isPending}>
              {saveM.isPending ? 'Saving…' : 'Save Event'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-slate-950 border-slate-800 rounded-2xl">
        <CardContent className="p-5">
          <div className="text-xs uppercase tracking-widest text-slate-500">Registry</div>
          <div className="mt-4 max-h-[520px] overflow-auto rounded-xl border border-slate-800">
            {q.isLoading ? (
              <div className="p-4 text-sm text-slate-400">Loading…</div>
            ) : (q.data || []).length === 0 ? (
              <div className="p-4 text-sm text-slate-400">No events recorded.</div>
            ) : (
              <ul className="divide-y divide-slate-800">
                {(q.data || []).map((ev) => (
                  <li key={ev.id} className="p-3">
                    <div className="text-sm text-slate-100">{(ev.event_type || ev.type || 'EVENT').toString()} {ev.active ? '• active' : '• inactive'}</div>
                    <div className="mt-1 text-xs text-slate-500 break-all">
                      {(ev.event_time_utc || ev.event_time || ev.time || '—').toString()}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
