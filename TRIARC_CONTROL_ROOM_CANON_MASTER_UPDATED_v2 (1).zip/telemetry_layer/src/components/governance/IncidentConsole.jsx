import React, { useMemo, useState } from 'react';
import PanelCard from '@/components/controlroom/PanelCard';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useIncidents, useEnforcementActions } from '@/data/hooks';

const statusBadge = (s) => {
  const v = (s || '—').toString().toUpperCase();
  if (v === 'OPEN') return <Badge variant="destructive">OPEN</Badge>;
  if (v === 'ACK') return <Badge variant="secondary">ACK</Badge>;
  if (v === 'CLOSED') return <Badge variant="outline">CLOSED</Badge>;
  return <Badge variant="outline">—</Badge>;
};

export default function IncidentConsole({ initialUplinkKey } = {}) {
  const [uplink, setUplink] = useState(initialUplinkKey ? String(initialUplinkKey) : 'ALL');
  const [tab, setTab] = useState('INCIDENTS');

  const uplink_key = uplink === 'ALL' ? undefined : uplink;
  const incidents = useIncidents({ uplink_key, status: undefined, limit: 200 });
  const actions = useEnforcementActions({ uplink_key, limit: 200 });

  const rowsInc = useMemo(() => (Array.isArray(incidents.data) ? incidents.data : []), [incidents.data]);
  const rowsAct = useMemo(() => (Array.isArray(actions.data) ? actions.data : []), [actions.data]);

  return (
    <PanelCard
      title="GOVERNANCE • INCIDENTS & ENFORCEMENT"
      subtitle="Fleet-level incident ledger. Governance actions are logged as permission controls, not execution calls."
      right={
        <div className="flex items-center gap-2">
          <select
            value={uplink}
            onChange={(e) => setUplink(e.target.value)}
            className="rounded-xl border border-slate-800 bg-black px-3 py-2 text-xs text-slate-100"
          >
            <option value="ALL">ALL UPLINKS</option>
            {/* Options are intentionally minimal here. Deep-links should pass uplink= */}
          </select>
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              incidents.refetch();
              actions.refetch();
            }}
          >
            Refresh
          </Button>
        </div>
      }
    >
      <div className="flex items-center gap-2">
        <button
          onClick={() => setTab('INCIDENTS')}
          className={`rounded-xl border px-3 py-2 text-xs ${tab === 'INCIDENTS' ? 'border-slate-500 bg-slate-900 text-white' : 'border-slate-800 bg-black text-slate-300'}`}
        >
          INCIDENTS
        </button>
        <button
          onClick={() => setTab('ENFORCEMENT')}
          className={`rounded-xl border px-3 py-2 text-xs ${tab === 'ENFORCEMENT' ? 'border-slate-500 bg-slate-900 text-white' : 'border-slate-800 bg-black text-slate-300'}`}
        >
          ENFORCEMENT LOG
        </button>
      </div>

      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <div className="rounded-2xl border border-slate-800 bg-black/30 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500">
            {tab === 'INCIDENTS' ? 'Incidents' : 'Enforcement Actions'}
          </div>

          <div className="mt-3 space-y-2">
            {tab === 'INCIDENTS' ? (
              incidents.isLoading ? (
                <div className="text-xs text-slate-400">Loading…</div>
              ) : rowsInc.length ? (
                rowsInc.slice(0, 25).map((i) => (
                  <div key={i?.id} className="rounded-xl border border-slate-800 bg-slate-950 p-3">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="text-sm text-slate-100">{i?.title ?? i?.incident_type ?? 'INCIDENT'}</div>
                        <div className="mt-1 text-xs text-slate-400">
                          {i?.uplink_key ? `Uplink: ${i.uplink_key}` : '—'}
                          {i?.created_at ? ` • ${i.created_at}` : ''}
                        </div>
                        {i?.summary ? <div className="mt-2 text-xs text-slate-500">{i.summary}</div> : null}
                      </div>
                      {statusBadge(i?.status)}
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-xs text-slate-400">No incidents recorded.</div>
              )
            ) : actions.isLoading ? (
              <div className="text-xs text-slate-400">Loading…</div>
            ) : rowsAct.length ? (
              rowsAct.slice(0, 25).map((a) => (
                <div key={a?.id} className="rounded-xl border border-slate-800 bg-slate-950 p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-sm text-slate-100">{a?.action_type ?? 'ENFORCEMENT'}</div>
                      <div className="mt-1 text-xs text-slate-400">
                        {a?.uplink_key ? `Uplink: ${a.uplink_key}` : '—'}
                        {a?.created_at ? ` • ${a.created_at}` : ''}
                      </div>
                      {a?.reason ? <div className="mt-2 text-xs text-slate-500">{a.reason}</div> : null}
                    </div>
                    <Badge variant="outline">{(a?.result || 'LOGGED').toString().toUpperCase()}</Badge>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-xs text-slate-400">No enforcement actions recorded.</div>
            )}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-black/30 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500">Doctrine</div>
          <div className="mt-3 space-y-3 text-sm text-slate-200">
            <div className="rounded-xl border border-slate-800 bg-black p-3 text-xs text-slate-300">
              Incidents are governance records. They justify permission adjustments (holds, restrictions, required training),
              not public marketing.
            </div>
            <div className="rounded-xl border border-slate-800 bg-black p-3 text-xs text-slate-300">
              Enforcement is logged to preserve auditability. If an operator is restricted, the restriction should be
              visible across Fleet, Compliance, and Nexus Telemetry.
            </div>
          </div>
        </div>
      </div>
    </PanelCard>
  );
}
