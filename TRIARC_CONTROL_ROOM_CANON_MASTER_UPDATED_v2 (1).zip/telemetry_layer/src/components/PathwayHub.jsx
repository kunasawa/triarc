import React, { useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { TRAINING_MODULES, TRAINING_PATHWAYS } from '@/data/trainingRegistry';
import { findDocById } from '@/data/libraryRegistry';
import { canViewArtifact, SURFACE } from '@/data/rolloutPolicy';
import { getProgress, setModuleComplete, pathwayCompletionRate } from '@/lib/trainingProgress';
import { recordTrainingProgress, submitTrainingCheckpoint } from '@/data/trainingAudit';
import { useAuth } from '@/lib/AuthContext';
import { useIdentity } from '@/data/hooks';

export default function PathwayHub({ pathway }) {
  const { user } = useAuth();
  const email = user?.email || user?.username || 'anon';
  const idQ = useIdentity();
  const uplink_key = idQ.data?.uplink_key ?? null;
  const cfg = TRAINING_PATHWAYS[pathway];
  const modules = TRAINING_MODULES[pathway] || [];

  const [tick, setTick] = useState(0);
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [checkpointOpen, setCheckpointOpen] = useState(false);
  const [checkpointText, setCheckpointText] = useState('');
  const [checkpointModule, setCheckpointModule] = useState(null);


  const prog = useMemo(() => {
    void tick;
    return getProgress(email, pathway);
  }, [email, pathway, tick]);

  const rate = useMemo(() => pathwayCompletionRate(email, pathway), [email, pathway, tick]);

  if (!cfg) {
    return (
      <div className="min-h-screen bg-black text-slate-100">
        <div className="mx-auto max-w-6xl px-6 py-10">
          <div className="text-sm text-slate-300">Unknown pathway.</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-slate-100">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="text-xs tracking-widest text-slate-400">TRIARC • TRAINING SURFACE</div>
        <h1 className="mt-2 text-2xl font-semibold">{cfg.label}</h1>
        <p className="mt-3 max-w-2xl text-sm text-slate-300">{cfg.subtitle}</p>

        <div className="mt-8 grid gap-4 md:grid-cols-3">
          <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5 md:col-span-1">
            <div className="text-xs uppercase tracking-widest text-slate-500">Progress</div>
            <div className="mt-2 text-3xl font-semibold">{rate.pct}%</div>
            <div className="mt-1 text-sm text-slate-300">
              {rate.done} of {rate.total} modules marked complete.
            </div>
            <div className="mt-4 text-xs text-slate-400">
              Progress is stored locally per device and is audited when Training entities are provisioned.
            </div>
          </div>

          <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5 md:col-span-2">
            <div className="text-xs uppercase tracking-widest text-slate-500">Module Spine</div>
            <div className="mt-3 space-y-3">
              {modules.map((m) => {
                const done = !!prog[m.id];
                const libDoc = m.docId ? findDocById(m.docId) : null;
                const canOpen = m.docId ? canViewArtifact({ user, doc: libDoc || { id: m.docId, category: 'training', status: 'UNBOUND' }, surface: SURFACE.TRAINING }) : false;
                return (
                  <div key={m.id} className="rounded-xl border border-slate-800 bg-black/40 p-4">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <div className="text-sm font-semibold">{m.title}</div>
                        <div className="mt-1 text-xs text-slate-400">{m.phase} • {m.status}</div>
                        <div className="mt-2 text-sm text-slate-300">{m.focus}</div>
                        {m.tags?.length ? (
                          <div className="mt-2 flex flex-wrap gap-2">
                            {m.tags.map((t) => (
                              <span key={t} className="rounded-full border border-slate-800 bg-slate-950 px-2 py-0.5 text-[11px] text-slate-300">
                                {t}
                              </span>
                            ))}
                          </div>
                        ) : null}
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          className={`rounded-xl px-3 py-2 text-xs font-semibold border ${
                            canOpen
                              ? 'border-slate-800 bg-slate-950 text-slate-200 hover:bg-slate-900'
                              : 'border-slate-800 bg-black/30 text-slate-500 cursor-not-allowed'
                          }`}
                          disabled={!canOpen}
                          onClick={() => {
                            if (!canOpen) return;
                            if (m.docId) navigate(`/library?doc=${encodeURIComponent(m.docId)}`);
                            else navigate('/library');
                          }}
                        >
                          {canOpen ? 'OPEN DOC' : 'DOC LOCKED'}
                        </button>
                        <button
                          className="rounded-xl px-3 py-2 text-xs font-semibold border border-slate-800 bg-slate-950 text-slate-200 hover:bg-slate-900"
                          onClick={() => {
                            setCheckpointModule(m);
                            setCheckpointText('');
                            setCheckpointOpen(true);
                          }}
                        >
                          CHECKPOINT
                        </button>
                        <button
                          className={`rounded-xl px-3 py-2 text-xs font-semibold border ${
                            done
                              ? 'border-emerald-700 bg-emerald-950/40 text-emerald-200'
                              : 'border-slate-700 bg-slate-950 text-slate-200 hover:bg-slate-900'
                          }`}
                          onClick={() => {
                            setModuleComplete(email, pathway, m.id, !done);
                            // Best-effort audit write (never blocks UI)
                            recordTrainingProgress({
                              operator_email: email,
                              pathway,
                              module_id: m.id,
                              complete: !done,
                            }).catch(() => {});
                            setTick((n) => n + 1);
                          }}
                        >
                          {done ? 'COMPLETED' : 'MARK COMPLETE'}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}

              {!modules.length ? (
                <div className="rounded-xl border border-slate-800 bg-black/40 p-4 text-sm text-slate-300">
                  No modules registered for this pathway.
                </div>
              ) : null}
            </div>
          </div>
        </div>


        {checkpointOpen && checkpointModule ? (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-6">
            <div className="w-full max-w-xl rounded-2xl border border-slate-800 bg-slate-950 p-6">
              <div className="text-xs tracking-widest text-slate-400">TRAINING CHECKPOINT</div>
              <div className="mt-2 text-lg font-semibold">{checkpointModule.title}</div>
              <p className="mt-2 text-sm text-slate-300">
                Submit a short reflection. This is stored locally and is audited when Training Submission entities are provisioned.
              </p>
              <textarea
                className="mt-4 h-36 w-full rounded-xl border border-slate-800 bg-black/40 p-3 text-sm text-slate-100 outline-none"
                placeholder="What changed in your perception of environment, permission, and risk?"
                value={checkpointText}
                onChange={(e) => setCheckpointText(e.target.value)}
              />
              <div className="mt-4 flex items-center justify-between gap-3">
                <button
                  className="rounded-xl border border-slate-800 bg-black/40 px-4 py-2 text-xs font-semibold text-slate-200 hover:bg-black/60"
                  onClick={() => {
                    setCheckpointOpen(false);
                    setCheckpointModule(null);
                    setCheckpointText('');
                  }}
                >
                  CANCEL
                </button>
                <button
                  className="rounded-xl border border-emerald-700 bg-emerald-950/40 px-4 py-2 text-xs font-semibold text-emerald-200 hover:bg-emerald-950/60"
                  onClick={() => {
                    submitTrainingCheckpoint({
                      operator_email: email,
                      pathway,
                      module_id: checkpointModule.id,
                      module_title: checkpointModule.title,
                      doc_id: checkpointModule.docId || null,
                      text: checkpointText || '',
                      uplink_key,
                    }).catch(() => {});
                    setCheckpointOpen(false);
                    setCheckpointModule(null);
                    setCheckpointText('');
                  }}
                >
                  SUBMIT
                </button>
              </div>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
