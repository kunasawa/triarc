import React from "react";

/**
 * CanonHeader — standard document header for TriArc publishing surfaces.
 *
 * Intentionally calm and strict; no marketing copy.
 */
export default function CanonHeader({
  name = "—",
  version = "—",
  status = "—",
  tier = "—",
  roleSurface = "—",
  lastUpdated = "—",
  changelog = "—",
  operatorImpact = "—",
  rolloutSurface = "—",
  rolloutStage = "—",
}) {
  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="text-xs tracking-widest text-slate-400">CANON HEADER</div>
          <div className="mt-2 text-lg font-semibold text-slate-100">{name}</div>
          <div className="mt-1 text-xs text-slate-400">{roleSurface}</div>
        </div>
        <div className="text-right">
          <div className="text-xs text-slate-400">Version</div>
          <div className="text-sm font-semibold text-slate-100">{version}</div>
          <div className="mt-2 text-xs text-slate-400">Status</div>
          <div className="text-sm font-semibold text-slate-100">{status}</div>
        </div>
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-4">
        <div className="rounded-xl border border-slate-800 bg-black/30 p-3">
          <div className="text-[10px] tracking-widest text-slate-500">TIER / ACCESS</div>
          <div className="mt-1 text-xs text-slate-200">{tier}</div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-black/30 p-3">
          <div className="text-[10px] tracking-widest text-slate-500">ROLLOUT</div>
          <div className="mt-1 text-xs text-slate-200">{rolloutSurface}</div>
          <div className="mt-1 text-[11px] text-slate-400">{rolloutStage}</div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-black/30 p-3">
          <div className="text-[10px] tracking-widest text-slate-500">LAST UPDATED</div>
          <div className="mt-1 text-xs text-slate-200">{lastUpdated}</div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-black/30 p-3">
          <div className="text-[10px] tracking-widest text-slate-500">OPERATOR IMPACT</div>
          <div className="mt-1 text-xs text-slate-200">{operatorImpact || "—"}</div>
        </div>
      </div>

      <div className="mt-3 rounded-xl border border-slate-800 bg-black/30 p-3">
        <div className="text-[10px] tracking-widest text-slate-500">CHANGELOG</div>
        <div className="mt-1 whitespace-pre-wrap text-xs text-slate-200">{changelog || "—"}</div>
      </div>
    </div>
  );
}
