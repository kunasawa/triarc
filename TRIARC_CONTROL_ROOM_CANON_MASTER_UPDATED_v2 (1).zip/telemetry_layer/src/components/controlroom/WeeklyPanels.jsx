import React from 'react';
import PanelCard from './PanelCard';
import KeyValueList from './KeyValueList';
import { useWeeklyArtifact } from '@/data/hooks';

function pick(artifact) {
  if (!artifact) return null;

  // Support both canonical and legacy field names.
  const instrument = artifact.instrument ?? artifact.symbol ?? artifact.market ?? '—';
  const weekType = artifact.week_type ?? artifact.wk_type ?? artifact.regime ?? artifact.prior_regime ?? '—';
  const respiration = artifact.respiration ?? artifact.weekly_respiration ?? '—';
  const clarity = artifact.clarity_score ?? artifact.clarity ?? artifact.wk_clarity ?? '—';
  const focus = artifact.focus ?? artifact.wk_focus ?? artifact.primary_focus ?? '—';
  const warning = artifact.warning ?? artifact.wk_warning ?? artifact.primary_warning ?? '—';

  return { instrument, weekType, respiration, clarity, focus, warning };
}

export default function WeeklyPanels({ instrument = 'ES' }) {
  const q = useWeeklyArtifact(instrument);
  const a = q.data;
  const view = pick(a);

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <PanelCard
        title="Environment"
        subtitle="Weekly artifact (read-only)"
        right={
          <div className="rounded-xl border border-slate-800 bg-black px-3 py-1 text-xs tracking-widest text-slate-200">
            {instrument}
          </div>
        }
      >
        {q.isLoading ? (
          <div className="text-sm text-slate-400">Loading…</div>
        ) : !a ? (
          <div className="text-sm text-slate-400">
            No weekly artifact published for this instrument yet.
          </div>
        ) : (
          <KeyValueList
            rows={[
              { k: 'instrument', v: view?.instrument },
              { k: 'week_type', v: view?.weekType },
              { k: 'respiration', v: view?.respiration },
              { k: 'clarity', v: view?.clarity },
              { k: 'focus', v: view?.focus },
              { k: 'warning', v: view?.warning }
            ]}
          />
        )}

        {a ? (
          <div className="mt-4 border-t border-slate-800 pt-4">
            <div className="text-xs uppercase tracking-widest text-slate-500">Canon Header</div>
            <div className="mt-2 grid gap-2 text-sm text-slate-300">
              <div>
                <span className="text-slate-500">Name:</span> {a.canon_name ?? 'Weekly Artifact'}
              </div>
              <div>
                <span className="text-slate-500">Version:</span> {a.canon_version ?? (a.version_num ? `v${a.version_num}` : '—')} •
                <span className="text-slate-500"> Status:</span> {a.status ?? a.canon_status ?? '—'}
              </div>
              <div>
                <span className="text-slate-500">Last Updated:</span> {a.canon_last_updated ?? a.updated_at ?? a.published_at ?? '—'}
              </div>
            </div>

            {(a.operator_impact || a.changelog || a.notes) ? (
              <div className="mt-4 grid gap-3 md:grid-cols-3">
                <div className="rounded-2xl border border-slate-800 bg-black p-4">
                  <div className="text-xs uppercase tracking-widest text-slate-500">Operator Impact</div>
                  <div className="mt-2 whitespace-pre-wrap text-sm text-slate-200">{a.operator_impact || '—'}</div>
                </div>
                <div className="rounded-2xl border border-slate-800 bg-black p-4">
                  <div className="text-xs uppercase tracking-widest text-slate-500">Changelog</div>
                  <div className="mt-2 whitespace-pre-wrap text-sm text-slate-200">{a.changelog || '—'}</div>
                </div>
                <div className="rounded-2xl border border-slate-800 bg-black p-4">
                  <div className="text-xs uppercase tracking-widest text-slate-500">Governance Notes</div>
                  <div className="mt-2 whitespace-pre-wrap text-sm text-slate-200">{a.notes || '—'}</div>
                </div>
              </div>
            ) : null}
          </div>
        ) : null}
      </PanelCard>

      <PanelCard
        title="Desk Briefings"
        subtitle="Instrument playbook attachments + archive"
      >
        <div className="text-sm text-slate-300">
          This surface will attach the published weekly briefs (ES / NQ / GC / CL) and map them to the artifact.
        </div>
        <div className="mt-2 text-xs text-slate-500">
          Canon rule: briefs are environment guidance — never advice.
        </div>
      </PanelCard>
    </div>
  );
}
