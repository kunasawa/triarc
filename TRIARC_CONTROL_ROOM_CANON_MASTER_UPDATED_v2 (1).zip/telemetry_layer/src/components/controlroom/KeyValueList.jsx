import React from 'react';

export default function KeyValueList({ rows = [] }) {
  return (
    <div className="space-y-1 text-sm">
      {rows.map((r, idx) => (
        <div key={idx} className="flex items-baseline justify-between gap-4">
          <div className="text-slate-500">{r.k}</div>
          <div className="text-right text-slate-200 break-all">{r.v ?? '—'}</div>
        </div>
      ))}
    </div>
  );
}
