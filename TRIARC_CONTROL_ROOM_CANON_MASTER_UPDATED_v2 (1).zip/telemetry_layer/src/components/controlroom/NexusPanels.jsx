import React from 'react';
import PanelCard from './PanelCard';
import KeyValueList from './KeyValueList';
import { useNexusLive, useOpportunityLedger } from '@/data/hooks';

function Badge({ text, tone = 'neutral' }) {
  const cls =
    tone === 'good'
      ? 'bg-green-600/20 border-green-700 text-green-200'
      : tone === 'warn'
        ? 'bg-orange-600/20 border-orange-700 text-orange-200'
        : tone === 'bad'
          ? 'bg-red-600/20 border-red-700 text-red-200'
          : 'bg-slate-700/20 border-slate-700 text-slate-200';
  return (
    <div className={`rounded-xl border px-3 py-1 text-xs tracking-widest ${cls}`}>
      {text}
    </div>
  );
}

export default function NexusPanels({ uplink_key }) {
  const liveQ = useNexusLive(uplink_key);
  const ledQ = useOpportunityLedger(uplink_key, 10);

  const payload = liveQ.data?.payload ?? liveQ.data?.raw?.payload ?? null;
  const gov = payload?.governance ?? null;
  const servo = payload?.servo ?? null;
  const opp = payload?.opportunity ?? null;

  const govTone = gov?.global_void
    ? 'bad'
    : gov?.probe_only
      ? 'warn'
      : gov?.is_permitted
        ? 'good'
        : 'bad';

  return (
    <div className="grid gap-4 md:grid-cols-3">
      <PanelCard
        title="Governance"
        subtitle="Permission envelope (live)"
        right={<Badge text={gov?.gov_state ?? 'NO FEED'} tone={govTone} />}
      >
        {liveQ.isLoading ? (
          <div className="text-sm text-slate-400">Loading…</div>
        ) : !payload ? (
          <div className="text-sm text-slate-400">
            No telemetry found for this uplink. (Waiting for STATE_SNAPSHOT.)
          </div>
        ) : (
          <KeyValueList
            rows={[
              { k: 'is_permitted', v: String(gov?.is_permitted ?? false) },
              { k: 'denial_reason', v: gov?.denial_reason ?? '—' },
              { k: 'sentinel_state', v: String(gov?.sentinel_state ?? 0) },
              { k: 'wk_type', v: gov?.wk_type ?? '—' },
              { k: 'wk_confidence', v: gov?.wk_confidence != null ? `${gov.wk_confidence}%` : '—' },
              { k: 'matrix_healthy', v: String(gov?.matrix_healthy ?? false) }
            ]}
          />
        )}
      </PanelCard>

      <PanelCard
        title="Load"
        subtitle="Servo decision + caps"
        right={<Badge text={servo?.servo_decision ?? '—'} tone={servo?.servo_decision === 'PASS' ? 'good' : servo?.servo_decision === 'WARN' ? 'warn' : 'bad'} />}
      >
        {!payload ? (
          <div className="text-sm text-slate-400">Awaiting feed.</div>
        ) : (
          <KeyValueList
            rows={[
              { k: 'servo_reason', v: servo?.servo_reason ?? '—' },
              { k: 'risk_multiplier', v: servo?.risk_multiplier != null ? `${servo.risk_multiplier}x` : '—' },
              { k: 'env_cap', v: servo?.env_cap != null ? `${servo.env_cap}x` : '—' }
            ]}
          />
        )}
      </PanelCard>

      <PanelCard
        title="Opportunity"
        subtitle="Active opportunity (redacted mechanics)"
        right={<Badge text={opp?.active ? 'ACTIVE' : 'IDLE'} tone={opp?.active ? 'good' : 'neutral'} />}
      >
        {!payload ? (
          <div className="text-sm text-slate-400">Awaiting feed.</div>
        ) : (
          <KeyValueList
            rows={[
              { k: 'name', v: opp?.name ?? '—' },
              { k: 'side', v: opp?.side ?? '—' },
              { k: 'score', v: opp?.score != null ? `${opp.score}%` : '—' },
              { k: 'rotation_mode', v: String(opp?.rotation_mode ?? false) },
              { k: 'hammer', v: String(opp?.hammer ?? false) },
              { k: 'matrix_ok', v: String(opp?.matrix_ok ?? false) }
            ]}
          />
        )}

        <div className="mt-4 border-t border-slate-800 pt-4">
          <div className="text-xs uppercase tracking-widest text-slate-500">Recent ledger</div>
          {ledQ.isLoading ? (
            <div className="mt-2 text-sm text-slate-400">Loading…</div>
          ) : (ledQ.data?.length ?? 0) === 0 ? (
            <div className="mt-2 text-sm text-slate-400">No ledger entries.</div>
          ) : (
            <div className="mt-2 space-y-2 text-sm">
              {ledQ.data.slice(0, 5).map((row) => (
                <div key={row.id} className="rounded-xl border border-slate-800 bg-black px-3 py-2">
                  <div className="flex items-baseline justify-between gap-3">
                    <div className="text-slate-200">{row.name ?? row.opportunity_name ?? 'OPPORTUNITY'}</div>
                    <div className="text-xs text-slate-500">{row.last_seen_timestamp_ms ?? row.created_date ?? '—'}</div>
                  </div>
                  <div className="mt-1 text-xs text-slate-500">
                    score: {row.score ?? '—'} • side: {row.side ?? '—'}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </PanelCard>
    </div>
  );
}
