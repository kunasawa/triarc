import { base44 } from '@/api/base44Client';

/**
 * Control Room Data Layer (v1)
 *
 * Notes:
 * - Base44 entities can differ between environments (legacy vs canonical).
 * - These helpers attempt canonical entities first, then fall back.
 */

const tryEntity = (name) => {
  try {
    return base44.entities?.[name];
  } catch {
    return null;
  }
};

const safeList = async (entity, sort, limit) => {
  if (!entity?.list) return [];
  return await entity.list(sort, limit);
};

const safeFilter = async (entity, query, sort, limit) => {
  if (!entity?.filter) return [];
  // base44 SDK signatures vary: filter(query, sort, limit) or filter(query, sort)
  try {
    return await entity.filter(query, sort, limit);
  } catch {
    try {
      return await entity.filter(query, sort);
    } catch {
      return [];
    }
  }
};

// ------------------------------------------------------------
// Identity
// ------------------------------------------------------------


export async function getIdentity() {
  // NOTE: Legacy alias. Prefer useMemberRecord() which calls getMemberRecord().
  return await getMemberRecord();
}

// ------------------------------------------------------------
// Canonical Member Record (Identity Authority Layer)
// ------------------------------------------------------------

export async function getMemberRecord() {
  const me = await base44.auth.me().catch(() => null);
  const email = me?.email ?? null;

  // Billing → Profile Synchronization (best-effort)
  // Canon: identity entitlements must be derived from Stripe, not UI state.
  if (email && base44?.functions?.invoke) {
    try {
      await base44.functions.invoke('syncStripeProfile', {});
    } catch {
      // Non-blocking: local identity retrieval must still succeed even if billing sync is unavailable.
    }
  }

  const MemberRecord = tryEntity('MemberRecord');
  const MemberIdentity = tryEntity('MemberIdentity');
  const Profile = tryEntity('Profile');
  const MemberProfile = tryEntity('MemberProfile');

  let rec = null;

  // Canonical-first
  if (MemberRecord && email) {
    const rows = await safeFilter(MemberRecord, { email }, '-created_date', 1);
    rec = rows?.[0] ?? null;
  }

  // Legacy fallback
  if (!rec && MemberIdentity && email) {
    const rows = await safeFilter(MemberIdentity, { email }, '-created_date', 1);
    rec = rows?.[0] ?? null;
  }
  if (!rec && (Profile || MemberProfile) && email) {
    const Ent = Profile || MemberProfile;
    const rows = await safeFilter(Ent, { email }, '-created_date', 1);
    rec = rows?.[0] ?? null;
  }

  // Normalize uplink keys (string or list)
  const uplink_keys =
    Array.isArray(rec?.uplink_keys) ? rec.uplink_keys :
    Array.isArray(rec?.uplinkKeys) ? rec.uplinkKeys :
    (rec?.uplink_key || rec?.uplinkKey) ? [rec.uplink_key || rec.uplinkKey] : [];

  const role = (rec?.role ?? me?.role ?? '').toString() || null;
  const tier = (rec?.tier ?? me?.tier ?? '').toString() || null;
  const pathway = (rec?.pathway ?? rec?.assigned_path ?? me?.pathway ?? '').toString() || null;

  const allowed_symbols =
    Array.isArray(rec?.allowed_symbols) ? rec.allowed_symbols :
    Array.isArray(rec?.allowedSymbols) ? rec.allowedSymbols : [];

  const allowed_modes =
    Array.isArray(rec?.allowed_modes) ? rec.allowed_modes :
    Array.isArray(rec?.allowedModes) ? rec.allowedModes : [];

  const status = (rec?.status ?? 'ACTIVE').toString();

  return {
    member_id: rec?.id ?? me?.id ?? null,
    email,
    name: rec?.name ?? me?.name ?? null,
    role: role ? role.toLowerCase() : null,
    tier,
    pathway,
    status,
    uplink_keys,
    allowed_symbols,
    allowed_modes,
    raw: { me, record: rec }
  };
}

// Fleet listing (Controller/Warden/Architect only)
export async function listMemberRecords({ q = '', limit = 50 } = {}) {
  const MemberRecord = tryEntity('MemberRecord');
  const Fallback = tryEntity('Profile') || tryEntity('MemberIdentity') || tryEntity('MemberProfile');

  const Ent = MemberRecord || Fallback;
  if (!Ent) return [];

  if (q && Ent?.filter) {
    const candidates = [{ email: q }, { name: q }, { created_by: q }, { operator_email: q }, { operator_id: q }];
    for (const c of candidates) {
      const rows = await safeFilter(Ent, c, '-created_date', limit);
      if (Array.isArray(rows) && rows.length) return rows;
    }
  }

  return await safeList(Ent, '-created_date', limit);
}

export async function updateMemberRecord(memberId, patch) {
  const MemberRecord = tryEntity('MemberRecord');
  const Fallback = tryEntity('Profile') || tryEntity('MemberIdentity') || tryEntity('MemberProfile');
  const Ent = MemberRecord || Fallback;
  if (!Ent?.update) throw new Error('No updatable identity entity available in this environment.');
  return await Ent.update(memberId, patch);
}


// ------------------------------------------------------------
// Weekly Artifact
// ------------------------------------------------------------

export async function getLatestWeeklyArtifact({ instrument } = {}) {
  // Canonical entity (preferred)
  const WeeklyArtifact = tryEntity('WeeklyArtifact');
  // Legacy fallback
  const WeeklyBrief = tryEntity('WeeklyBrief');

  // Canon rule: Operators consume the published environment contract.
  // Drafts are governance-internal and must never be treated as the active artifact.
  const q = instrument ? { instrument } : {};
  const qPublished = { ...q, status: 'PUBLISHED' };
  const qLocked = { ...q, status: 'LOCKED' };

  if (WeeklyArtifact) {
    // Prefer LOCKED (end-state) over PUBLISHED (active) over any other state.
    let rows = await safeFilter(WeeklyArtifact, qLocked, '-published_at', 1);
    if (!rows?.length) rows = await safeFilter(WeeklyArtifact, qPublished, '-published_at', 1);
    if (!rows?.length) rows = await safeFilter(WeeklyArtifact, q, '-created_date', 1);
    return rows?.[0] ?? null;
  }
  if (WeeklyBrief) {
    const rows = await safeFilter(WeeklyBrief, q, '-created_date', 1);
    return rows?.[0] ?? null;
  }
  return null;
}

export async function getWeeklyArtifactsArchive({ instrument, limit = 50 } = {}) {
  const WeeklyArtifact = tryEntity('WeeklyArtifact');
  const WeeklyBrief = tryEntity('WeeklyBrief');
  const q = instrument ? { instrument } : {};

  if (WeeklyArtifact) {
    // Archive should exclude drafts by default.
    const rows = await safeFilter(WeeklyArtifact, q, '-week_of', limit);
    return (rows ?? []).filter((r) => r?.status !== 'DRAFT');
  }
  if (WeeklyBrief) {
    return await safeFilter(WeeklyBrief, q, '-created_date', limit);
  }
  return [];
}

export async function getWeeklyArtifactByWeek({ instrument, week_of } = {}) {
  const WeeklyArtifact = tryEntity('WeeklyArtifact');
  if (!WeeklyArtifact || !instrument || !week_of) return null;
  const rows = await safeFilter(WeeklyArtifact, { instrument, week_of }, '-version_num', 1);
  return rows?.[0] ?? null;
}

// ------------------------------------------------------------
// Nexus Live State (latest snapshot per uplink)
// ------------------------------------------------------------

export async function getNexusLive({ uplink_key } = {}) {
  const NexusStateLive = tryEntity('NexusStateLive');
  const NexusEvent = tryEntity('NexusEvent'); // legacy

  if (NexusStateLive && uplink_key) {
    const rows = await safeFilter(NexusStateLive, { uplink_key }, '-last_seen_timestamp_ms', 1);
    return rows?.[0] ?? null;
  }

  // Fallback: compute from latest STATE_SNAPSHOT in NexusEvent
  if (NexusEvent && uplink_key) {
    const rows = await safeFilter(
      NexusEvent,
      { uplink_key, event_type: 'STATE_SNAPSHOT' },
      '-timestamp_ms',
      1
    );
    const ev = rows?.[0] ?? null;
    return ev ? { uplink_key, payload: ev.payload, last_seen_timestamp_ms: ev.timestamp_ms, raw: ev } : null;
  }

  return null;
}

// ------------------------------------------------------------
// Opportunity Ledger
// ------------------------------------------------------------

export async function getOpportunityLedger({ uplink_key, limit = 25 } = {}) {
  const OpportunityLedger = tryEntity('OpportunityLedger');
  if (!OpportunityLedger) return [];

  if (uplink_key) {
    return await safeFilter(OpportunityLedger, { uplink_key }, '-last_seen_timestamp_ms', limit);
  }
  return await safeList(OpportunityLedger, '-last_seen_timestamp_ms', limit);
}

// ------------------------------------------------------------
// Nexus Telemetry Stream (raw events)
// ------------------------------------------------------------

export async function getNexusEvents({ uplink_key, event_type, limit = 50 } = {}) {
  const NexusRawEvent = tryEntity('NexusRawEvent');
  const NexusTelemetryEvent = tryEntity('NexusTelemetryEvent');
  const NexusEvent = tryEntity('NexusEvent');

  const Ent = NexusRawEvent || NexusTelemetryEvent || NexusEvent;
  if (!Ent) return [];

  const q = {};
  if (uplink_key) q.uplink_key = uplink_key;
  if (event_type) q.event_type = event_type;

  // Sorting fields vary across environments.
  const sortCandidates = ['-event_time_ms', '-timestamp_ms', '-created_date'];
  for (const sort of sortCandidates) {
    const rows = await safeFilter(Ent, q, sort, limit);
    if (Array.isArray(rows) && rows.length) return rows;
  }
  return await safeFilter(Ent, q, '-created_date', limit);
}

export async function getNexusLiveFleet({ limit = 200 } = {}) {
  // For Warden/Controller/Architect views.
  const NexusStateLive = tryEntity('NexusStateLive');
  if (!NexusStateLive) return [];

  // Sorting fields vary.
  const sortCandidates = ['-last_seen_timestamp_ms', '-event_time_ms', '-created_date'];
  for (const sort of sortCandidates) {
    const rows = await safeList(NexusStateLive, sort, limit);
    if (Array.isArray(rows) && rows.length) return rows;
  }
  return await safeList(NexusStateLive, '-created_date', limit);
}

// ------------------------------------------------------------
// Compliance & Remediation
// ------------------------------------------------------------

const ComplianceEventEntNames = ['ComplianceEvent', 'NexusComplianceEvent'];
const RemediationCaseEntNames = ['RemediationCase', 'NexusRemediationCase'];
const ComplianceProfileEntNames = ['ComplianceProfile', 'OperatorComplianceProfile'];
const IncidentEntNames = ['GovernanceIncident', 'Incident', 'IncidentLog'];
const EnforcementEntNames = ['EnforcementAction', 'GovernanceAction', 'PermissionAction'];

const pickAny = (names) => {
  for (const n of names) {
    const ent = tryEntity(n);
    if (ent) return ent;
  }
  return null;
};

const safeCreate = async (entity, payload) => {
  if (!entity?.create) return null;
  try {
    return await entity.create(payload);
  } catch {
    return null;
  }
};

const safeUpdate = async (entity, id, patch) => {
  if (!entity?.update) return null;
  try {
    return await entity.update(id, patch);
  } catch {
    return null;
  }
};

export async function getComplianceSummary({ member_id, uplink_key } = {}) {
  const Profile = pickAny(ComplianceProfileEntNames);
  if (!Profile) {
    // Graceful fallback: compute a shallow summary from recent events.
    const events = await listComplianceEvents({ uplink_key, limit: 200 });
    const score = events.reduce((acc, e) => {
      const sev = (e?.severity || '').toString().toUpperCase();
      if (sev === 'CRITICAL') return acc - 50;
      if (sev === 'MAJOR') return acc - 20;
      if (sev === 'MINOR') return acc - 5;
      return acc;
    }, 100);
    const open = await listRemediationCases({ member_id, uplink_key, status: 'OPEN', limit: 100 });
    return {
      score: Math.max(0, Math.min(100, score)),
      open_cases: open?.length ?? 0,
      last_violation_type: events?.[0]?.violation_type ?? '—',
      source: 'computed'
    };
  }

  const q = {};
  if (member_id) q.member_id = member_id;
  if (uplink_key) q.uplink_key = uplink_key;

  const rows = await safeFilter(Profile, q, '-updated_at', 1);
  return rows?.[0] ?? null;
}

export async function listComplianceEvents({ member_id, uplink_key, limit = 200 } = {}) {
  const Ent = pickAny(ComplianceEventEntNames);
  if (!Ent) return [];
  const q = {};
  if (member_id) q.member_id = member_id;
  if (uplink_key) q.uplink_key = uplink_key;

  const sortCandidates = ['-timestamp_ms', '-event_time_ms', '-created_date'];
  for (const sort of sortCandidates) {
    const rows = await safeFilter(Ent, q, sort, limit);
    if (Array.isArray(rows) && rows.length) return rows;
  }
  return await safeFilter(Ent, q, '-created_date', limit);
}

export async function listRemediationCases({ member_id, uplink_key, status, limit = 200 } = {}) {
  const Ent = pickAny(RemediationCaseEntNames);
  if (!Ent) return [];
  const q = {};
  if (member_id) q.member_id = member_id;
  if (uplink_key) q.uplink_key = uplink_key;
  if (status) q.status = status;

  const sortCandidates = ['-created_date', '-deadline', '-updated_at'];
  for (const sort of sortCandidates) {
    const rows = await safeFilter(Ent, q, sort, limit);
    if (Array.isArray(rows) && rows.length) return rows;
  }
  return await safeFilter(Ent, q, '-created_date', limit);
}

// ------------------------------------------------------------
// Incidents & Enforcement (Governance)
// ------------------------------------------------------------

export async function listIncidents({ uplink_key, status, limit = 200 } = {}) {
  const Ent = pickAny(IncidentEntNames);
  if (!Ent) return [];
  const q = {};
  if (uplink_key) q.uplink_key = uplink_key;
  if (status) q.status = status;

  const sortCandidates = ['-created_date', '-timestamp_ms', '-updated_at'];
  for (const sort of sortCandidates) {
    const rows = await safeFilter(Ent, q, sort, limit);
    if (Array.isArray(rows) && rows.length) return rows;
  }
  return await safeFilter(Ent, q, '-created_date', limit);
}

export async function listEnforcementActions({ uplink_key, limit = 200 } = {}) {
  const Ent = pickAny(EnforcementEntNames);
  if (!Ent) return [];
  const q = {};
  if (uplink_key) q.uplink_key = uplink_key;
  const sortCandidates = ['-created_date', '-timestamp_ms'];
  for (const sort of sortCandidates) {
    const rows = await safeFilter(Ent, q, sort, limit);
    if (Array.isArray(rows) && rows.length) return rows;
  }
  return await safeFilter(Ent, q, '-created_date', limit);
}

export async function createIncident(payload) {
  const Ent = pickAny(IncidentEntNames);
  if (!Ent) throw new Error('No incident entity available in this environment.');
  const row = await safeCreate(Ent, payload);
  if (!row) throw new Error('Failed to create incident record.');
  return row;
}

export async function createEnforcementAction(payload) {
  const Ent = pickAny(EnforcementEntNames);
  if (!Ent) throw new Error('No enforcement entity available in this environment.');
  const row = await safeCreate(Ent, payload);
  if (!row) throw new Error('Failed to create enforcement action.');
  return row;
}

// Upsert execution hold flags on ComplianceProfile.
export async function setExecutionHold({ uplink_key, hold, reason, until_iso, actor_role } = {}) {
  if (!uplink_key) throw new Error('uplink_key required');
  const Profile = pickAny(ComplianceProfileEntNames);
  if (!Profile) throw new Error('No compliance profile entity available in this environment.');

  const rows = await safeFilter(Profile, { uplink_key }, '-updated_at', 1);
  const existing = rows?.[0] ?? null;

  const patch = {
    uplink_key,
    execution_hold: !!hold,
    hold_reason: reason || (hold ? 'GOVERNANCE HOLD' : 'RELEASED'),
    hold_until: until_iso || null,
    stability_status: hold ? 'RESTRICTED' : 'ACTIVE',
    last_action_by_role: actor_role || null,
    updated_at: new Date().toISOString()
  };

  // Prefer update; otherwise create.
  if (existing?.id) {
    const out = await safeUpdate(Profile, existing.id, patch);
    if (out) return out;
  }
  const created = await safeCreate(Profile, patch);
  if (!created) throw new Error('Failed to set execution hold.');
  return created;
}

