import { useQuery } from '@tanstack/react-query';
import {
  getIdentity,
  getMemberRecord,
  getLatestWeeklyArtifact,
  getWeeklyArtifactsArchive,
  getWeeklyArtifactByWeek,
  getNexusLive,
  getOpportunityLedger,
  getNexusEvents,
  getNexusLiveFleet,
  getComplianceSummary,
  listComplianceEvents,
  listRemediationCases,
  listIncidents,
  listEnforcementActions
} from './api';
import { MODEL_KEYS } from './contracts';

const isFleetRole = (role) => ['warden','controller','architect','admin'].includes((role||'').toLowerCase());

export function useMemberRecord() {
  return useQuery({
    queryKey: [MODEL_KEYS.MEMBER_RECORD],
    queryFn: () => getMemberRecord(),
    staleTime: 60 * 1000
  });
}

export function useIdentity() {
  return useQuery({
    queryKey: [MODEL_KEYS.IDENTITY],
    queryFn: () => getIdentity(),
    staleTime: 60 * 1000
  });
}

// Preferred identity hook (canonical)
export function useWeeklyArtifact(instrument) {
  return useQuery({
    queryKey: [MODEL_KEYS.WEEKLY_ARTIFACT, instrument ?? 'ALL'],
    queryFn: () => getLatestWeeklyArtifact({ instrument }),
    staleTime: 60 * 1000
  });
}

export function useWeeklyArchive(instrument, limit = 50) {
  return useQuery({
    queryKey: [MODEL_KEYS.WEEKLY_ARCHIVE, instrument ?? 'ALL', limit],
    queryFn: () => getWeeklyArtifactsArchive({ instrument, limit }),
    staleTime: 60 * 1000
  });
}

export function useWeeklyByWeek(instrument, week_of) {
  return useQuery({
    queryKey: [MODEL_KEYS.WEEKLY_BY_WEEK, instrument ?? 'ALL', week_of ?? 'NONE'],
    queryFn: () => getWeeklyArtifactByWeek({ instrument, week_of }),
    enabled: !!instrument && !!week_of,
    staleTime: 60 * 1000
  });
}

export function useNexusLive(uplink_key) {
  return useQuery({
    queryKey: [MODEL_KEYS.NEXUS_LIVE, uplink_key ?? 'NONE'],
    queryFn: () => getNexusLive({ uplink_key }),
    enabled: !!uplink_key,
    refetchInterval: 10 * 1000,
    staleTime: 5 * 1000
  });
}

export function useOpportunityLedger(uplink_key, limit = 25) {
  return useQuery({
    queryKey: [MODEL_KEYS.OPPORTUNITY_LEDGER, uplink_key ?? 'NONE', limit],
    queryFn: () => getOpportunityLedger({ uplink_key, limit }),
    enabled: !!uplink_key,
    refetchInterval: 15 * 1000,
    staleTime: 10 * 1000
  });
}

export function useNexusEvents({ uplink_key, event_type, limit = 50 } = {}) {
  return useQuery({
    queryKey: [MODEL_KEYS.NEXUS_EVENTS, uplink_key ?? 'ALL', event_type ?? 'ANY', limit],
    queryFn: () => getNexusEvents({ uplink_key, event_type, limit }),
    enabled: !!uplink_key || uplink_key === null,
    refetchInterval: 10 * 1000,
    staleTime: 5 * 1000
  });
}

export function useNexusLiveFleet(limit = 200) {
  return useQuery({
    queryKey: [MODEL_KEYS.NEXUS_FLEET, limit],
    queryFn: async () => {
      const id = await getMemberRecord();
      if (!isFleetRole(id?.role)) throw new Error('RBAC: fleet telemetry requires Warden/Controller/Architect.');
      return await getNexusLiveFleet({ limit });
    },
    staleTime: 10 * 1000,
    refetchInterval: 15 * 1000
  });
}

// ------------------------------------------------------------
// Compliance & Remediation (Governance Layer)
// ------------------------------------------------------------

export function useComplianceSummary({ member_id, uplink_key } = {}) {
  return useQuery({
    queryKey: [MODEL_KEYS.COMPLIANCE_SUMMARY, member_id ?? 'NONE', uplink_key ?? 'NONE'],
    queryFn: async () => {
      const id = await getMemberRecord();
      if (!isFleetRole(id?.role)) throw new Error('RBAC: compliance summary requires Warden/Controller/Architect/Admin.');
      return await getComplianceSummary({ member_id, uplink_key });
    },
    staleTime: 30 * 1000,
    refetchInterval: 30 * 1000
  });
}

export function useComplianceEvents({ member_id, uplink_key, limit = 200 } = {}) {
  return useQuery({
    queryKey: [MODEL_KEYS.COMPLIANCE_EVENTS, member_id ?? 'NONE', uplink_key ?? 'NONE', limit],
    queryFn: async () => {
      const id = await getMemberRecord();
      if (!isFleetRole(id?.role)) throw new Error('RBAC: compliance events require Warden/Controller/Architect/Admin.');
      return await listComplianceEvents({ member_id, uplink_key, limit });
    },
    staleTime: 15 * 1000,
    refetchInterval: 20 * 1000
  });
}

export function useRemediationCases({ member_id, uplink_key, status = 'OPEN', limit = 200 } = {}) {
  return useQuery({
    queryKey: [MODEL_KEYS.REMEDIATION_CASES, member_id ?? 'NONE', uplink_key ?? 'NONE', status ?? 'ANY', limit],
    queryFn: async () => {
      const id = await getMemberRecord();
      if (!isFleetRole(id?.role)) throw new Error('RBAC: remediation cases require Warden/Controller/Architect/Admin.');
      return await listRemediationCases({ member_id, uplink_key, status, limit });
    },
    staleTime: 30 * 1000,
    refetchInterval: 30 * 1000
  });
}

// ------------------------------------------------------------
// Incidents & Enforcement (Governance Layer)
// ------------------------------------------------------------

export function useIncidents({ uplink_key, status, limit = 200 } = {}) {
  return useQuery({
    queryKey: [MODEL_KEYS.INCIDENTS, uplink_key ?? 'ALL', status ?? 'ANY', limit],
    queryFn: async () => {
      const id = await getMemberRecord();
      if (!isFleetRole(id?.role)) throw new Error('RBAC: incidents require Warden/Controller/Architect/Admin.');
      return await listIncidents({ uplink_key, status, limit });
    },
    staleTime: 15 * 1000,
    refetchInterval: 20 * 1000
  });
}

export function useEnforcementActions({ uplink_key, limit = 200 } = {}) {
  return useQuery({
    queryKey: [MODEL_KEYS.ENFORCEMENT_ACTIONS, uplink_key ?? 'ALL', limit],
    queryFn: async () => {
      const id = await getMemberRecord();
      if (!isFleetRole(id?.role)) throw new Error('RBAC: enforcement requires Warden/Controller/Architect/Admin.');
      return await listEnforcementActions({ uplink_key, limit });
    },
    staleTime: 30 * 1000,
    refetchInterval: 30 * 1000
  });
}
