/**
 * doctrineGuard.js — Outbound Publishing Control (Doctrine Guardrail)
 *
 * Goal: prevent retail language drift and execution framing from entering
 * public corridor artifacts.
 *
 * This module is intentionally conservative. It is not meant to be perfect NLP.
 * It is meant to be a hard stop on obvious violations.
 */

export const DOCTRINE_VALIDATION = Object.freeze({
  PASS: "PASS",
  FAIL: "FAIL",
});

// -----------------------------------------------------------------------------
// Guardrail vocabulary (extend as needed)
// -----------------------------------------------------------------------------

// Words/phrases strongly correlated with retail signal services.
export const PROHIBITED_TERMS = [
  "signal",
  "signals",
  "win rate",
  "winrate",
  "profitable",
  "profits",
  "profit",
  "guarantee",
  "guaranteed",
  "alpha",
  "edge",
  "entries",
  "entry",
  "exits",
  "exit",
  "buy",
  "sell",
  "long",
  "short",
  "target",
  "targets",
  "take profit",
  "stop loss",
  "stop",
  "setup",
  "setups",
  "trade idea",
  "call",
  "calls",
  "alert",
  "alerts",
  "copy trade",
  "copytrade",
];

// Pattern-based phrasing that implies instruction/advice.
export const PROHIBITED_PATTERNS = [
  /\b(you should|you\s+must|we\s+recommend|i\s+recommend)\b/gi,
  /\b(look\s+to\s+buy|look\s+to\s+sell)\b/gi,
  /\b(this\s+week\s+we\s+are\s+targeting|targeting\s+this\s+week)\b/gi,
  /\b(high\s+probability\s+trade|high\s+probability\s+setup)\b/gi,
  /\b(don'?t\s+miss|can'?t\s+miss)\b/gi,
  /\b(returns?|%\s*return|roi|pnl|p\s*\/\s*l)\b/gi,
  /\b(\d+(?:\.\d+)?\s*(?:r|rr|r-multiple|r\s*multiple))\b/gi,
];

// Required boundary phrases for any public-facing artifact.
export const REQUIRED_BOUNDARY_PHRASES = [
  "TriArc is not a signal service",
  "Permission precedes participation",
];

// Required metadata fields on a canon document record.
export const REQUIRED_CANON_FIELDS = [
  "canon_id",
  "canon_name",
  "canon_version",
  "canon_status",
  "canon_tier",
  "canon_role_surface",
  "canon_last_updated",
  "operator_impact",
  "changelog",
];

const normalize = (v) => (v ?? "").toString();

export function buildOutboundBody({ title, summary } = {}) {
  const t = normalize(title).trim();
  const s = normalize(summary).trim();

  return [
    "# " + (t || "CANON OUTREACH ARTIFACT"),
    "",
    "## Boundary",
    "TriArc is not a signal service.",
    "Permission precedes participation.",
    "",
    "## Summary",
    s || "—",
    "",
    "## Notes",
    "This document is doctrine distribution only. It does not grant execution permission.",
    "",
  ].join("\n");
}

/**
 * validateDoctrine(doc)
 */
export function validateDoctrine(doc = {}) {
  const title = normalize(doc.title || doc.canon_name);
  const summary = normalize(doc.summary);
  const body = normalize(doc.body);
  const operatorImpact = normalize(doc.operator_impact);
  const changelog = normalize(doc.changelog);

  const combined = [title, summary, body, operatorImpact, changelog].filter(Boolean).join("\n\n");
  const lc = combined.toLowerCase();

  const prohibited_terms = [];
  for (const t of PROHIBITED_TERMS) {
    const needle = t.toLowerCase();
    const hit = needle.includes(" ")
      ? lc.includes(needle)
      : new RegExp(`\\b${needle.replace(/[.*+?^${}()|[\\]\\]/g, "\\$&")}\\b`, "i").test(combined);
    if (hit) prohibited_terms.push(t);
  }

  const prohibited_patterns = [];
  for (const rx of PROHIBITED_PATTERNS) {
    const m = combined.match(rx);
    if (m?.length) prohibited_patterns.push(String(rx));
  }

  const missing_boundary = [];
  for (const phrase of REQUIRED_BOUNDARY_PHRASES) {
    if (!lc.includes(phrase.toLowerCase())) missing_boundary.push(phrase);
  }

  const missing_fields = [];
  for (const f of REQUIRED_CANON_FIELDS) {
    const v = doc?.[f];
    if (v === undefined || v === null || String(v).trim() === "") missing_fields.push(f);
  }

  const fail =
    prohibited_terms.length || prohibited_patterns.length || missing_boundary.length || missing_fields.length;

  return {
    status: fail ? DOCTRINE_VALIDATION.FAIL : DOCTRINE_VALIDATION.PASS,
    violations: {
      prohibited_terms,
      prohibited_patterns,
      missing_boundary,
      missing_fields,
    },
    inspected_text_preview: combined.slice(0, 400),
  };
}
