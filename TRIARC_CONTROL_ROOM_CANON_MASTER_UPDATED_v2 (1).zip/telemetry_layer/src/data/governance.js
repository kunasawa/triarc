import { base44 } from '@/api/base44Client';

// ------------------------------------------------------------
// Governance Layer (v1)
// ------------------------------------------------------------
// Purpose:
// - Provide mutation helpers for Controller / Governance / Architect consoles.
// - Keep entity naming flexible (canonical-first, legacy-fallback).
//
// NOTE:
// UI gating (RoleGate) prevents accidental exposure.
// Server-side role permissions remain the source of truth.

const getEntity = (names = []) => {
  for (const name of names) {
    const ent = base44.entities?.[name];
    if (ent) return ent;
  }
  return null;
};

const nowIso = () => new Date().toISOString();

// -------------------------
// Intake: Access Requests
// -------------------------

const ACCESS_REQUEST_ENTS = ['AccessRequest', 'PermissionRequest', 'IntakeRequest'];

export async function listAccessRequests({ status = 'PENDING', limit = 100 } = {}) {
  const AccessRequest = getEntity(ACCESS_REQUEST_ENTS);
  if (!AccessRequest?.list && !AccessRequest?.filter) return [];

  // Prefer filter when available
  if (status && AccessRequest?.filter) {
    try {
      const rows = await AccessRequest.filter({ status }, '-created_date', limit);
      if (Array.isArray(rows)) return rows;
    } catch {
      // ignore
    }
  }

  // Fallback list
  try {
    return await AccessRequest.list('-created_date', limit);
  } catch {
    try {
      return await AccessRequest.list();
    } catch {
      return [];
    }
  }
}

export async function updateAccessRequest(requestId, patch) {
  const AccessRequest = getEntity(ACCESS_REQUEST_ENTS);
  if (!AccessRequest?.update) throw new Error('AccessRequest entity not available in this environment.');
  return await AccessRequest.update(requestId, patch);
}

/**
 * Approve an AccessRequest:
 * - mark request APPROVED
 * - create/update MemberRecord/Profile
 * - provision uplink key (optional)
 */
export async function approveAccessRequest({ request, tier, role, path, provision_key = true }) {
  if (!request?.id) throw new Error('Invalid request payload');

  const operator_email = (request.email || '').toString().trim().toLowerCase();
  if (!operator_email) throw new Error('Request is missing an email address');

  const hint = (request.pathway_hint || '').toString().trim().toUpperCase();
  const resolvedPath = (path ?? (hint === 'GAUNTLET' ? 'GNT' : hint === 'INFIRMARY' ? 'INF' : 'ACAD'));
  const resolvedTier = tier ?? (hint === 'GAUNTLET' ? 'GAUNTLET' : hint === 'INFIRMARY' ? 'INFIRMARY' : 'ACADEMY');
  const resolvedRole = role ?? 'operator';

  // 1) Update request status
  await updateAccessRequest(request.id, {
    status: 'APPROVED',
    approved_at: nowIso(),
    approved_by: (await base44.auth.me().catch(() => null))?.email ?? 'UNKNOWN',
    assigned_tier: resolvedTier,
    assigned_role: resolvedRole,
    assigned_path: resolvedPath,
  });

  // 2) Create or patch a profile record
  // Best-effort: attempt to find by email across candidate schemas.
  const Profile = getEntity(PROFILE_ENTS);
  let profile = null;
  if (Profile?.filter) {
    const tries = [{ email: operator_email }, { operator_email }];
    for (const t of tries) {
      try {
        const rows = await Profile.filter(t, '-created_date', 1);
        if (Array.isArray(rows) && rows.length) {
          profile = rows[0];
          break;
        }
      } catch {
        // ignore
      }
    }
  }

  const profilePatch = {
    name: request.name ?? null,
    email: operator_email,
    role: resolvedRole,
    tier: resolvedTier,
    pathway: hint || null,
    risk_profile: request.risk_profile ?? null,
    intake_status: 'APPROVED',
    intake_source: 'ACCESS_REQUEST',
    updated_at: nowIso(),
  };

  let profile_id = null;
  if (Profile?.update && profile?.id) {
    const updated = await Profile.update(profile.id, profilePatch);
    profile_id = updated?.id ?? profile.id;
  } else if (Profile?.create) {
    try {
      const created = await Profile.create({ ...profilePatch, created_at: nowIso() });
      profile_id = created?.id ?? null;
    } catch {
      // ignore
    }
  }

  // 3) Provision key
  let uplink = null;
  if (provision_key) {
    uplink = await provisionUplinkKey({
      operator_email,
      path: resolvedPath,
      tier: resolvedTier,
      profile_id,
      revoke_previous: false,
    }).catch(() => null);
  }

  await writeAudit({
    operator_email,
    action_type: 'ACCESS_REQUEST_APPROVED',
    entity_type: 'AccessRequest',
    details: { request_id: request.id, tier: resolvedTier, role: resolvedRole, path: resolvedPath, provision_key, uplink },
  });

  return { profile_id, uplink };
}

// -------------------------
// Identity / Fleet
// -------------------------

const PROFILE_ENTS = ['MemberRecord', 'Profile', 'MemberIdentity', 'MemberProfile'];
const AUDIT_ENTS = ['AuditTrail', 'SystemAudit', 'AccessAudit'];

export async function listFleet({ q = '', limit = 50 } = {}) {
  const Profile = getEntity(PROFILE_ENTS);
  if (!Profile?.list && !Profile?.filter) return [];

  // If we have a query, attempt filter by email/name where possible.
  if (q && Profile?.filter) {
    // Best-effort: different schemas use different fields.
    const candidates = [
      { email: q },
      { created_by: q },
      { operator_email: q },
      { name: q },
    ];

    for (const c of candidates) {
      try {
        const rows = await Profile.filter(c, '-created_date', limit);
        if (Array.isArray(rows) && rows.length) return rows;
      } catch {
        // continue
      }
    }
  }

  // Fallback list
  try {
    return await Profile.list('-created_date', limit);
  } catch {
    try {
      return await Profile.list();
    } catch {
      return [];
    }
  }
}

export async function updateFleetMember(memberId, patch) {
  const Profile = getEntity(PROFILE_ENTS);
  if (!Profile?.update) throw new Error('Profile entity not available in this environment.');
  return await Profile.update(memberId, patch);
}

export async function writeAudit({ operator_email, action_type, entity_type, details }) {
  const Audit = getEntity(AUDIT_ENTS);
  if (!Audit?.create) return null;
  const me = await base44.auth.me().catch(() => null);
  return await Audit.create({
    operator_id: operator_email,
    action_type,
    entity_type,
    performed_by: me?.email ?? 'UNKNOWN',
    performed_at: nowIso(),
    details: details ?? {},
  });
}

// -------------------------
// Uplink provisioning
// -------------------------

export async function provisionUplinkKey({ operator_email, path, tier, profile_id, revoke_previous = false }) {
  const res = await base44.functions.invoke('generateUplinkKey', {
    operator_email,
    path,
    tier,
    profile_id,
    revoke_previous,
  });
  return res?.data ?? res;
}

export async function rotateUplinkKey({ operator_email, new_tier, new_path, trigger_event }) {
  const res = await base44.functions.invoke('rotateUplinkKey', {
    operator_email,
    new_tier,
    new_path,
    trigger_event,
  });
  return res?.data ?? res;
}



export async function revokeUplinkKey({ operator_email, reason = 'REVOKED' } = {}) {
  // Best-effort: if there is a server function, use it; otherwise patch MemberRecord/Profile.
  try {
    const res = await base44.functions.invoke('revokeUplinkKey', { operator_email, reason });
    return res?.data ?? res;
  } catch {
    // Fallback: patch identity entity
    const Profile = getEntity(PROFILE_ENTS);
    if (!Profile?.filter || !Profile?.update) throw new Error('No identity entity available to revoke key.');
    const rows = await Profile.filter({ email: operator_email }, '-created_date', 1).catch(() => []);
    const rec = rows?.[0];
    if (!rec?.id) throw new Error('Member record not found for revoke.');
    const patch = { uplink_key: null, uplink_keys: [], status: 'SUSPENDED', key_status: reason };
    return await Profile.update(rec.id, patch);
  }
}

// -------------------------
// Weekly Artifact Publishing Pipeline
// -------------------------
// Canon:
// - The Weekly Artifact is the environment contract.
// - Drafts exist only for governance roles.
// - Operators should see only PUBLISHED / LOCKED artifacts.

const WEEKLY_ENTS = ['WeeklyArtifact', 'WeeklyPublication', 'WeeklyBrief'];

export const WEEKLY_STATUS = {
  DRAFT: 'DRAFT',
  PUBLISHED: 'PUBLISHED',
  LOCKED: 'LOCKED',
  ARCHIVED: 'ARCHIVED'
};

const weeklyEntity = () => getEntity(WEEKLY_ENTS);

async function listWeeklyVersions({ instrument, week_of } = {}) {
  const Weekly = weeklyEntity();
  if (!Weekly?.filter) return [];
  try {
    const rows = await Weekly.filter({ instrument, week_of }, '-version_num', 50);
    return Array.isArray(rows) ? rows : [];
  } catch {
    // Fallback: sort by created_date if version_num is unsupported.
    try {
      const rows = await Weekly.filter({ instrument, week_of }, '-created_date', 50);
      return Array.isArray(rows) ? rows : [];
    } catch {
      return [];
    }
  }
}

async function nextVersionNum({ instrument, week_of } = {}) {
  const versions = await listWeeklyVersions({ instrument, week_of });
  const top = versions?.[0];
  const n = Number(top?.version_num);
  return Number.isFinite(n) ? n + 1 : (versions.length ? versions.length + 1 : 1);
}

const buildCanonHeader = ({ instrument, week_of, status, version_num }) => ({
  canon_name: `Weekly Artifact — ${instrument}`,
  canon_version: `WEEKLY.${week_of}.v${version_num}`,
  canon_status: status,
  canon_role_surface: 'Warden / Governance',
  canon_last_updated: nowIso(),
});

export async function upsertWeeklyDraft({
  instrument,
  week_of,
  wk_type = 'UNDECLARED',
  wk_confidence = 0,
  focus = '',
  warning = '',
  macro_cap = 1.0,
  notes = '',
  changelog = '',
  operator_impact = ''
}) {
  const Weekly = weeklyEntity();
  if (!Weekly?.create) throw new Error('Weekly publication entity not available in this environment.');

  // If a draft already exists, update it (best-effort).
  let existing = null;
  if (Weekly?.filter) {
    try {
      const rows = await Weekly.filter({ instrument, week_of, status: WEEKLY_STATUS.DRAFT }, '-created_date', 1);
      existing = rows?.[0] ?? null;
    } catch {
      existing = null;
    }
  }

  const version_num = existing?.version_num ?? (await nextVersionNum({ instrument, week_of }));
  const status = WEEKLY_STATUS.DRAFT;
  const canon = buildCanonHeader({ instrument, week_of, status, version_num });

  const payload = {
    instrument,
    week_of,
    wk_type,
    wk_confidence,
    focus,
    warning,
    macro_cap,
    notes,
    status,
    version_num,
    changelog,
    operator_impact,
    ...canon,
    updated_at: nowIso(),
  };

  const record = {
    ...payload,
    payload_json: JSON.stringify(payload),
  };

  if (existing?.id && Weekly?.update) {
    return await Weekly.update(existing.id, record);
  }
  return await Weekly.create({ ...record, created_at: nowIso() });
}

export async function publishWeeklyArtifact({
  instrument,
  week_of,
  wk_type,
  wk_confidence,
  focus,
  warning,
  macro_cap,
  notes,
  changelog = 'Initial publication.',
  operator_impact = '',
}) {
  const Weekly = weeklyEntity();
  if (!Weekly?.create) throw new Error('Weekly publication entity not available in this environment.');

  const version_num = await nextVersionNum({ instrument, week_of });
  const status = WEEKLY_STATUS.PUBLISHED;
  const canon = buildCanonHeader({ instrument, week_of, status, version_num });

  const payload = {
    instrument,
    week_of,
    wk_type,
    wk_confidence,
    focus,
    warning,
    macro_cap,
    notes,
    status,
    version_num,
    changelog,
    operator_impact,
    published_at: nowIso(),
    ...canon,
  };

  const record = {
    ...payload,
    payload_json: JSON.stringify(payload),
  };

  return await Weekly.create(record);
}

export async function lockWeeklyArtifact({ id }) {
  const Weekly = weeklyEntity();
  if (!Weekly?.update) throw new Error('Weekly publication entity not available in this environment.');
  return await Weekly.update(id, {
    status: WEEKLY_STATUS.LOCKED,
    locked_at: nowIso(),
    canon_status: WEEKLY_STATUS.LOCKED,
    canon_last_updated: nowIso(),
  });
}

export async function archiveWeeklyArtifact({ id }) {
  const Weekly = weeklyEntity();
  if (!Weekly?.update) throw new Error('Weekly publication entity not available in this environment.');
  return await Weekly.update(id, {
    status: WEEKLY_STATUS.ARCHIVED,
    archived_at: nowIso(),
    canon_status: WEEKLY_STATUS.ARCHIVED,
    canon_last_updated: nowIso(),
  });
}

export async function amendWeeklyArtifact({
  parent_id,
  instrument,
  week_of,
  patch,
  changelog,
  operator_impact = ''
}) {
  const Weekly = weeklyEntity();
  if (!Weekly?.create) throw new Error('Weekly publication entity not available in this environment.');
  const version_num = await nextVersionNum({ instrument, week_of });
  const status = WEEKLY_STATUS.PUBLISHED;
  const canon = buildCanonHeader({ instrument, week_of, status, version_num });

  const payload = {
    ...(patch ?? {}),
    instrument,
    week_of,
    status,
    version_num,
    amendment_of: parent_id,
    changelog: changelog || 'Amendment.',
    operator_impact,
    published_at: nowIso(),
    ...canon,
  };

  const record = {
    ...payload,
    payload_json: JSON.stringify(payload),
  };

  return await Weekly.create(record);
}

// -------------------------
// Sentinel (manual governance)
// -------------------------

const SENT_EVENT_ENTS = ['SentinelEvent'];

export async function listSentinelEvents({ activeOnly = false, limit = 50 } = {}) {
  const Ent = getEntity(SENT_EVENT_ENTS);
  if (!Ent?.filter && !Ent?.list) return [];
  if (activeOnly && Ent?.filter) {
    try {
      return await Ent.filter({ active: true }, '-created_date', limit);
    } catch {
      return [];
    }
  }
  try {
    return await Ent.list('-created_date', limit);
  } catch {
    return [];
  }
}

export async function upsertSentinelEvent({ id, patch }) {
  const Ent = getEntity(SENT_EVENT_ENTS);
  if (!Ent?.create) throw new Error('SentinelEvent entity not available.');
  if (id && Ent?.update) return await Ent.update(id, patch);
  return await Ent.create(patch);
}
