import { getNexusLive } from '@/data/api';

// Best-effort extraction of governance + environment fields from Nexus STATE_SNAPSHOT payload.

const safeGet = (obj, path, fallback = null) => {
  try {
    return path.split('.').reduce((acc, k) => (acc && acc[k] !== undefined ? acc[k] : undefined), obj) ?? fallback;
  } catch {
    return fallback;
  }
};

const normalizeSnapshot = (row) => {
  const payload = row?.payload ?? row?.snapshot ?? row?.state ?? row?.data ?? null;
  const meta = safeGet(payload, 'meta', {});
  const gov = safeGet(payload, 'governance', {});
  const servo = safeGet(payload, 'servo', {});

  return {
    uplink_key: row?.uplink_key ?? null,
    last_seen_timestamp_ms: row?.last_seen_timestamp_ms ?? row?.event_time_ms ?? null,

    // Market identity
    symbol: meta?.symbol ?? meta?.symbol_id ?? null,
    tf: meta?.tf ?? null,
    is_exec_tf: meta?.is_exec_tf ?? null,

    // Governance / permission
    gov_state: gov?.gov_state ?? null,
    is_permitted: gov?.is_permitted ?? null,
    toi_active: gov?.toi_active ?? null,
    sentinel_state: gov?.sentinel_state ?? null,
    global_void: gov?.global_void ?? null,
    probe_only: gov?.probe_only ?? null,
    denial_reason: gov?.denial_reason ?? null,
    navigator_bias: gov?.navigator_bias ?? null,
    matrix_healthy: gov?.matrix_healthy ?? null,

    // Weekly classifier output (if present)
    wk_type: gov?.wk_type ?? null,
    wk_confidence: gov?.wk_confidence ?? null,

    // Load clamp
    servo_decision: servo?.servo_decision ?? null,
    servo_reason: servo?.servo_reason ?? null,
    risk_multiplier: servo?.risk_multiplier ?? null,
    env_cap: servo?.env_cap ?? null,
  };
};

export async function getTrainingTelemetryContext({ uplink_key } = {}) {
  if (!uplink_key) return null;
  const row = await getNexusLive({ uplink_key }).catch(() => null);
  if (!row) return null;
  return normalizeSnapshot(row);
}
