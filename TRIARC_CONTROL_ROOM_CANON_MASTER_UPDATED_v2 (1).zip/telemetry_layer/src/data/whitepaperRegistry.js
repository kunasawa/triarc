/**
 * whitepaperRegistry.js — Public-facing Whitepaper Corridor (Outreach)
 * Canon intent: distribute doctrine without leaking execution.
 *
 * NOTE: Content here is intentionally summarized. Full artifacts should be served
 * through the controlled publishing pipeline (CMS/gated storage) with versioning.
 */

export const WHITEPAPERS = [
  {
    id: "WP-UEDF-001",
    title: "Institutional Operational Framework — The Unified Environmental Protocol",
    canon_status: "PUBLISHED",
    tier: "Public",
    canon_version: "WP-UEDF-001.v1",
    canon_last_updated: "2026-02-14",
    canon_role_surface: "Public Corridor / Governance",
    changelog: "v1: corridor publication. Summarized outreach form.",
    operator_impact: "Doctrine exposure only. No execution permission granted.",
    summary:
      "A doctrine-first framework for reading markets as environments. Defines the environmental stack and the sovereignty rule: Permission precedes participation.",
    tags: ["Environment", "Governance", "Permission > Opportunity"],
    source_url: "",
  },
  {
    id: "WP-ENV-002",
    title: "Stop Trading Patterns, Start Trading Environments — 5 Counter-Intuitive Truths",
    canon_status: "PUBLISHED",
    tier: "Public",
    canon_version: "WP-ENV-002.v1",
    canon_last_updated: "2026-02-14",
    canon_role_surface: "Public Corridor / Governance",
    changelog: "v1: corridor publication. Summarized outreach form.",
    operator_impact: "Doctrine exposure only. No execution permission granted.",
    summary:
      "A corrective thesis against pattern-chasing. Reframes operator work as environmental classification, volatility management, and permission alignment.",
    tags: ["Environment", "Structure > Pattern", "Volatility > Direction"],
    source_url: "",
  },
  {
    id: "WP-FLEET-003",
    title: "The TriArc Fleet — Three-Path Architecture",
    canon_status: "PUBLISHED",
    tier: "Public",
    canon_version: "WP-FLEET-003.v1",
    canon_last_updated: "2026-02-14",
    canon_role_surface: "Public Corridor / Governance",
    changelog: "v1: corridor publication. Summarized outreach form.",
    operator_impact: "Doctrine exposure only. No execution permission granted.",
    summary:
      "An overview of the three-path routing model (Academy, Infirmary, Gauntlet) and how identity, permission, and governance determine progression.",
    tags: ["Pathways", "Identity", "Governance"],
    source_url: "",
  },
];

export const getWhitepaperById = (id) => WHITEPAPERS.find((w) => w.id === id);
