// TriArc Control Room — Audit Export
// Exports a governance JSON bundle. Best-effort entity resolution.

// NOTE:
// This module assumes you have a Base44-style data client available.
// Replace `api.list()` with your concrete data access layer.

import { RETENTION } from './retentionPolicy.js';

const ENTITY_ALIASES = {
  NexusStateLive: ['NexusStateLive', 'NexusLive', 'NexusSnapshot', 'StateSnapshot'],
  ComplianceEvent: ['ComplianceEvent', 'ComplianceEvents', 'Compliance_Log'],
  RemediationCase: ['RemediationCase', 'Remediation', 'RemediationCases'],
  GovernanceIncident: ['GovernanceIncident', 'Incident', 'Incidents'],
  EnforcementAction: ['EnforcementAction', 'Enforcement', 'EnforcementActions'],
  TrainingSubmission: ['TrainingSubmission', 'TrainingSubmissions', 'CheckpointSubmission'],
  TrainingProgress: ['TrainingProgress', 'Progress', 'ModuleProgress'],
};

async function tryList(api, names, query) {
  for (const n of names) {
    try {
      const res = await api.list(n, query);
      if (Array.isArray(res)) return { entity: n, rows: res };
      if (res?.items && Array.isArray(res.items)) return { entity: n, rows: res.items };
    } catch (e) {
      // ignore and continue
    }
  }
  return { entity: null, rows: [] };
}

export async function exportAuditBundle({ api, uplinkKey, startMs, endMs }) {
  if (!api) throw new Error('exportAuditBundle requires an api client');
  if (!uplinkKey) throw new Error('uplinkKey is required');

  const start = startMs ?? (Date.now() - RETENTION.DEFAULT_OPPORTUNITY_DAYS * 86400000);
  const end = endMs ?? Date.now();

  const baseQuery = {
    where: {
      uplink_key: uplinkKey,
      timestamp_ms: { $gte: start, $lte: end },
    },
    limit: 5000,
  };

  const snapshotQ = {
    where: {
      uplink_key: uplinkKey,
      // some stores use event_time_ms for snapshots
      $or: [
        { timestamp_ms: { $gte: start, $lte: end } },
        { event_time_ms: { $gte: start, $lte: end } },
      ],
    },
    limit: 5000,
  };

  const [snap, comp, rem, inc, enf, sub, prog] = await Promise.all([
    tryList(api, ENTITY_ALIASES.NexusStateLive, snapshotQ),
    tryList(api, ENTITY_ALIASES.ComplianceEvent, baseQuery),
    tryList(api, ENTITY_ALIASES.RemediationCase, { where: { uplink_key: uplinkKey }, limit: 2000 }),
    tryList(api, ENTITY_ALIASES.GovernanceIncident, { where: { uplink_key: uplinkKey }, limit: 2000 }),
    tryList(api, ENTITY_ALIASES.EnforcementAction, { where: { uplink_key: uplinkKey }, limit: 2000 }),
    tryList(api, ENTITY_ALIASES.TrainingSubmission, { where: { uplink_key: uplinkKey }, limit: 5000 }),
    tryList(api, ENTITY_ALIASES.TrainingProgress, { where: { uplink_key: uplinkKey }, limit: 2000 }),
  ]);

  return {
    meta: {
      schema: 'TRIARC_AUDIT_BUNDLE',
      schema_version: '1.0',
      generated_at_ms: Date.now(),
      uplink_key: uplinkKey,
      window: { start_ms: start, end_ms: end },
      resolved_entities: {
        snapshots: snap.entity,
        compliance: comp.entity,
        remediation: rem.entity,
        incidents: inc.entity,
        enforcement: enf.entity,
        training_submissions: sub.entity,
        training_progress: prog.entity,
      },
    },
    snapshots: snap.rows,
    compliance_events: comp.rows,
    remediation_cases: rem.rows,
    governance_incidents: inc.rows,
    enforcement_actions: enf.rows,
    training_submissions: sub.rows,
    training_progress: prog.rows,
  };
}
