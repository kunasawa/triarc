/**
 * publishingPipeline.js — Canon publishing lifecycle (draft → review → approved → published)
 *
 * Purpose: keep outreach material governed.
 */

import { apiClient } from "@/lib/api";
import { createEnforcementAction, createIncident } from "@/data/api";
import {
  DOCTRINE_VALIDATION,
  buildOutboundBody,
  validateDoctrine,
} from "@/data/doctrineGuard";

export const DOC_STATUS = Object.freeze({
  DRAFT: "DRAFT",
  REVIEW: "REVIEW",
  APPROVED: "APPROVED",
  PUBLISHED: "PUBLISHED",
  ARCHIVED: "ARCHIVED",
});

const nowIso = () => new Date().toISOString();

function entity(name) {
  try {
    return apiClient?.entities?.[name] ?? null;
  } catch {
    return null;
  }
}

// Tolerant entity resolution (schema may vary by environment)
function canonDocEntity() {
  return (
    entity("CanonDocument") ||
    entity("PublishingDocument") ||
    entity("LibraryDocument") ||
    entity("Document")
  );
}

function canonChangeEntity() {
  return (
    entity("CanonChangelog") ||
    entity("DocumentChangelog") ||
    entity("PublishingChangelog") ||
    null
  );
}

export function buildCanonHeader({ id, name, version, status, tier, roleSurface }) {
  return {
    canon_id: id,
    canon_name: name,
    canon_version: version,
    canon_status: status,
    canon_tier: tier,
    canon_role_surface: roleSurface,
    canon_last_updated: nowIso(),
  };
}

export async function listCanonDocs({ status } = {}) {
  const Docs = canonDocEntity();
  if (!Docs?.filter) return [];
  try {
    const q = status ? { canon_status: status } : {};
    const rows = await Docs.filter(q, "-updated_at", 200);
    return Array.isArray(rows) ? rows : [];
  } catch {
    return [];
  }
}

export function buildOutreachBody({ title, summary }) {
  return buildOutboundBody({ title, summary });
}

export async function upsertCanonDraft({
  id,
  title,
  tier = "Public",
  roleSurface = "Governance",
  summary = "",
  body = "",
  operatorImpact = "—",
  changelog = "—",
  source_url = "",
  tags = [],
} = {}) {
  const Docs = canonDocEntity();
  if (!Docs?.create) throw new Error("Publishing entity not available in this environment.");

  // Best-effort: find existing by canon_id
  let existing = null;
  if (Docs?.filter) {
    try {
      const rows = await Docs.filter({ canon_id: id }, "-updated_at", 1);
      existing = rows?.[0] ?? null;
    } catch {
      existing = null;
    }
  }

  const version_num = Number(existing?.version_num);
  const nextVersion = Number.isFinite(version_num) ? version_num : 0;
  const v = existing ? nextVersion : 1;
  const status =
    existing?.canon_status && existing.canon_status !== DOC_STATUS.ARCHIVED
      ? existing.canon_status
      : DOC_STATUS.DRAFT;

  const canon = buildCanonHeader({
    id,
    name: title,
    version: `${id}.v${v}`,
    status,
    tier,
    roleSurface,
  });

  const safeBody = (body || "").trim() || buildOutreachBody({ title, summary });

  const payload = {
    ...canon,
    title,
    summary,
    body: safeBody,
    tags: Array.isArray(tags) ? tags.join(", ") : String(tags || ""),
    operator_impact: operatorImpact,
    changelog,
    source_url,
    version_num: v,
    updated_at: nowIso(),
  };

  if (existing?.id && Docs?.update) {
    return await Docs.update(existing.id, payload);
  }
  return await Docs.create(payload);
}

async function fetchCanonDocById(canon_id) {
  const Docs = canonDocEntity();
  if (!Docs?.filter) throw new Error("Publishing entity not available in this environment.");
  const rows = await Docs.filter({ canon_id }, "-updated_at", 1);
  const doc = rows?.[0];
  if (!doc?.id) throw new Error("Document not found.");
  return { Docs, doc };
}

export async function validateAndPersistDoctrine({
  canon_id,
  actor_role = "unknown",
  note = "Doctrine validation",
} = {}) {
  const { Docs, doc } = await fetchCanonDocById(canon_id);

  const result = validateDoctrine(doc);

  // Best-effort persistence: environments may not have these columns.
  if (Docs?.update) {
    try {
      await Docs.update(doc.id, {
        doctrine_validation: result.status,
        doctrine_report: JSON.stringify(result.violations),
        doctrine_validated_at: nowIso(),
        updated_at: nowIso(),
      });
    } catch {
      // ignore
    }
  }

  // Create an incident on FAIL so governance can audit drift.
  if (result.status === DOCTRINE_VALIDATION.FAIL) {
    try {
      await createIncident({
        uplink_key: "CANON",
        status: "OPEN",
        severity: "MEDIUM",
        category: "OUTREACH_DOCTRINE_VIOLATION",
        title: `Doctrine validation failed: ${canon_id}`,
        description: JSON.stringify(result.violations),
        actor_role,
        timestamp_ms: Date.now(),
        created_date: nowIso(),
        updated_at: nowIso(),
        note,
      });
    } catch {
      // ignore
    }
  }

  return { doc, result };
}

export async function transitionCanonDoc({
  canon_id,
  toStatus,
  note = "",
  actor_role = "unknown",
  override_doctrine_guard = false,
} = {}) {
  const { Docs, doc } = await fetchCanonDocById(canon_id);

  // Hard stop on publishing without doctrine validation pass.
  if (toStatus === DOC_STATUS.PUBLISHED) {
    const { result } = await validateAndPersistDoctrine({
      canon_id,
      actor_role,
      note: "Publish gate validation",
    });

    if (result.status !== DOCTRINE_VALIDATION.PASS && !override_doctrine_guard) {
      const v = result.violations;
      const summary = [
        v.missing_fields?.length ? `missing_fields=${v.missing_fields.length}` : null,
        v.missing_boundary?.length ? `missing_boundary=${v.missing_boundary.length}` : null,
        v.prohibited_terms?.length ? `prohibited_terms=${v.prohibited_terms.length}` : null,
        v.prohibited_patterns?.length ? `prohibited_patterns=${v.prohibited_patterns.length}` : null,
      ]
        .filter(Boolean)
        .join(" | ");

      throw new Error(`Doctrine Guard blocked publishing (${summary}). Validate + repair, or override (admin/architect).`);
    }

    if (result.status !== DOCTRINE_VALIDATION.PASS && override_doctrine_guard) {
      try {
        await createEnforcementAction({
          uplink_key: "CANON",
          action: "DOCTRINE_GUARD_OVERRIDE",
          scope: canon_id,
          actor_role,
          timestamp_ms: Date.now(),
          created_date: nowIso(),
          updated_at: nowIso(),
          note: note || "Override used to publish despite doctrine validation failure.",
        });
      } catch {
        // ignore
      }
    }
  }

  const updated = await Docs.update(doc.id, {
    canon_status: toStatus,
    canon_last_updated: nowIso(),
    updated_at: nowIso(),
  });

  // Optional changelog write
  const Changes = canonChangeEntity();
  if (Changes?.create) {
    try {
      await Changes.create({ canon_id, at: nowIso(), to_status: toStatus, note });
    } catch {
      // ignore
    }
  }

  return updated;
}
