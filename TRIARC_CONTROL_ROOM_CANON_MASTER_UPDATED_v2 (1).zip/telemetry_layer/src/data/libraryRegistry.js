// TriArc Library Registry (binding layer)

const doc = ({ id, title, category, status = 'UNBOUND', url = '' }) => ({ id, title, category, status, url });

export const LIBRARY_DOCS = [
  doc({ id: 'TRN-M01', title: 'M01 System Physics', category: 'training', status: 'UNBOUND' }),
  doc({ id: 'TRN-M02', title: 'M02 Risk Calibration', category: 'training', status: 'UNBOUND' }),
  doc({ id: 'TRN-M03', title: 'M03 Warden Map', category: 'training', status: 'UNBOUND' }),
  doc({ id: 'TRN-M04', title: 'M04 Daily Cycle', category: 'training', status: 'UNBOUND' }),
  doc({ id: 'TRN-M05', title: 'M05 Sentinel Defense', category: 'training', status: 'UNBOUND' }),
  doc({ id: 'TRN-M06', title: 'M06 Macro (SMR)', category: 'training', status: 'UNBOUND' }),
  doc({ id: 'TRN-M07', title: 'M07 Auditing Lifecycle', category: 'training', status: 'UNBOUND' }),
  doc({ id: 'DOC-SOV', title: 'Doctrine of Sovereignty', category: 'doctrine', status: 'ACTIVE' }),
  doc({ id: 'DOC-CONST', title: 'Sovereign Constitution', category: 'doctrine', status: 'ACTIVE' }),
  doc({ id: 'DOC-MACRO', title: 'Macro Doctrine', category: 'doctrine', status: 'ACTIVE' }),
  doc({ id: 'PB-ES', title: 'Playbook ES', category: 'playbooks', status: 'ACTIVE' }),
  doc({ id: 'PB-NQ', title: 'Playbook NQ', category: 'playbooks', status: 'ACTIVE' }),
  doc({ id: 'PB-GC', title: 'Playbook GC', category: 'playbooks', status: 'ACTIVE' }),
  doc({ id: 'PB-CL', title: 'Playbook CL', category: 'playbooks', status: 'ACTIVE' }),
];

export const findDocById = (id) => LIBRARY_DOCS.find((d) => d.id === id) || null;