/**
 * TriArc Sovereign Control Room — Rollout Policy (Frontend)
 *
 * Purpose:
 * - Provide a single, explicit gate for whether an artifact may be seen and/or opened.
 * - Keep the rules deterministic and boring.
 *
 * Notes:
 * - This is UI governance only. Server-side RBAC remains the source of truth.
 */

export const SURFACE = {
  LIBRARY: 'library',
  WEEKLY: 'weekly',
  ONBOARDING: 'onboarding',
  GOVERNANCE: 'governance',
};

export const ROLLOUT_STAGE = {
  CLOSED: 'CLOSED',
  INTERNAL: 'INTERNAL',
  MEMBER: 'MEMBER',
  PUBLIC: 'PUBLIC',
};

const norm = (v) => (v ?? '').toString().trim();
const normUpper = (v) => norm(v).toUpperCase();

function isStaffRole(role) {
  const r = (role || '').toString().toLowerCase();
  return r === 'admin' || r === 'controller' || r === 'architect';
}

export function deriveRollout(doc) {
  const surface = norm(doc?.surface || SURFACE.LIBRARY).toLowerCase();
  const status = normUpper(doc?.status || 'ACTIVE');

  let stage = ROLLOUT_STAGE.MEMBER;
  if (status === 'PUBLIC') stage = ROLLOUT_STAGE.PUBLIC;
  else if (status === 'DRAFT' || status === 'INTERNAL') stage = ROLLOUT_STAGE.INTERNAL;
  else if (status === 'CLOSED' || status === 'RETIRED') stage = ROLLOUT_STAGE.CLOSED;

  return { surface, status, stage };
}

export function canViewArtifact({ doc, user, surface } = {}) {
  const { stage } = deriveRollout(doc);
  const s = (surface || doc?.surface || SURFACE.LIBRARY).toString().toLowerCase();

  if (stage === ROLLOUT_STAGE.CLOSED) return false;
  if (stage === ROLLOUT_STAGE.PUBLIC) return true;
  if (!user) return false;
  if (stage === ROLLOUT_STAGE.INTERNAL) return isStaffRole(user?.role);

  return !!s;
}
