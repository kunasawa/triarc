import { base44 } from '@/api/base44Client';
import { getComplianceSummary, listIncidents, listRemediationCases, listComplianceEvents } from '@/data/api';

/**
 * Operator Stability Index (v1)
 *
 * Canon intent:
 * - Provide a governance-grade stability signal (0–100) that is NOT PnL-derived.
 * - Index is computed from compliance posture, incidents/enforcement history, remediation load,
 *   and training maturity (when available).
 *
 * Design:
 * - Best-effort entity resolution (works across legacy/canonical Base44 schemas).
 * - Never blocks the UI; returns partial results with a `source` field.
 */

const tryEntity = (name) => {
  try {
    return base44.entities?.[name] ?? null;
  } catch {
    return null;
  }
};

const pickEntity = (names) => {
  for (const n of names) {
    const e = tryEntity(n);
    if (e) return e;
  }
  return null;
};

const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));

const toUpper = (v) => (v ?? '').toString().toUpperCase();

const getTs = (row) => {
  // Prefer explicit timestamp_ms
  const a = Number(row?.timestamp_ms);
  if (Number.isFinite(a) && a > 0) return a;

  // Common alternatives
  const b = Number(row?.event_time_ms);
  if (Number.isFinite(b) && b > 0) return b;

  // ISO-ish dates
  const c = row?.created_date || row?.createdAt || row?.created_at || row?.updated_at;
  if (c) {
    const t = Date.parse(c);
    if (Number.isFinite(t)) return t;
  }
  return null;
};

const ageDays = (ts) => {
  if (!ts) return null;
  const now = Date.now();
  return (now - ts) / (1000 * 60 * 60 * 24);
};

async function lookupIdentityByUplinkKey(uplink_key) {
  if (!uplink_key) return null;

  const Ent = pickEntity([
    'MemberIdentity',
    'MemberProfile',
    'MemberRecord',
    'Profile',
    'OperatorProfile',
    'IdentityProfile',
    'UserProfile',
  ]);

  if (!Ent?.filter) return null;

  // Try common field names
  const candidates = [
    { uplink_key },
    { uplinkKey: uplink_key },
    { uplink: uplink_key },
    { uplink_id: uplink_key },
  ];

  for (const q of candidates) {
    try {
      const rows = await Ent.filter(q, '-updated_at', 5);
      const hit = Array.isArray(rows) ? rows[0] : null;
      if (hit) {
        return {
          member_id: hit?.member_id ?? hit?.memberId ?? hit?.id ?? null,
          operator_email: hit?.email ?? hit?.operator_email ?? hit?.operatorEmail ?? null,
          role: hit?.role ?? hit?.rbac_role ?? null,
          tier: hit?.tier ?? hit?.membership_tier ?? null,
          source: Ent?.name ?? 'identity_entity'
        };
      }
    } catch {
      // try next
    }
  }

  return null;
}

async function listTrainingProgress({ operator_email, member_id, limit = 200 } = {}) {
  const Ent = pickEntity([
    'TrainingProgress',
    'TrainingProgressRecord',
    'ModuleProgress',
    'TrainingMaturity',
    'TrainingStatus',
  ]);

  if (!Ent?.filter) return [];

  const qCandidates = [];
  if (operator_email) qCandidates.push({ operator_email });
  if (operator_email) qCandidates.push({ email: operator_email });
  if (member_id) qCandidates.push({ member_id });
  if (member_id) qCandidates.push({ memberId: member_id });

  for (const q of qCandidates) {
    try {
      const rows = await Ent.filter(q, '-timestamp_ms', limit);
      if (Array.isArray(rows)) return rows;
    } catch {
      // continue
    }
  }
  return [];
}

function computeFromInputs({
  complianceScore = null,
  openCases = 0,
  incidents = [],
  remediation = [],
  complianceEvents = [],
  trainingProgress = [],
  flags = {}
} = {}) {
  // Base anchor: compliance score when available, else 80 (neutral-but-cautious).
  let score = Number.isFinite(Number(complianceScore)) ? Number(complianceScore) : 80;

  const deductions = [];
  const addDeduction = (label, pts) => {
    const p = Math.max(0, Math.round(pts));
    if (p > 0) deductions.push({ label, pts: p });
    score -= p;
  };

  // Holds
  if (flags?.execution_hold === true) addDeduction('Execution Hold', 30);

  // Open remediation cases
  const open = Number(openCases ?? remediation?.length ?? 0) || 0;
  addDeduction('Open Remediation Load', clamp(open * 10, 0, 30));

  // Incident severity in last 30 days
  const nowInc = (incidents || []).map((i) => ({ ...i, _ts: getTs(i), _age: ageDays(getTs(i)) }));
  const recent30 = nowInc.filter((i) => i._age != null && i._age <= 30);
  const recent14 = nowInc.filter((i) => i._age != null && i._age <= 14);

  const sevPts = { CRITICAL: 20, MAJOR: 10, MINOR: 3 };
  let sevTotal = 0;
  for (const i of recent30) {
    const sev = toUpper(i?.severity);
    sevTotal += (sevPts[sev] ?? 5);
    // Sentinel-specific weight
    const vt = toUpper(i?.violation_type || i?.type || i?.category);
    if (vt.includes('SENTINEL')) sevTotal += 10;
  }
  addDeduction('Incidents (30d)', clamp(sevTotal, 0, 50));

  // Compliance events as micro-signal (if incidents not populated)
  if ((!incidents || incidents.length === 0) && Array.isArray(complianceEvents) && complianceEvents.length) {
    const evRecent = complianceEvents
      .map((e) => ({ ...e, _age: ageDays(getTs(e)) }))
      .filter((e) => e._age != null && e._age <= 14);

    const evPts = evRecent.reduce((acc, e) => {
      const sev = toUpper(e?.severity);
      if (sev === 'CRITICAL') return acc + 15;
      if (sev === 'MAJOR') return acc + 7;
      if (sev === 'MINOR') return acc + 2;
      return acc;
    }, 0);

    addDeduction('Recent Compliance Events (14d)', clamp(evPts, 0, 25));
  }

  // Training maturity (optional tailwind)
  // Normalize: count completed modules if present.
  let trainingBoost = 0;
  if (Array.isArray(trainingProgress) && trainingProgress.length) {
    const completed = trainingProgress.filter((p) => {
      const st = toUpper(p?.status ?? p?.state);
      return st === 'COMPLETE' || st === 'COMPLETED' || st === 'PASSED';
    }).length;

    // max +10
    trainingBoost = clamp(Math.round((completed / Math.max(1, trainingProgress.length)) * 10), 0, 10);
  }
  score += trainingBoost;

  // Clean streak bonus (no incidents in last 14d)
  if (recent14.length === 0 && (incidents || []).length > 0) score += 5;

  score = clamp(score, 0, 100);

  return {
    stability_index: score,
    training_boost: trainingBoost,
    deductions,
  };
}

export async function computeStabilityIndex({ uplink_key, member_id, operator_email } = {}) {
  try {
    const ident = (!member_id && !operator_email) ? await lookupIdentityByUplinkKey(uplink_key) : null;
    const mid = member_id ?? ident?.member_id ?? null;
    const email = operator_email ?? ident?.operator_email ?? null;

    const [comp, incidents, remediation, events, progress] = await Promise.all([
      getComplianceSummary({ member_id: mid, uplink_key }),
      listIncidents({ uplink_key, limit: 200 }),
      listRemediationCases({ member_id: mid, uplink_key, status: 'OPEN', limit: 200 }),
      listComplianceEvents({ uplink_key, limit: 200 }),
      listTrainingProgress({ operator_email: email, member_id: mid, limit: 200 }),
    ]);

    const flags = {
      execution_hold: toUpper(comp?.permission_state).includes('HOLD') || toUpper(comp?.status).includes('HOLD') || comp?.execution_hold === true
    };

    const computed = computeFromInputs({
      complianceScore: comp?.score,
      openCases: comp?.open_cases,
      incidents,
      remediation,
      complianceEvents: events,
      trainingProgress: progress,
      flags
    });

    return {
      ...computed,
      uplink_key,
      member_id: mid,
      operator_email: email,
      compliance: comp ?? null,
      incident_count_30d: (incidents || []).filter((i) => {
        const a = ageDays(getTs(i));
        return a != null && a <= 30;
      }).length,
      remediation_open: remediation?.length ?? (comp?.open_cases ?? 0),
      source: 'computed'
    };
  } catch (e) {
    return {
      uplink_key,
      stability_index: 0,
      deductions: [{ label: 'Computation Error', pts: 100 }],
      source: 'error'
    };
  }
}

export function stabilityColor(index) {
  const v = Number(index);
  if (!Number.isFinite(v)) return 'bg-slate-700';
  if (v >= 80) return 'bg-emerald-700';
  if (v >= 60) return 'bg-yellow-700';
  if (v >= 40) return 'bg-orange-700';
  return 'bg-red-800';
}

export function stabilityLabel(index) {
  const v = Number(index);
  if (!Number.isFinite(v)) return 'UNKNOWN';
  if (v >= 80) return 'STABLE';
  if (v >= 60) return 'WATCH';
  if (v >= 40) return 'FRAGILE';
  return 'CRITICAL';
}
