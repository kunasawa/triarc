// TriArc Training Registry (pre-canon maturity)
//
// This registry provides a stable list of training modules rendered across
// pathway hubs (Academy / Infirmary / Gauntlet).
//
// Persistence is intentionally local (localStorage) until the Training Progress
// entity is finalized in the data layer.

const mod = ({ id, title, phase, order, focus, docId = null, checkpoint = null, status = 'ACTIVE', tags = [] }) => ({
  id,
  title,
  phase,
  order,
  focus,
  docId,
  checkpoint,
  status,
  tags,
});

export const TRAINING_PATHWAYS = {
  academy: {
    key: 'academy',
    label: 'ACADEMY',
    subtitle:
      'Apprenticeship track. Structure literacy and permission discipline. Execution remains constrained until governance upgrades.',
  },
  infirmary: {
    key: 'infirmary',
    label: 'INFIRMARY',
    subtitle:
      'Rehabilitation track. Recovery from outcome-chasing, drift, or fatigue. The goal is stability and obedience before re-entry.',
  },
  gauntlet: {
    key: 'gauntlet',
    label: 'GAUNTLET',
    subtitle:
      'Operator-engineering track. System discipline, auditing competence, and sovereign execution readiness.',
  },
};

export const TRAINING_MODULES = {
  academy: [
    mod({
      id: 'M01',
      docId: 'TRN-M01',
      order: 1,
      phase: 'Academy Core',
      title: 'Module 1 — System Physics (Axiom Layer)',
      focus: 'Time > Price. Structure > Pattern. Volatility > Direction. Permission > Opportunity.',
      tags: ['axioms', 'doctrine'],
    }),
    mod({
      id: 'M02',
      docId: 'TRN-M02',
      order: 2,
      phase: 'Academy Core',
      title: 'Module 2 — Risk & Kinetic Calibration',
      focus: 'Load discipline, kinetic controls, and the distinction between allowed and desired.',
      tags: ['risk', 'load'],
    }),
    mod({
      id: 'M03',
      docId: 'TRN-M03',
      order: 3,
      phase: 'Academy Core',
      title: 'Module 3 — The Warden Map (Structural Life Cycle)',
      focus: 'Life-cycle recognition: purge, rotation, migration, acceptance, compression.',
      tags: ['warden', 'structure'],
    }),
    mod({
      id: 'M04',
      docId: 'TRN-M04',
      order: 4,
      phase: 'Academy Core',
      title: 'Module 4 — Daily Structural Cycle & TOI',
      focus: 'Time-of-Intent governance. Session windows as permission, not convenience.',
      tags: ['toi', 'cadence'],
    }),
    mod({
      id: 'M05',
      docId: 'TRN-M05',
      order: 5,
      phase: 'Academy Core',
      title: 'Module 5 — Sentinel Event Defense (State N)',
      focus: 'Sentinel overrides participation. Stand down doctrine and distortion rules.',
      tags: ['sentinel', 'events'],
    }),
    mod({
      id: 'M06',
      docId: 'TRN-M06',
      order: 6,
      phase: 'Academy Core',
      title: 'Module 6 — Instrument Macro (SMR)',
      focus: 'Structural macro rails and SMR interaction; environment before impulse.',
      tags: ['macro', 'smr'],
    }),
    mod({
      id: 'M07',
      docId: 'TRN-M07',
      order: 7,
      phase: 'Academy Core',
      title: 'Module 7 — TriArc Auditing Lifecycle',
      focus: 'Audit integrity: permission logs, breach review, remediation triggers.',
      tags: ['audit', 'governance'],
    }),
  ],
  infirmary: [
    mod({
      id: 'INF-A',
      order: 1,
      phase: 'Phase Alpha',
      title: 'Forensic Exam — Phase Alpha',
      focus: 'Identify drift vectors: over-frequency, over-risk, narrative addiction, revenge cycles.',
      tags: ['forensics', 'rehab'],
    }),
    mod({
      id: 'INF-B',
      docId: 'DOC-SOV',
      order: 2,
      phase: 'Protocol B',
      title: 'Rehabilitation Doctrine — Protocol B',
      focus: 'Stability recovery, permission obedience, and re-entry conditions.',
      tags: ['protocol-b', 'rehab'],
    }),
  ],
  gauntlet: [
    mod({
      id: 'GNT-C',
      docId: 'DOC-CONST',
      order: 1,
      phase: 'Phase Charlie',
      title: 'Phase Charlie — The Sovereign Actuator',
      focus: 'Execution responsibility, audit discipline, and environment-to-action translation.',
      tags: ['sovereignty', 'actuator'],
    }),
    mod({
      id: 'GNT-AUD',
      docId: 'DOC-MACRO',
      order: 2,
      phase: 'Audit',
      title: 'TriArc Auditing Lifecycle (Applied)',
      focus: 'Applied audit: convert telemetry into correction, promotion, or remediation.',
      tags: ['audit', 'applied'],
    }),
  ],
};
