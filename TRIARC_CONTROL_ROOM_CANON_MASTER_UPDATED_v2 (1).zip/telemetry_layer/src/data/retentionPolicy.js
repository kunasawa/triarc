// TriArc Control Room — External Data Hardening
// Layer 3: Retention + immutability primitives

export const RETENTION = {
  // Telemetry is high-volume; keep it bounded.
  DEFAULT_SNAPSHOT_DAYS: 30,
  DEFAULT_OPPORTUNITY_DAYS: 90,

  // Governance logs are institutional record. Prefer indefinite retention.
  GOVERNANCE_INCIDENTS_DAYS: null, // null = indefinite
  ENFORCEMENT_ACTIONS_DAYS: null,

  // Training evidence is part of promotion history.
  TRAINING_SUBMISSIONS_DAYS: 365,
};

export function toMsDays(days) {
  if (days == null) return null;
  return days * 24 * 60 * 60 * 1000;
}

export function cutoffMsFromNow(days) {
  const ms = toMsDays(days);
  if (ms == null) return null;
  return Date.now() - ms;
}

export function isImmutableEntity(entityName) {
  const n = String(entityName || '').toLowerCase();
  return (
    n.includes('incident') ||
    n.includes('enforcement') ||
    n.includes('amendment') ||
    n.includes('audit')
  );
}
