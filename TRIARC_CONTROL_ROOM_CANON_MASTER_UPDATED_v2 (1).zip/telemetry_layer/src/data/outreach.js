import { base44 } from '@/api/base44Client';

/**
 * Outreach Data Layer
 *
 * Public surfaces must work without authentication.
 * This module intentionally uses only create() calls against a single entity.
 */

const tryEntity = (name) => {
  try {
    return base44.entities?.[name];
  } catch {
    return null;
  }
};

/**
 * Canonical entity: AccessRequest
 * Allowed aliases (legacy): PermissionRequest, IntakeRequest
 */
export async function submitAccessRequest(payload) {
  const AccessRequest = tryEntity('AccessRequest')
    || tryEntity('PermissionRequest')
    || tryEntity('IntakeRequest');

  if (!AccessRequest?.create) {
    throw new Error('Access request entity is not available in this environment.');
  }

  // Normalize + harden
  const now = Date.now();
  const clean = {
    created_at_ms: now,
    name: (payload?.name || '').toString().trim(),
    email: (payload?.email || '').toString().trim().toLowerCase(),
    intent: (payload?.intent || '').toString().trim(),
    pathway_hint: (payload?.pathway_hint || '').toString().trim(),
    experience: (payload?.experience || '').toString().trim(),
    notes: (payload?.notes || '').toString().trim(),
    // Optional structured fields (ignored if the entity schema does not include them)
    risk_profile: (payload?.risk_profile || '').toString().trim(),
    assessment_id: (payload?.assessment_id || '').toString().trim(),
    answers_json: payload?.answers_json ?? null,
    status: 'PENDING',
    source: 'CONTROL_ROOM_PUBLIC',
  };

  if (!clean.email) throw new Error('Email is required.');

  return await AccessRequest.create(clean);
}

/**
 * Pathway Assessment (Psychometric Filter)
 * 
 * Canon intent: route to a pathway recommendation and optionally request permission.
 */
export async function submitPathwayAssessment(payload) {
  const assessment_id = `TA-${Date.now()}`;
  return await submitAccessRequest({
    ...payload,
    intent: payload?.intent || 'PATHWAY_ASSESSMENT',
    assessment_id,
  });
}
