import { base44 } from '@/api/base44Client';
import { getTrainingTelemetryContext } from '@/data/telemetryContext';

/**
 * Training Audit Binding Layer (v1)
 *
 * Canon intent:
 * - Convert local training activity into governed, auditable records when entities exist.
 * - Preserve operability in environments where entities are not yet provisioned.
 */

const tryEntity = (name) => {
  try {
    return base44.entities?.[name] ?? null;
  } catch {
    return null;
  }
};

const pickEntity = (names) => {
  for (const n of names) {
    const e = tryEntity(n);
    if (e) return e;
  }
  return null;
};

const localKeySubmissions = (email) => `triarc_training_submissions:${(email || 'anon').toLowerCase()}`;
const localKeyProgress = (email, pathway) => `triarc_progress::${(email || 'anon').toLowerCase()}::${pathway}`;

export function listLocalTrainingSubmissions(email) {
  try {
    const raw = localStorage.getItem(localKeySubmissions(email));
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function writeLocalSubmission(email, payload) {
  const key = localKeySubmissions(email);
  const list = listLocalTrainingSubmissions(email);
  list.unshift(payload);
  localStorage.setItem(key, JSON.stringify(list.slice(0, 100)));
  return { stored: 'local', id: null };
}

function writeLocalProgress(email, pathway, moduleId, complete) {
  const key = localKeyProgress(email, pathway);
  let cur = {};
  try {
    cur = JSON.parse(localStorage.getItem(key) || '{}') || {};
  } catch {
    cur = {};
  }
  const next = { ...cur, [moduleId]: !!complete };
  localStorage.setItem(key, JSON.stringify(next));
  return next;
}

// ------------------------------------------------------------
// Checkpoint / Reflection Submissions
// ------------------------------------------------------------

export async function submitTrainingCheckpoint({
  operator_email,
  pathway,
  module_id,
  doc_id = null,
  text = '',
  module_title = null,
  status = 'SUBMITTED',
  uplink_key = null,
} = {}) {
  const time_ms = Date.now();

  // Best-effort: bind live Nexus governance context to the training checkpoint.
  // This makes training auditable against environment + permission without blocking the operator.
  const telemetry_context = uplink_key
    ? await getTrainingTelemetryContext({ uplink_key }).catch(() => null)
    : null;

  const payload = {
    timestamp_ms: time_ms,
    operator_email,
    pathway,
    module_id,
    module_title,
    doc_id,
    text,
    status,
    uplink_key: uplink_key || null,
    telemetry_context,
    // Canon: preserve integrity by capturing environment metadata if needed later.
    source: 'CONTROL_ROOM',
  };

  const Ent = pickEntity([
    'TrainingSubmission',
    'TrainingCheckpoint',
    'TrainingReflection',
    'TrainingSubmissionLog',
  ]);

  if (!Ent?.create) {
    return writeLocalSubmission(operator_email, payload);
  }

  try {
    const row = await Ent.create(payload);
    return { stored: 'remote', id: row?.id ?? null, row };
  } catch {
    // Safety fallback: never block operator flow.
    return writeLocalSubmission(operator_email, payload);
  }
}

// ------------------------------------------------------------
// Progress Recording (completion state)
// ------------------------------------------------------------

export async function recordTrainingProgress({
  operator_email,
  pathway,
  module_id,
  complete,
} = {}) {
  // Always update local first so UI stays deterministic.
  const local = writeLocalProgress(operator_email, pathway, module_id, complete);

  const Ent = pickEntity([
    'TrainingProgress',
    'TrainingStatus',
    'ModuleProgress',
    'LearningProgress',
  ]);

  if (!Ent?.create && !Ent?.update && !Ent?.filter) {
    return { stored: 'local', local };
  }

  // Canonical model: one row per (operator_email, pathway, module_id)
  // If the environment supports filter+update, we upsert.
  try {
    if (Ent?.filter && Ent?.update) {
      const rows = await Ent.filter({ operator_email, pathway, module_id }, '-created_date', 1).catch(() => []);
      const existing = rows?.[0] ?? null;
      if (existing?.id) {
        const row = await Ent.update(existing.id, {
          complete: !!complete,
          updated_at: new Date().toISOString(),
        });
        return { stored: 'remote', id: row?.id ?? existing.id, row, local };
      }
    }

    if (Ent?.create) {
      const row = await Ent.create({
        operator_email,
        pathway,
        module_id,
        complete: !!complete,
        updated_at: new Date().toISOString(),
      });
      return { stored: 'remote', id: row?.id ?? null, row, local };
    }
  } catch {
    // Ignore remote failure; local is authoritative until audit surface is provisioned.
  }

  return { stored: 'local', local };
}

// ------------------------------------------------------------
// Governance read helpers (optional, best-effort)
// ------------------------------------------------------------

export async function listTrainingSubmissions({ operator_email, limit = 50 } = {}) {
  const Ent = pickEntity([
    'TrainingSubmission',
    'TrainingCheckpoint',
    'TrainingReflection',
    'TrainingSubmissionLog',
  ]);

  if (Ent?.filter && operator_email) {
    try {
      return await Ent.filter({ operator_email }, '-timestamp_ms', limit);
    } catch {
      return [];
    }
  }

  // Fallback: local only (caller can decide whether to show)
  return [];
}
