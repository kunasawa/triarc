/**
 * TriArc Sovereign Control Room — Data Contracts (Frontend)
 *
 * Goal:
 * - One canonical vocabulary for UI → data mapping.
 * - Keep pages/components insulated from backend entity naming drift.
 */

// ------------------------------------------------------------
// 1) Telemetry event names (must match Nexus alert envelopes)
// ------------------------------------------------------------
export const TELEMETRY_EVENTS = {
  STATE_SNAPSHOT: 'STATE_SNAPSHOT',
  OPPORTUNITY_CREATED: 'OPPORTUNITY_CREATED',
  OPPORTUNITY_UPDATED: 'OPPORTUNITY_UPDATED',
  OPPORTUNITY_CLEARED: 'OPPORTUNITY_CLEARED'
};

// ------------------------------------------------------------
// 2) Canonical telemetry schema (Nexus v2.x envelope)
// ------------------------------------------------------------
// Pine emits:
// {
//   event_type: string,
//   uplink_key: string,
//   payload: {
//     meta: {...},
//     governance: {...},
//     servo: {...},
//     opportunity: {...}
//   }
// }
// The UI should treat everything except `payload` as transport.

export const NEXUS_SCHEMA = {
  meta: {
    schema_version: 'string',
    script_version: 'string',
    event_time_ms: 'number',
    bar_index: 'number',
    tf: 'string',
    tf_sec: 'number',
    is_exec_tf: 'boolean',
    symbol: 'string',
    symbol_id: 'string',
    tick_size: 'number'
  },
  governance: {
    gov_state: 'string',
    is_permitted: 'boolean',
    toi_active: 'boolean',
    sentinel_state: 'number',
    global_void: 'boolean',
    probe_only: 'boolean',
    manual_lock: 'boolean',
    event_lock: 'boolean',
    denial_reason: 'string',
    wk_type: 'string',
    wk_confidence: 'number',
    matrix_healthy: 'boolean',
    navigator_bias: 'string'
  },
  servo: {
    servo_decision: 'string',
    servo_reason: 'string',
    risk_multiplier: 'number',
    env_cap: 'number'
  },
  opportunity: {
    active: 'boolean',
    opportunity_id: 'string',
    side: 'string',
    name: 'string',
    bar_idx: 'number',
    score: 'number',
    entry: 'number',
    stop: 'number',
    risk_to_stop: 'number',
    tp1: 'number',
    tp2: 'number',
    tp3: 'number',
    rotation_mode: 'boolean',
    hammer: 'boolean',
    matrix_ok: 'boolean'
  }
};

// ------------------------------------------------------------
// 3) Canonical Control Room models (frontend normalized)
// ------------------------------------------------------------

export const MODEL_KEYS = {
  MEMBER_RECORD: 'MEMBER_RECORD',
  UPLINK_KEY_REGISTRY: 'UPLINK_KEY_REGISTRY',
  IDENTITY: 'IDENTITY', // legacy alias (use MEMBER_RECORD)
  WEEKLY_ARTIFACT: 'WEEKLY_ARTIFACT',
  WEEKLY_ARCHIVE: 'WEEKLY_ARCHIVE',
  WEEKLY_BY_WEEK: 'WEEKLY_BY_WEEK',
  NEXUS_LIVE: 'NEXUS_LIVE',
  OPPORTUNITY_LEDGER: 'OPPORTUNITY_LEDGER',
  NEXUS_EVENTS: 'NEXUS_EVENTS',
  NEXUS_FLEET: 'NEXUS_FLEET',

  // Compliance & Remediation (Governance Layer)
  COMPLIANCE_SUMMARY: 'COMPLIANCE_SUMMARY',
  COMPLIANCE_EVENTS: 'COMPLIANCE_EVENTS',
  REMEDIATION_CASES: 'REMEDIATION_CASES',

  // Incidents & Enforcement (Governance Layer)
  INCIDENTS: 'INCIDENTS',
  ENFORCEMENT_ACTIONS: 'ENFORCEMENT_ACTIONS'
};

export const DEFAULTS = {
  instrument: {
    symbol: 'ES',
    symbol_id: 'CME_MINI:ES1!',
    tf: '5'
  }
};
