import { base44 } from '@/api/base44Client';

// Stripe Price IDs (Canon)
export const PRICE_IDS = {
  ACADEMY: 'price_1StpvJCnl3FbLIYRZynjlZYM',
  INFIRMARY: 'price_1Stpe3Cnl3FbLIYRS2OZmqk8',
  GAUNTLET: 'price_1T0fafCnl3FbLIYRgQSeOd1t',
};

export async function createCheckoutSession({ price_id, return_path = '/portal' } = {}) {
  if (!price_id) throw new Error('Missing price_id');
  const res = await base44.functions.invoke('createCheckoutSession', { price_id, return_path });
  return res?.data ?? res;
}

export async function syncBillingAuthority() {
  const res = await base44.functions.invoke('syncStripeProfile', {});
  return res?.data ?? res;
}


export async function createBillingPortalSession({ return_path = '/portal/billing' } = {}) {
  const res = await base44.functions.invoke('createBillingPortalSession', { return_path });
  return res?.data ?? res;
}
