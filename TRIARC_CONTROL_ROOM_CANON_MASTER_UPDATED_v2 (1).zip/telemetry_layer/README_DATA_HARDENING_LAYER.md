# TriArc Control Room — Layer 3: External Data Hardening

This layer adds institutional-scale hardening primitives:

1) **Retention policy** for inbound telemetry (STATE_SNAPSHOT / opportunity events).
2) **Immutability markers** for incidents/enforcement logs (append-only semantics).
3) **Audit export** (JSON bundle) for a selected time window + uplink(s).
4) **Manifest version lock** (file hash manifest) for each governance upgrade.

## What’s included

- `src/data/retentionPolicy.js`
  - Central policy constants (default windows) and helper functions.

- `src/data/auditExport.js`
  - Exports a JSON bundle for:
    - Nexus snapshots
    - Compliance events
    - Incidents
    - Remediation cases
    - Training submissions
  - Uses **best-effort entity resolution** (supports likely Base44 entity naming variants).

- `src/pages/governance_data_hardening.jsx`
  - Governance UI to:
    - set retention windows (client-side config stub)
    - run an export for an uplink + date window
    - download the JSON bundle

- `scripts/generate_manifest.py`
  - Generates `MANIFEST.json` containing file SHA256 + count.

## Integration Notes

### A) Retention policy (server-side)
Apply retention in your ingest pipeline / scheduled job:
- purge snapshots older than `RETENTION.DEFAULT_SNAPSHOT_DAYS`
- keep incidents and enforcement logs indefinitely

### B) Immutability
For `GovernanceIncident` + `EnforcementAction` entities:
- treat as append-only
- no edits (or record edits as new events)

### C) Export
Export is intentionally **governance-only**.

### D) Manifest
Run `python scripts/generate_manifest.py` in the repository root at each release.

