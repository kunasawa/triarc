// Supabase Edge Function: nexus_ingest
// Receives TradingView alert envelopes emitted by TriArc Nexus and writes:
//  - public.nexus_events (raw)
//  - public.state_snapshots (flattened) when event_type === STATE_SNAPSHOT
//
// IMPORTANT:
//  - TradingView cannot attach a Supabase auth token.
//  - user_id is resolved by looking up uplink_key in public.uplink_keys.
//  - Binding uplink_key -> user_id is handled by the companion function: bind_uplink_key.

import { serve } from 'https://deno.land/std@0.224.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4'

type AnyObj = Record<string, any>

const json = (data: any, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'access-control-allow-origin': '*',
      'access-control-allow-headers': 'authorization, x-client-info, apikey, content-type',
    },
  })

const keyPathFrom = (uplinkKey: string) => {
  // Expected format: PREFIX-PATH-XXXX... (ex: TA-PRM-...)
  const parts = (uplinkKey || '').split('-').map((s) => s.trim()).filter(Boolean)
  return (parts[1] || 'INVALID').toUpperCase()
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return json({ ok: true }, 200)

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')
    const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
      return json({ ok: false, error: 'Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY' }, 500)
    }

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY)
    const body = (await req.json().catch(() => ({}))) as AnyObj

    const event_type = String(body.event_type ?? '').trim()
    const uplink_key = String(body.uplink_key ?? '').trim()
    const payload = (body.payload ?? null) as AnyObj | null

    if (!event_type || !uplink_key || !payload) {
      return json({ ok: false, error: 'Missing required fields: event_type, uplink_key, payload' }, 400)
    }

    const meta = (payload.meta ?? {}) as AnyObj
    const gov = (payload.governance ?? {}) as AnyObj
    const servo = (payload.servo ?? {}) as AnyObj
    const opp = (payload.opportunity ?? {}) as AnyObj

    const symbol = meta.symbol ?? null
    const tf = meta.tf ?? null
    const is_exec_tf = meta.is_exec_tf ?? null

    // Resolve user_id via uplink key (if pre-bound in app)
    let user_id: string | null = null
    {
      const { data, error } = await admin
        .from('uplink_keys')
        .select('user_id')
        .eq('uplink_key', uplink_key)
        .eq('is_active', true)
        .maybeSingle()

      if (!error && data?.user_id) user_id = data.user_id
    }

    // 1) Store raw envelope (always)
    await admin.from('nexus_events').insert({
      event_type,
      uplink_key,
      symbol,
      tf,
      is_exec_tf,
      payload,
    })

    // 2) Store flattened state snapshot
    if (event_type === 'STATE_SNAPSHOT') {
      await admin.from('state_snapshots').insert({
        user_id,
        uplink_key,
        event_time_ms: meta.event_time_ms ?? null,
        bar_index: meta.bar_index ?? null,
        symbol: meta.symbol ?? null,
        symbol_id: meta.symbol_id ?? null,
        tf: meta.tf ?? null,
        tf_sec: meta.tf_sec ?? null,
        is_exec_tf: meta.is_exec_tf ?? null,

        gov_state: gov.gov_state ?? null,
        is_permitted: gov.is_permitted ?? null,
        toi_active: gov.toi_active ?? null,
        sentinel_state: gov.sentinel_state ?? null,
        global_void: gov.global_void ?? null,
        probe_only: gov.probe_only ?? null,
        manual_lock: gov.manual_lock ?? null,
        event_lock: gov.event_lock ?? null,
        denial_reason: gov.denial_reason ?? null,

        wk_type: gov.wk_type ?? null,
        wk_confidence: gov.wk_confidence ?? null,
        matrix_healthy: gov.matrix_healthy ?? null,
        navigator_bias: gov.navigator_bias ?? null,

        servo_decision: servo.servo_decision ?? null,
        servo_reason: servo.servo_reason ?? null,
        risk_multiplier: servo.risk_multiplier ?? null,
        env_cap: servo.env_cap ?? null,

        opportunity_id: opp.opportunity_id ?? null,
        opp_active: opp.active ?? null,
        opp_side: opp.side ?? null,
        opp_name: opp.name ?? null,
        opp_score: opp.score ?? null,
        opp_entry: opp.entry ?? null,
        opp_stop: opp.stop ?? null,
        opp_tp1: opp.tp1 ?? null,
        opp_tp2: opp.tp2 ?? null,
        opp_tp3: opp.tp3 ?? null,
        opp_rotation_mode: opp.rotation_mode ?? null,
        opp_hammer: opp.hammer ?? null,
        opp_matrix_ok: opp.matrix_ok ?? null,

        raw: payload,
      })
    }

    return json({ ok: true, resolved_user: !!user_id, key_path: keyPathFrom(uplink_key) }, 200)
  } catch (e) {
    return json({ ok: false, error: (e as Error)?.message ?? 'Unknown error' }, 500)
  }
})
