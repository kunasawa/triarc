// Supabase Edge Function: bind_uplink_key
// Authenticated call from the Control Room portal to bind an uplink_key to the current user.
// This enables latency-free user resolution during TradingView webhook ingestion.

import { serve } from 'https://deno.land/std@0.224.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4'

type AnyObj = Record<string, any>

const json = (data: any, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'access-control-allow-origin': '*',
      'access-control-allow-headers': 'authorization, x-client-info, apikey, content-type',
    },
  })

const keyPathFrom = (uplinkKey: string) => {
  const parts = (uplinkKey || '').split('-').map((s) => s.trim()).filter(Boolean)
  return (parts[1] || 'INVALID').toUpperCase()
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return json({ ok: true }, 200)

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')
    const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    const ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY')

    if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !ANON_KEY) {
      return json({ ok: false, error: 'Missing SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY / SUPABASE_ANON_KEY' }, 500)
    }

    const authHeader = req.headers.get('Authorization') || ''
    if (!authHeader) return json({ ok: false, error: 'Missing Authorization header' }, 401)

    // Verify user with anon key + forwarded auth header
    const authed = createClient(SUPABASE_URL, ANON_KEY, { global: { headers: { Authorization: authHeader } } })
    const { data: userRes, error: userErr } = await authed.auth.getUser()
    if (userErr || !userRes?.user) return json({ ok: false, error: 'Invalid token' }, 401)
    const user_id = userRes.user.id

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY)
    const body = (await req.json().catch(() => ({}))) as AnyObj

    const uplink_key = String(body.uplink_key ?? '').trim()
    if (!uplink_key) return json({ ok: false, error: 'Missing uplink_key' }, 400)

    const key_path = keyPathFrom(uplink_key)
    if (key_path === 'INVALID') return json({ ok: false, error: 'Invalid uplink_key format' }, 400)

    // If key exists and belongs to another user, refuse.
    const { data: existing, error: exErr } = await admin
      .from('uplink_keys')
      .select('user_id, is_active')
      .eq('uplink_key', uplink_key)
      .maybeSingle()

    if (!exErr && existing?.user_id && existing.user_id !== user_id) {
      return json({ ok: false, error: 'uplink_key is already bound to another operator' }, 409)
    }

    // Upsert (safe if same user)
    const { error } = await admin
      .from('uplink_keys')
      .upsert(
        {
          uplink_key,
          user_id,
          key_path,
          is_active: true,
        },
        { onConflict: 'uplink_key' }
      )

    if (error) return json({ ok: false, error: error.message }, 500)

    return json({ ok: true, uplink_key, key_path }, 200)
  } catch (e) {
    return json({ ok: false, error: (e as Error)?.message ?? 'Unknown error' }, 500)
  }
})
