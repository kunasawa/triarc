-- Authority Compression Engine (v1)
-- Converts telemetry + OSI into dynamic pathway + load authority.

create or replace function public.triarc_compute_band(osi int)
returns text language plpgsql as $$
begin
  if osi is null then return 'UNASSESSED'; end if;
  if osi >= 90 then return 'SOVEREIGN';
  elsif osi >= 80 then return 'STABLE';
  elsif osi >= 70 then return 'RECOVERING';
  elsif osi >= 60 then return 'FRAGILE';
  else return 'UNSTABLE';
  end if;
end; $$;

create or replace function public.triarc_compute_pathway(access_tier triarc_tier, osi int)
returns triarc_pathway language plpgsql as $$
begin
  -- Access tier is the ceiling. OSI determines current authority state.
  if access_tier = 'ACADEMY' then
    return 'ACADEMY';
  elsif access_tier = 'INFIRMARY' then
    -- Infirmary access: may compress to Academy authority when unstable.
    if osi >= 60 then return 'INFIRMARY'; else return 'ACADEMY'; end if;
  elsif access_tier = 'GAUNTLET' then
    -- Gauntlet access: compress to Infirmary when OSI degrades; to Academy when unstable.
    if osi >= 80 then return 'GAUNTLET';
    elsif osi >= 60 then return 'INFIRMARY';
    else return 'ACADEMY';
    end if;
  else
    -- Staff roles treated as GAUNTLET authority by default
    return 'GAUNTLET';
  end if;
end; $$;

create or replace function public.triarc_compute_load(pathway triarc_pathway, osi int, gov_state triarc_exec_state)
returns numeric language plpgsql as $$
begin
  -- Governance state overrides (CRITICAL/RESTRICTED): hard clamp.
  if gov_state in ('CRITICAL') then
    return 0.50;
  end if;

  if pathway = 'ACADEMY' then
    return 0.50;
  elsif pathway = 'INFIRMARY' then
    return case when osi >= 70 then 1.00 else 0.50 end;
  else -- GAUNTLET
    return case when osi >= 85 then 2.00 else 1.00 end;
  end if;
end; $$;

create or replace function public.triarc_apply_authority_compression(
  p_user_id uuid,
  p_gov_state triarc_exec_state,
  p_osi int,
  p_reason text,
  p_evidence jsonb default '{}'::jsonb
) returns void language plpgsql as $$
declare
  v_profile public.operator_profiles%rowtype;
  v_next_path triarc_pathway;
  v_next_load numeric(3,2);
  v_next_band text;
  v_prev_path triarc_pathway;
  v_prev_load numeric(3,2);
  v_prev_osi int;
  v_access triarc_tier;
begin
  select * into v_profile from public.operator_profiles where user_id = p_user_id;
  if not found then
    -- If profile missing, create with conservative defaults
    insert into public.operator_profiles(user_id, access_tier, active_pathway, osi_score, load_authority, current_state)
    values (p_user_id, 'ACADEMY', 'ACADEMY', coalesce(p_osi,0), 0.50, coalesce(p_gov_state,'REFERENCE'))
    returning * into v_profile;
  end if;

  v_access := v_profile.access_tier;
  v_prev_path := v_profile.active_pathway;
  v_prev_load := v_profile.load_authority;
  v_prev_osi := v_profile.osi_score;

  v_next_band := public.triarc_compute_band(coalesce(p_osi, v_profile.osi_score));
  v_next_path := public.triarc_compute_pathway(v_access, coalesce(p_osi, v_profile.osi_score));
  v_next_load := public.triarc_compute_load(v_next_path, coalesce(p_osi, v_profile.osi_score), coalesce(p_gov_state, v_profile.current_state));

  update public.operator_profiles
     set osi_score = coalesce(p_osi, osi_score),
         osi_band = v_next_band,
         active_pathway = v_next_path,
         load_authority = v_next_load,
         current_state = coalesce(p_gov_state, current_state)
   where user_id = p_user_id;

  if (v_prev_path is distinct from v_next_path)
     or (v_prev_load is distinct from v_next_load)
     or (v_prev_osi is distinct from coalesce(p_osi, v_prev_osi)) then

    insert into public.authority_events(
      user_id,
      prev_pathway, next_pathway,
      prev_load, next_load,
      prev_osi, next_osi,
      reason, evidence
    ) values (
      p_user_id,
      v_prev_path, v_next_path,
      v_prev_load, v_next_load,
      v_prev_osi, coalesce(p_osi, v_prev_osi),
      p_reason,
      p_evidence
    );
  end if;
end; $$;

-- Trigger: when new snapshot arrives for a known user, update pathway/load.
-- NOTE: user_id mapping from uplink_key is implementation-specific.
-- In MVP you may pass user_id directly in the ingest function.

create or replace function public.triarc_on_snapshot_insert()
returns trigger language plpgsql as $$
begin
  if new.user_id is not null then
    perform public.triarc_apply_authority_compression(
      new.user_id,
      coalesce(new.gov_state, 'REFERENCE'),
      null, -- OSI updates typically come from audit layer; keep as-is here
      'TELEMETRY_SNAPSHOT',
      jsonb_build_object(
        'symbol', new.symbol,
        'tf', new.tf,
        'is_permitted', new.is_permitted,
        'denial_reason', new.denial_reason,
        'sentinel_state', new.sentinel_state,
        'servo_decision', new.servo_decision
      )
    );
  end if;
  return new;
end; $$;

do $$ begin
  create trigger trg_state_snapshots_authority
  after insert on public.state_snapshots
  for each row execute function public.triarc_on_snapshot_insert();
exception when duplicate_object then null; end $$;
