-- TRIARC CONTROL ROOM (Telemetry Spine)
-- Backend Schema v1.0
-- Purpose: Persist Nexus telemetry, authority compression state, and training/audit signals.

-- Recommended extensions
create extension if not exists pgcrypto;
create extension if not exists "uuid-ossp";

-- =====================================================================
-- 0. ENUMS
-- =====================================================================

do $$ begin
  create type triarc_tier as enum ('ACADEMY','INFIRMARY','GAUNTLET','ADMIN','ARCHITECT','CONTROLLER');
exception when duplicate_object then null; end $$;

do $$ begin
  create type triarc_pathway as enum ('ACADEMY','INFIRMARY','GAUNTLET');
exception when duplicate_object then null; end $$;

do $$ begin
  create type triarc_exec_state as enum ('REFERENCE','ALIGNED','RESTRICTED','CAUTION','CRITICAL');
exception when duplicate_object then null; end $$;

do $$ begin
  create type triarc_servo_decision as enum ('PASS','WARN','BLOCK');
exception when duplicate_object then null; end $$;

-- =====================================================================
-- 1. CORE IDENTITY
-- =====================================================================

-- If you use Supabase Auth, "auth.users" exists already.
-- This table stores TriArc-specific operator profile state.
create table if not exists public.operator_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- Commercial access (Stripe/Memberstack) does NOT equal authority.
  access_tier triarc_tier not null default 'ACADEMY',

  -- Dynamic pathway assignment (state) may differ from access_tier.
  active_pathway triarc_pathway not null default 'ACADEMY',

  -- Operator Stability Index (0-100). Used for authority compression.
  osi_score int not null default 0 check (osi_score between 0 and 100),
  osi_band text not null default 'UNASSESSED',

  -- Authority load cap (0.5x / 1.0x / 2.0x)
  load_authority numeric(3,2) not null default 0.50 check (load_authority in (0.50, 1.00, 2.00)),

  -- Current governance posture (for dashboard state)
  current_state triarc_exec_state not null default 'REFERENCE',

  -- Optional: mentorship assignment
  mentor_user_id uuid null references auth.users(id),

  -- Notes for controllers
  controller_notes text
);

create index if not exists idx_operator_profiles_access_tier on public.operator_profiles(access_tier);
create index if not exists idx_operator_profiles_active_pathway on public.operator_profiles(active_pathway);

-- Updated timestamp trigger
create or replace function public.triarc_touch_updated_at() returns trigger as $$
begin
  new.updated_at = now();
  return new;
end; $$ language plpgsql;

do $$ begin
  create trigger trg_operator_profiles_touch
  before update on public.operator_profiles
  for each row execute function public.triarc_touch_updated_at();
exception when duplicate_object then null; end $$;

-- =====================================================================
-- 2. UPLINK KEYS (Audit)
-- =====================================================================

create table if not exists public.uplink_keys (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),

  -- Human owner
  user_id uuid not null references auth.users(id) on delete cascade,

  -- Key string (store hash if desired). In MVP we store plain for audit.
  uplink_key text not null unique,

  -- Key path code (PRM/GST/ACAD etc.)
  key_path text not null,

  -- Status
  is_active boolean not null default true,
  revoked_at timestamptz,
  revoked_reason text
);

create index if not exists idx_uplink_keys_user on public.uplink_keys(user_id);
create index if not exists idx_uplink_keys_active on public.uplink_keys(is_active);

-- =====================================================================
-- 3. RAW TELEMETRY EVENTS (Envelope)
-- =====================================================================

create table if not exists public.nexus_events (
  id bigserial primary key,
  received_at timestamptz not null default now(),

  event_type text not null,
  uplink_key text,

  -- Metadata extracted (fast filters)
  symbol text,
  tf text,
  is_exec_tf boolean,

  -- Full payload for replay / debugging
  payload jsonb not null
);

create index if not exists idx_nexus_events_received_at on public.nexus_events(received_at desc);
create index if not exists idx_nexus_events_type on public.nexus_events(event_type);
create index if not exists idx_nexus_events_symbol on public.nexus_events(symbol);
create index if not exists idx_nexus_events_uplink on public.nexus_events(uplink_key);

-- =====================================================================
-- 4. STATE SNAPSHOTS (Flattened) — primary dashboard feed
-- =====================================================================

create table if not exists public.state_snapshots (
  id bigserial primary key,
  received_at timestamptz not null default now(),

  user_id uuid null references auth.users(id) on delete set null,
  uplink_key text,

  event_time_ms bigint,
  bar_index int,
  symbol text,
  symbol_id text,
  tf text,
  tf_sec int,
  is_exec_tf boolean,

  gov_state triarc_exec_state,
  is_permitted boolean,
  toi_active boolean,
  sentinel_state int,
  global_void boolean,
  probe_only boolean,
  manual_lock boolean,
  event_lock boolean,
  denial_reason text,

  wk_type text,
  wk_confidence int,
  matrix_healthy boolean,
  navigator_bias text,

  servo_decision triarc_servo_decision,
  servo_reason text,
  risk_multiplier numeric(4,2),
  env_cap numeric(4,2),

  opportunity_id text,
  opp_active boolean,
  opp_side text,
  opp_name text,
  opp_score int,
  opp_entry numeric,
  opp_stop numeric,
  opp_tp1 numeric,
  opp_tp2 numeric,
  opp_tp3 numeric,
  opp_rotation_mode boolean,
  opp_hammer boolean,
  opp_matrix_ok boolean,

  raw jsonb not null
);

create index if not exists idx_state_snapshots_received_at on public.state_snapshots(received_at desc);
create index if not exists idx_state_snapshots_user on public.state_snapshots(user_id);
create index if not exists idx_state_snapshots_symbol on public.state_snapshots(symbol);
create index if not exists idx_state_snapshots_uplink on public.state_snapshots(uplink_key);

-- =====================================================================
-- 5. AUTHORITY COMPRESSION LOG (Audit trail)
-- =====================================================================

create table if not exists public.authority_events (
  id bigserial primary key,
  created_at timestamptz not null default now(),

  user_id uuid not null references auth.users(id) on delete cascade,

  -- Previous → Next
  prev_pathway triarc_pathway,
  next_pathway triarc_pathway,
  prev_load numeric(3,2),
  next_load numeric(3,2),
  prev_osi int,
  next_osi int,

  reason text not null,
  evidence jsonb
);

create index if not exists idx_authority_events_user on public.authority_events(user_id);
create index if not exists idx_authority_events_created_at on public.authority_events(created_at desc);

-- =====================================================================
-- 6. TRAINING / AUDIT SIGNALS
-- =====================================================================

create table if not exists public.training_audit_events (
  id bigserial primary key,
  created_at timestamptz not null default now(),
  user_id uuid not null references auth.users(id) on delete cascade,

  domain text not null,            -- e.g., 'CLASSIFIER', 'NEXUS_DISCIPLINE', 'PLAYBOOK'
  metric text not null,            -- e.g., 'accuracy', 'rule_violations'
  value numeric not null,
  band text,
  evidence jsonb
);

create index if not exists idx_training_audit_user on public.training_audit_events(user_id);
create index if not exists idx_training_audit_domain on public.training_audit_events(domain);

-- =====================================================================
-- 7. BASIC RLS SKELETON (Adjust per deployment)
-- =====================================================================

alter table public.operator_profiles enable row level security;
alter table public.uplink_keys enable row level security;
alter table public.nexus_events enable row level security;
alter table public.state_snapshots enable row level security;
alter table public.authority_events enable row level security;
alter table public.training_audit_events enable row level security;

-- Operators can read/update their own profile
create policy if not exists "profiles_select_own" on public.operator_profiles
  for select using (auth.uid() = user_id);
create policy if not exists "profiles_update_own" on public.operator_profiles
  for update using (auth.uid() = user_id);

-- Controllers/Admins: implement via JWT claims or a separate role mapping.
-- Placeholder: allow service role (server-side) full access.
