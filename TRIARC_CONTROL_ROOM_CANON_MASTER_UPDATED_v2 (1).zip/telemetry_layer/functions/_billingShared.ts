import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import Stripe from 'npm:stripe@16.12.0';

export const PRICE_IDS = {
  ACADEMY: 'price_1StpvJCnl3FbLIYRZynjlZYM',
  INFIRMARY: 'price_1Stpe3Cnl3FbLIYRS2OZmqk8',
  GAUNTLET: 'price_1T0fafCnl3FbLIYRgQSeOd1t',
} as const;

export const tierFromPriceId = (priceId: string) => {
  if (priceId === PRICE_IDS.ACADEMY) return 'ACADEMY';
  if (priceId === PRICE_IDS.INFIRMARY) return 'INFIRMARY';
  if (priceId === PRICE_IDS.GAUNTLET) return 'GAUNTLET';
  return 'UNDECLARED';
};

export const stripeClient = () => {
  const key = Deno.env.get('STRIPE_SECRET_KEY');
  if (!key) throw new Error('Missing STRIPE_SECRET_KEY');
  return new Stripe(key, { apiVersion: '2024-06-20' });
};

export const resolveIdentityEntity = (base44: any) => {
  // Canonical-first, then legacy fallbacks
  const ents = base44?.asServiceRole?.entities ?? {};
  return (
    ents.MemberRecord ||
    ents.MemberIdentity ||
    ents.Profile ||
    ents.MemberProfile ||
    null
  );
};

export const getMemberByEmail = async (base44: any, email: string) => {
  const Ent = resolveIdentityEntity(base44);
  if (!Ent?.filter) throw new Error('Identity entity not available');
  const rows = await Ent.filter({ email }, '-created_date', 1).catch(() => []);
  return { Ent, rec: rows?.[0] ?? null };
};

export const patchMember = async (Ent: any, id: string, patch: Record<string, unknown>) => {
  if (!Ent?.update) throw new Error('Identity entity not updatable');
  return await Ent.update(id, patch);
};

export const nowIso = () => new Date().toISOString();

export const nowMs = () => Date.now();

export const parseIsoMs = (iso: any): number | null => {
  try {
    if (!iso) return null;
    const t = new Date(String(iso)).getTime();
    return Number.isFinite(t) ? t : null;
  } catch {
    return null;
  }
};

export const graceDays = () => Number(Deno.env.get('TRIARC_BILLING_GRACE_DAYS') || '3');

/**
 * Canon enforcement:
 * - Execution locks immediately when billing is not ACTIVE (including GRACE).
 * - Content (Classifier + Playbooks) can remain accessible during GRACE until grace_until.
 */
export const computeEntitlementState = (billingStatus: string, graceUntilIso: any) => {
  const status = (billingStatus || 'NONE').toUpperCase();
  const now = nowMs();
  const graceUntil = parseIsoMs(graceUntilIso);
  const inGrace = status === 'GRACE' && graceUntil !== null && graceUntil > now;

  const contentEntitled = (status === 'ACTIVE') || inGrace;
  const executionEntitled = (status === 'ACTIVE'); // immediate lock on GRACE/SUSPENDED/CANCELED

  return { inGrace, contentEntitled, executionEntitled, graceUntil };
};

export const nextGraceUntilIso = () => new Date(Date.now() + graceDays() * 24 * 60 * 60 * 1000).toISOString();


export const toBillingStatus = (sub: Stripe.Subscription | null) => {
  if (!sub) return 'NONE';
  // Stripe status: active, trialing, past_due, unpaid, canceled, incomplete, incomplete_expired
  // Canon buckets:
  // - ACTIVE: active or trialing
  // - GRACE: past_due (within grace)
  // - SUSPENDED: unpaid/incomplete
  // - CANCELED: canceled
  const s = sub.status;
  if (s === 'active' || s === 'trialing') return 'ACTIVE';
  if (s === 'past_due') return 'GRACE';
  if (s === 'canceled') return 'CANCELED';
  if (s === 'unpaid' || s === 'incomplete' || s === 'incomplete_expired') return 'SUSPENDED';
  return 'UNKNOWN';
};

export const entitlementsFromTier = (tier: string) => {
  // Canon entitlement map: playbooks
  // Academy: MES
  // Infirmary: MES/ES, MNQ/NQ
  // Gauntlet: all playbooks
  const T = (tier || '').toUpperCase();
  if (T === 'ACADEMY') return { playbooks: ['MES'], suite: ['WEEKLY_CLASSIFIER', 'NEXUS_LITE'] };
  if (T === 'INFIRMARY') return { playbooks: ['MES', 'ES', 'MNQ', 'NQ'], suite: ['WEEKLY_CLASSIFIER', 'NEXUS_GHOST'] };
  if (T === 'GAUNTLET') return { playbooks: ['ALL'], suite: ['WEEKLY_CLASSIFIER', 'NEXUS_PRIME'] };
  return { playbooks: [], suite: ['WEEKLY_CLASSIFIER'] };
};

export const createBase44 = (req: Request) => createClientFromRequest(req);
