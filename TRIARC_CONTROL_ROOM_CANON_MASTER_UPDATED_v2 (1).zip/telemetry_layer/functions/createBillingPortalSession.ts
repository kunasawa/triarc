import { createBase44, getMemberByEmail, patchMember, stripeClient, nowIso } from './_billingShared.ts';

// Creates a Stripe Billing Portal session for an authenticated operator.
// Canon: operators can manage payment methods / cancel via Stripe-owned portal.

Deno.serve(async (req) => {
  try {
    const base44 = createBase44(req);
    const user = await base44.auth.me();
    if (!user?.email) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const stripe = stripeClient();
    const { Ent, rec } = await getMemberByEmail(base44, user.email);
    if (!rec?.id) return Response.json({ error: 'Member record not found' }, { status: 404 });

    const { return_path } = await req.json().catch(() => ({}));

    let customerId = rec?.stripe_customer_id || rec?.stripeCustomerId || null;
    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        name: user.name ?? undefined,
        metadata: { operator_email: user.email, base44_member_id: rec.id },
      });
      customerId = customer.id;
      await patchMember(Ent, rec.id, { stripe_customer_id: customerId, billing_authority_updated_at: nowIso() });
    }

    const appUrl = Deno.env.get('APP_BASE_URL') || Deno.env.get('APP_URL') || (req.headers.get('origin') ?? '');
    if (!appUrl) return Response.json({ error: 'Missing APP_BASE_URL/APP_URL' }, { status: 500 });

    const returnUrl = `${appUrl}${return_path || '/portal/billing'}`;

    const session = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: returnUrl,
    });

    return Response.json({ url: session.url });
  } catch (error) {
    console.error('createBillingPortalSession error:', error);
    return Response.json({ error: (error as Error).message }, { status: 500 });
  }
});
