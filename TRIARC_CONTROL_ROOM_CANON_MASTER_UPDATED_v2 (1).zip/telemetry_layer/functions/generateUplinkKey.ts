import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { operator_email, path, tier, profile_id, revoke_previous } = await req.json();

    // Validate operator
    if (operator_email !== user.email && user.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    // Revoke previous keys if requested (tier transition)
    if (revoke_previous) {
      const existingActivations = await base44.asServiceRole.entities.NexusActivation.filter({
        operator_email
      });
      
      for (const activation of existingActivations) {
        await base44.asServiceRole.entities.NexusActivation.update(activation.id, {
          status: 'REVOKED',
          revoked_at: new Date().toISOString(),
          revoked_reason: 'Tier transition - key rotation'
        });
      }
    } else {
      // Check if active uplink key already exists
      const existingActivations = await base44.asServiceRole.entities.NexusActivation.filter({
        operator_email,
        status: 'ACTIVE'
      });

      if (existingActivations.length > 0) {
        return Response.json({
          uplink_key: existingActivations[0].uplink_key,
          already_exists: true
        });
      }
    }

    // Generate dynamic uplink key: [TIER]-[PATH]-[ID]-[HASH]
    const tierMap = {
      'TIER_0_AIRLOCK': 'T0',
      'TIER_1_CADET': 'T1',
      'TIER_2_REHAB': 'T2',
      'TIER_3_OPERATOR': 'T3',
      'TIER_4_PRIME': 'T4'
    };

    // Path mapping for Nexus RBAC (CRITICAL: Gauntlet → Prime, Infirmary → Ghost)
    const pathMap = {
      'THE_ACADEMY': 'ACAD',      // Activates Lite Config
      'THE_INFIRMARY': 'INF',     // Activates Ghost Config
      'THE_GAUNTLET': 'GNT',      // Activates Prime Config
      'PRIME': 'PRM'              // Direct Prime Config (Tier 4)
    };

    const tierCode = tierMap[tier] || 'T0';
    const pathCode = pathMap[path] || 'ACAD';
    const operatorId = profile_id || Math.random().toString(36).substring(2, 6).toUpperCase();
    const hash = Math.random().toString(36).substring(2, 6).toUpperCase();

    const uplink_key = `${tierCode}-${pathCode}-${operatorId}-${hash}`;

    // Determine activation type based on path
    const activation_type = path === 'THE_ACADEMY' ? 'BRAVO_KEY_ISSUED' :
                           path === 'THE_INFIRMARY' ? 'GHOST_ACTIVATED' :
                           path === 'THE_GAUNTLET' ? 'GAUNTLET_UNLOCKED' :
                           'PRIME_ACTIVATED';

    // Determine terminal access (Gauntlet gets Prime, Infirmary gets Ghost)
    const terminal_access = path === 'THE_ACADEMY' ? ['LITE'] :
                           path === 'THE_INFIRMARY' ? ['GHOST'] :
                           (path === 'THE_GAUNTLET' || path === 'PRIME') ? ['PRIME'] :
                           ['LITE'];

    // Create NexusActivation
    const activation = await base44.asServiceRole.entities.NexusActivation.create({
      operator_email,
      uplink_key,
      activation_type,
      granted_by: 'SYSTEM',
      prerequisite_met: revoke_previous ? 'Tier transition' : 'Subscription activated',
      activation_timestamp: new Date().toISOString(),
      terminal_access_granted: terminal_access,
      instrument_authorization: ['ES', 'MES'],
      initial_load_cap: tier === 'TIER_1_CADET' ? 0.5 : tier === 'TIER_2_REHAB' ? 0.5 : 1.0,
      webhook_configured: false,
      status: 'ACTIVE',
      nexus_mode: pathCode
    });

    // Update profile with uplink key
    if (profile_id) {
      await base44.asServiceRole.entities.Profile.update(profile_id, {
        uplink_key
      });
    }

    return Response.json({
      uplink_key,
      activation_id: activation.id,
      terminal_access,
      nexus_mode: pathCode,
      tier_code: tierCode,
      revoked_previous: revoke_previous || false,
      webhook_endpoint: `https://api.base44.com/triarc/nexus/ingest?uplink_key=${uplink_key}`
    });

  } catch (error) {
    console.error('Uplink key generation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});