import { createBase44, getMemberByEmail, patchMember, stripeClient, tierFromPriceId, toBillingStatus, entitlementsFromTier, nowIso, computeEntitlementState, nextGraceUntilIso } from './_billingShared.ts';

// Pulls Stripe subscription truth and writes it into the identity record.
// Intended for: login sync, manual repair, webhook outage recovery.

Deno.serve(async (req) => {
  try {
    const base44 = createBase44(req);
    const user = await base44.auth.me();
    if (!user?.email) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const stripe = stripeClient();

    const { Ent, rec } = await getMemberByEmail(base44, user.email);
    if (!rec?.id) return Response.json({ error: 'Member record not found' }, { status: 404 });

    const customerId = rec?.stripe_customer_id || rec?.stripeCustomerId || null;
    const subId = rec?.stripe_subscription_id || rec?.stripeSubscriptionId || null;

    let sub: any = null;

    if (subId) {
      sub = await stripe.subscriptions.retrieve(subId).catch(() => null);
    }

    if (!sub && customerId) {
      const list = await stripe.subscriptions.list({ customer: customerId, status: 'all', limit: 5 }).catch(() => null);
      const best = list?.data?.find((s: any) => s.status === 'active' || s.status === 'trialing') || list?.data?.[0] || null;
      sub = best;
    }

    const billingStatus = toBillingStatus(sub);
    const prevStatus = (rec?.subscription_status || rec?.billing_status || 'NONE').toString().toUpperCase();
    const prevGrace = rec?.grace_until || null;

    let grace_until: string | null = null;
    if (billingStatus === 'GRACE') {
      const prevMs = (() => { try { return prevGrace ? new Date(String(prevGrace)).getTime() : 0; } catch { return 0; } })();
      const stillValid = prevMs && prevMs > Date.now();
      grace_until = (prevStatus !== 'GRACE' || !stillValid) ? nextGraceUntilIso() : String(prevGrace);
    } else {
      grace_until = null;
    }

    const entState = computeEntitlementState(billingStatus, grace_until);


    // Tier inference from subscription price
    const priceId = sub?.items?.data?.[0]?.price?.id;
    const tier = (sub?.metadata?.triarc_tier || (priceId ? tierFromPriceId(priceId) : rec?.tier || 'UNDECLARED')).toString().toUpperCase();

    const ent = entitlementsFromTier(tier);

    const patch: Record<string, unknown> = {
      subscription_status: billingStatus,
      billing_status: billingStatus,
      tier,
      entitlement_playbooks: ent.playbooks,
      entitlement_suite: ent.suite,
      grace_until: grace_until,
      content_entitled: entState.contentEntitled,
      execution_entitled: entState.executionEntitled,
      in_grace: entState.inGrace,
      billing_authority_updated_at: nowIso(),
    };

    if (customerId) patch.stripe_customer_id = customerId;
    if (sub?.id) patch.stripe_subscription_id = sub.id;

    await patchMember(Ent, rec.id, patch);

    return Response.json({ ok: true, tier, billing_status: billingStatus });
  } catch (error) {
    console.error('syncStripeProfile error:', error);
    return Response.json({ error: (error as Error).message }, { status: 500 });
  }
});
