import { base44 } from '@base44/sdk';

/**
 * TriArc Nexus — Telemetry Ingest (Control Room)
 *
 * Expected envelope (from TradingView alert):
 * {
 *   "event_type": "STATE_SNAPSHOT" | "OPPORTUNITY_CREATED" | "OPPORTUNITY_UPDATED" | "OPPORTUNITY_CLEARED",
 *   "uplink_key": "...",
 *   "payload": { ... }
 * }
 */

type AnyObj = Record<string, any>;

const pickEntity = (names: string[]) => {
  for (const n of names) {
    const ent = (base44 as any).entities?.[n];
    if (ent) return ent;
  }
  return null;
};

const RawEventEntNames = ['NexusRawEvent', 'NexusTelemetryEvent', 'NexusEvent'];
const LiveStateEntNames = ['NexusStateLive', 'NexusSnapshotLive', 'NexusState'];
const LedgerEntNames = ['OpportunityLedger', 'NexusOpportunityLedger', 'OpportunityEvent'];
const ComplianceEventEntNames = ['ComplianceEvent', 'NexusComplianceEvent'];
const RemediationCaseEntNames = ['RemediationCase', 'NexusRemediationCase'];
const ComplianceProfileEntNames = ['ComplianceProfile', 'OperatorComplianceProfile'];
const ActivationEntNames = ['NexusActivation'];

const nowIso = () => new Date().toISOString();

const safe = async (fn: () => Promise<any>) => {
  try {
    return await fn();
  } catch {
    return null;
  }
};

type Violation = {
  violation_type: string;
  severity: 'CRITICAL' | 'MAJOR' | 'MINOR';
  notes?: string;
  remediation?: {
    title: string;
    description: string;
    severity: 'CRITICAL' | 'MAJOR' | 'MINOR';
    deadline_days?: number;
  };
};

const evalViolations = (eventType: string, live: AnyObj | null, oppId: string | null): Violation[] => {
  const v: Violation[] = [];
  if (!live) return v;

  const isPermitted = !!live.is_permitted;
  const globalVoid = !!live.global_void || Number(live.sentinel_state ?? 0) === 2;
  const probeOnly = !!live.probe_only || Number(live.sentinel_state ?? 0) === 1;
  const matrixHealthy = live.matrix_healthy === null || live.matrix_healthy === undefined ? true : !!live.matrix_healthy;
  const load = Number(live.risk_multiplier ?? 1);
  const gov = String(live.gov_state ?? '').toUpperCase();

  const isTradeEvent = eventType === 'OPPORTUNITY_CREATED' || eventType === 'OPPORTUNITY_UPDATED';

  // 1) Permission gate breach: opportunity created while not permitted
  if (eventType === 'OPPORTUNITY_CREATED' && !isPermitted) {
    v.push({
      violation_type: 'PERMISSION_BREACH',
      severity: 'CRITICAL',
      notes: `Opportunity created while permission was RESTRICTED (${gov || 'UNKNOWN'}).`,
      remediation: {
        title: 'Permission breach — stand down and re-audit',
        description: 'Operator triggered opportunity creation while execution permission was restricted. Require stand-down, key review, and re-brief on Terminal permission doctrine.',
        severity: 'CRITICAL',
        deadline_days: 3
      }
    });
  }

  // 2) Sentinel stand-down breach
  if (eventType === 'OPPORTUNITY_CREATED' && globalVoid) {
    v.push({
      violation_type: 'SENTINEL_STAND_DOWN_BREACH',
      severity: 'CRITICAL',
      notes: 'Opportunity created during Sentinel LOCK (global void).',
      remediation: {
        title: 'Sentinel breach — enforce lock discipline',
        description: 'Opportunity created during a Sentinel LOCK window. Require event protocol re-certification and enforce hard locks for Tier-1 windows.',
        severity: 'CRITICAL',
        deadline_days: 7
      }
    });
  }

  // 3) Probe-only breach: load above probe cap
  if (isTradeEvent && probeOnly && load > 0.5) {
    v.push({
      violation_type: 'PROBE_PROTOCOL_BREACH',
      severity: 'MAJOR',
      notes: `Probe-only state active but load was ${load}x (cap 0.5x).`,
      remediation: {
        title: 'Probe protocol breach — reduce load',
        description: 'Probe-only state requires reduced load. Enforce Servo cap compliance and retrain probe posture execution.',
        severity: 'MAJOR',
        deadline_days: 7
      }
    });
  }

  // 4) Matrix disregard: fractured matrix with elevated load
  if (isTradeEvent && !matrixHealthy && load > 1.0) {
    v.push({
      violation_type: 'MATRIX_DISREGARD',
      severity: 'MAJOR',
      notes: `Matrix fractured but operator load was ${load}x.`,
      remediation: {
        title: 'Matrix disregard — clamp load to 1.0x',
        description: 'When the Trinity Matrix is fractured, load must be clamped. Enforce Servo cap and perform correlation briefing.',
        severity: 'MAJOR',
        deadline_days: 14
      }
    });
  }

  // 5) Repeated opportunity churn (minor): rapid create/clear patterns are destabilizing
  // (we do not compute churn here; this placeholder allows future expansion)
  if (eventType === 'OPPORTUNITY_CLEARED' && oppId) {
    // no-op
  }

  return v;
};

export default async function nexusIngest(request: any) {
  try {
    const body = (request?.body ?? {}) as AnyObj;
    const event_type = String(body.event_type ?? '').trim();
    const uplink_key = String(body.uplink_key ?? '').trim();
    const payload = (body.payload ?? null) as AnyObj | null;

    if (!event_type || !uplink_key || !payload) {
      return {
        status: 400,
        body: { ok: false, error: 'Missing required fields: event_type, uplink_key, payload' },
      };
    }

    // Extract snapshot subtrees if present
    const meta = (payload.meta ?? {}) as AnyObj;
    const gov = (payload.governance ?? {}) as AnyObj;
    const servo = (payload.servo ?? {}) as AnyObj;
    const opp = (payload.opportunity ?? {}) as AnyObj;

    const symbol = meta.symbol ?? null;
    const symbol_id = meta.symbol_id ?? null;
    const tf = meta.tf ?? null;
    const tf_sec = meta.tf_sec ?? null;
    const event_time_ms = meta.event_time_ms ?? null;
    const is_exec_tf = meta.is_exec_tf ?? null;

    // ------------------------------------------------------------
    // 1) Always persist raw event (best-effort)
    // ------------------------------------------------------------
    const RawEvents = pickEntity(RawEventEntNames);
    if (RawEvents) {
      await RawEvents.create({
        event_type,
        uplink_key,
        event_time_ms,
        received_at: nowIso(),
        symbol,
        symbol_id,
        tf,
        tf_sec,
        is_exec_tf,
        payload_json: JSON.stringify(payload),
      });
    }

    // ------------------------------------------------------------
    // 2) Maintain a "live" state row for fast UI reads (best-effort)
    // ------------------------------------------------------------
    if (event_type === 'STATE_SNAPSHOT') {
      const LiveState = pickEntity(LiveStateEntNames);
      if (LiveState) {
        const stateKey = [uplink_key, symbol_id || symbol || 'UNKNOWN', tf || 'NA'].join('::');

        const record = {
          state_key: stateKey,
          uplink_key,
          updated_at: nowIso(),

          symbol,
          symbol_id,
          tf,
          tf_sec,
          event_time_ms,

          // Governance
          gov_state: gov.gov_state ?? null,
          is_permitted: gov.is_permitted ?? null,
          denial_reason: gov.denial_reason ?? null,
          sentinel_state: gov.sentinel_state ?? null,
          global_void: gov.global_void ?? null,
          probe_only: gov.probe_only ?? null,
          wk_type: gov.wk_type ?? null,
          wk_confidence: gov.wk_confidence ?? null,
          matrix_healthy: gov.matrix_healthy ?? null,
          navigator_bias: gov.navigator_bias ?? null,

          // Load
          servo_decision: servo.servo_decision ?? null,
          servo_reason: servo.servo_reason ?? null,
          risk_multiplier: servo.risk_multiplier ?? null,
          env_cap: servo.env_cap ?? null,

          // Opportunity (redacted mechanics; only state)
          opportunity_id: opp.opportunity_id ?? null,
          opp_active: opp.active ?? null,
          opp_side: opp.side ?? null,
          opp_name: opp.name ?? null,
          opp_score: opp.score ?? null,
          opp_entry: opp.entry ?? null,
          opp_stop: opp.stop ?? null,
          opp_tp1: opp.tp1 ?? null,
          opp_tp2: opp.tp2 ?? null,
          opp_tp3: opp.tp3 ?? null,
          opp_rotation_mode: opp.rotation_mode ?? null,
          opp_hammer: opp.hammer ?? null,
          opp_matrix_ok: opp.matrix_ok ?? null,

          snapshot_json: JSON.stringify(payload),
        };

        // Upsert by state_key if possible.
        const existing = await LiveState.findFirst?.({ filter: { state_key: stateKey } });
        if (existing?.id) {
          await LiveState.update(existing.id, record);
        } else {
          await LiveState.create(record);
        }
      }
    }

    // ------------------------------------------------------------
    // 3) Append opportunity ledger events (best-effort)
    // ------------------------------------------------------------
    if (
      event_type === 'OPPORTUNITY_CREATED' ||
      event_type === 'OPPORTUNITY_UPDATED' ||
      event_type === 'OPPORTUNITY_CLEARED'
    ) {
      const Ledger = pickEntity(LedgerEntNames);
      if (Ledger) {
        await Ledger.create({
          uplink_key,
          event_type,
          received_at: nowIso(),
          symbol,
          symbol_id,
          tf,
          tf_sec,
          event_time_ms,
          opportunity_id: payload.opportunity_id ?? opp.opportunity_id ?? null,
          payload_json: JSON.stringify(payload),
        });
      }

      // ------------------------------------------------------------
      // 4) Compliance evaluation (best-effort)
      // ------------------------------------------------------------
      const LiveState = pickEntity(LiveStateEntNames);
      const ComplianceEvent = pickEntity(ComplianceEventEntNames);
      const RemediationCase = pickEntity(RemediationCaseEntNames);
      const ComplianceProfile = pickEntity(ComplianceProfileEntNames);
      const NexusActivation = pickEntity(ActivationEntNames);

      // Pull last known live-state snapshot for this uplink/symbol to judge permission.
      let live: AnyObj | null = null;
      if (LiveState) {
        live =
          (await safe(async () =>
            LiveState.findFirst?.({
              filter: { uplink_key, ...(symbol_id ? { symbol_id } : symbol ? { symbol } : {}) },
              sort: '-updated_at'
            })
          )) ?? null;

        if (!live) {
          const rows = await safe(async () =>
            LiveState.filter?.({
              uplink_key,
              ...(symbol_id ? { symbol_id } : symbol ? { symbol } : {})
            })
          );
          if (Array.isArray(rows) && rows.length) live = rows[0];
        }
      }

      const oppId = String((payload as AnyObj)?.opportunity_id ?? (opp as AnyObj)?.opportunity_id ?? '').trim() || null;

      const violations = evalViolations(event_type, live, oppId);
      if (violations.length && ComplianceEvent) {
        const activation = NexusActivation
          ? await safe(async () =>
              NexusActivation.findFirst?.({ filter: { uplink_key }, sort: '-created_date' })
            )
          : null;
        const operator_email = activation?.operator_email ?? null;

        for (const vi of violations) {
          await safe(async () =>
            ComplianceEvent.create({
              timestamp_ms: event_time_ms ?? Date.now(),
              uplink_key,
              operator_email,
              symbol: symbol ?? null,
              symbol_id: symbol_id ?? null,
              tf: tf ?? null,
              opportunity_id: oppId,
              violation_type: vi.violation_type,
              severity: vi.severity,
              notes: vi.notes ?? null,
              source_event_type: event_type,
              source_payload_json: JSON.stringify(payload),
              created_at: nowIso()
            })
          );

          if (RemediationCase && vi.remediation) {
            // Avoid duplicating open cases of the same type for the same uplink.
            const existing = await safe(async () =>
              RemediationCase.findFirst?.({
                filter: { uplink_key, status: 'OPEN', case_type: vi.violation_type },
                sort: '-created_date'
              })
            );
            if (!existing) {
              const deadline = vi.remediation.deadline_days
                ? new Date(Date.now() + vi.remediation.deadline_days * 86400000).toISOString()
                : null;
              await safe(async () =>
                RemediationCase.create({
                  uplink_key,
                  operator_email,
                  status: 'OPEN',
                  case_type: vi.violation_type,
                  title: vi.remediation.title,
                  description: vi.remediation.description,
                  severity: vi.remediation.severity,
                  deadline,
                  created_at: nowIso()
                })
              );
            }
          }
        }

        // Update / create compliance profile score (very simple scoring model)
        if (ComplianceProfile && operator_email) {
          const last = await safe(async () =>
            ComplianceProfile.findFirst?.({ filter: { uplink_key, operator_email }, sort: '-updated_at' })
          );
          const base = Number(last?.score ?? last?.compliance_score ?? 100);
          const delta = violations.reduce((acc, x) => {
            if (x.severity === 'CRITICAL') return acc - 50;
            if (x.severity === 'MAJOR') return acc - 20;
            if (x.severity === 'MINOR') return acc - 5;
            return acc;
          }, 0);
          const score = Math.max(0, Math.min(100, base + delta));

          const record = {
            uplink_key,
            operator_email,
            score,
            last_violation_type: violations[0]?.violation_type ?? null,
            updated_at: nowIso()
          };

          if (last?.id) await safe(async () => ComplianceProfile.update(last.id, record));
          else await safe(async () => ComplianceProfile.create(record));
        }
      }
    }

    return { status: 200, body: { ok: true } };
  } catch (err: any) {
    return {
      status: 500,
      body: {
        ok: false,
        error: err?.message || 'Unknown error',
      },
    };
  }
}
