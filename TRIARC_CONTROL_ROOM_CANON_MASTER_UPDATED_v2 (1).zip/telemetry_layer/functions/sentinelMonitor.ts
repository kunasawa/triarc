import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Unauthorized: Admin access required' }, { status: 403 });
    }

    const { action, data } = await req.json();

    if (action === 'detect') {
      // Get all active sentinel events
      const allEvents = await base44.asServiceRole.entities.SentinelEvent.filter({ active: true });
      const now = new Date();
      
      // Check if any events are within their buffer windows
      let activeEventWindows = [];
      let maxSeverityState = 'green';
      let lockoutInstruments = [];
      let stateReason = 'Normal market conditions';
      
      for (const event of allEvents) {
        // In production, check against scheduled event times from market calendar API
        // For now, wardens must manually trigger detection or we use mock times
        const eventTime = data?.eventTime ? new Date(data.eventTime) : null;
        
        if (eventTime) {
          const bufferBefore = event.buffer_before_minutes || 30;
          const bufferAfter = event.buffer_after_minutes || 60;
          const aftershock = event.aftershock_minutes || 15;
          
          const windowStart = new Date(eventTime.getTime() - bufferBefore * 60000);
          const windowEnd = new Date(eventTime.getTime() + (bufferAfter + aftershock) * 60000);
          
          if (now >= windowStart && now <= windowEnd) {
            activeEventWindows.push(event.event_name);
            
            // Map event state to sentinel state
            const eventState = event.state_engine_code === 'STATE_N_BLACK' ? 'red' : 
                              event.state_engine_code === 'STATE_3_RED' ? 'red' : 'orange';
            
            if (eventState === 'red' && maxSeverityState !== 'red') {
              maxSeverityState = 'red';
            } else if (eventState === 'orange' && maxSeverityState === 'green') {
              maxSeverityState = 'orange';
            }
            
            // Accumulate lockout instruments
            lockoutInstruments = [...new Set([...lockoutInstruments, ...event.primary_instruments])];
            
            // Build state reason
            const timeToEvent = Math.floor((eventTime - now) / 60000);
            if (timeToEvent > 0) {
              stateReason = `${event.event_rank} EVENT: ${event.event_name} in ${timeToEvent}m | Buffer Active`;
            } else {
              const timeSinceEvent = Math.floor((now - eventTime) / 60000);
              stateReason = `${event.event_rank} EVENT: ${event.event_name} +${timeSinceEvent}m | Aftershock Protocol`;
            }
          }
        }
      }
      
      // Fallback to volatility detection if no events active
      const volatilityIndex = data?.volatilityIndex || Math.random() * 100;
      const volumeSpike = data?.volumeSpike || Math.random() > 0.85;
      
      let sentinelState = maxSeverityState;
      let alertWardens = false;
      
      if (sentinelState === 'green') {
        // Check market conditions
        if (volatilityIndex > 80) {
          sentinelState = 'red';
          stateReason = `Critical volatility: ${volatilityIndex.toFixed(1)}% | No Scheduled Events`;
          lockoutInstruments = ['ES', 'MES', 'NQ', 'MNQ', 'GC', 'MGC', 'CL', 'MCL'];
          alertWardens = true;
        } else if (volatilityIndex > 60 || volumeSpike) {
          sentinelState = 'orange';
          stateReason = volumeSpike 
            ? `Volume spike detected: ${volatilityIndex.toFixed(1)}% volatility`
            : `Elevated volatility: ${volatilityIndex.toFixed(1)}%`;
          alertWardens = true;
        }
      } else {
        alertWardens = true;
      }

      // Calculate expiration based on event rank or condition
      const expiresAt = new Date();
      if (activeEventWindows.length > 0) {
        // Use longest buffer from active events
        const maxBuffer = Math.max(...allEvents
          .filter(e => activeEventWindows.includes(e.event_name))
          .map(e => (e.buffer_after_minutes || 60) + (e.aftershock_minutes || 15))
        );
        expiresAt.setMinutes(expiresAt.getMinutes() + maxBuffer);
      } else {
        expiresAt.setMinutes(expiresAt.getMinutes() + (sentinelState === 'red' ? 60 : 30));
      }

      // Get current state
      const existingStates = await base44.asServiceRole.entities.SentinelState.list();
      
      if (existingStates.length > 0) {
        // Update existing
        await base44.asServiceRole.entities.SentinelState.update(existingStates[0].id, {
          current_state: sentinelState,
          state_reason: stateReason,
          active_events: activeEventWindows,
          volatility_index: volatilityIndex,
          volume_spike: volumeSpike,
          lockout_instruments: lockoutInstruments,
          alert_wardens: alertWardens,
          expires_at: expiresAt.toISOString()
        });
      } else {
        // Create new
        await base44.asServiceRole.entities.SentinelState.create({
          current_state: sentinelState,
          state_reason: stateReason,
          active_events: activeEventWindows,
          volatility_index: volatilityIndex,
          volume_spike: volumeSpike,
          lockout_instruments: lockoutInstruments,
          alert_wardens: alertWardens,
          expires_at: expiresAt.toISOString()
        });
      }

      // Create violation alerts for wardens if needed
      if (alertWardens) {
        const operators = await base44.asServiceRole.entities.Profile.list();
        
        for (const operator of operators) {
          await base44.asServiceRole.entities.ViolationAlert.create({
            operator_email: operator.email,
            violation_type: 'inventory_lock',
            severity: sentinelState === 'red' ? 'red' : 'orange',
            status: 'pending',
            auto_message: `SENTINEL ${sentinelState.toUpperCase()}: ${stateReason}. Terminal access restricted.`,
            metadata: {
              sentinel_state: sentinelState,
              volatility_index: volatilityIndex,
              lockout_instruments: lockoutInstruments,
              timestamp: new Date().toISOString()
            }
          });
        }
      }

      return Response.json({
        success: true,
        sentinel_state: sentinelState,
        state_reason: stateReason,
        lockout_instruments: lockoutInstruments,
        expires_at: expiresAt.toISOString()
      });
    }

    if (action === 'get_current') {
      const states = await base44.asServiceRole.entities.SentinelState.list('-updated_date', 1);
      
      if (states.length === 0) {
        return Response.json({
          current_state: 'green',
          state_reason: 'No sentinel state recorded',
          active_events: [],
          lockout_instruments: []
        });
      }

      const currentState = states[0];

      // Auto-expire to green if past expiration
      if (currentState.expires_at && new Date(currentState.expires_at) < new Date()) {
        await base44.asServiceRole.entities.SentinelState.update(currentState.id, {
          current_state: 'green',
          state_reason: 'Auto-expired to green',
          active_events: [],
          lockout_instruments: [],
          alert_wardens: false
        });

        return Response.json({
          current_state: 'green',
          state_reason: 'Auto-expired to green',
          active_events: [],
          lockout_instruments: []
        });
      }

      return Response.json(currentState);
    }

    return Response.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});