import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { operator_email, new_tier, new_path, trigger_event } = await req.json();

    // Validate operator (admin or self)
    if (operator_email !== user.email && user.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    // Get operator profile
    const [profile] = await base44.asServiceRole.entities.Profile.filter({
      created_by: operator_email
    });

    if (!profile) {
      return Response.json({ error: 'Profile not found' }, { status: 404 });
    }

    // Log tier transition for audit trail
    await base44.asServiceRole.entities.AuditTrail.create({
      operator_id: operator_email,
      action_type: 'UPLINK_KEY_ROTATION',
      entity_type: 'NexusActivation',
      performed_by: user.email,
      performed_at: new Date().toISOString(),
      details: {
        previous_tier: profile.tier,
        new_tier,
        previous_path: profile.assigned_path,
        new_path,
        trigger_event
      }
    });

    // Generate new uplink key
    const response = await base44.functions.invoke('generateUplinkKey', {
      operator_email,
      path: new_path,
      tier: new_tier,
      profile_id: profile.id,
      revoke_previous: true
    });

    // Update profile tier and path
    await base44.asServiceRole.entities.Profile.update(profile.id, {
      tier: new_tier,
      assigned_path: new_path
    });

    return Response.json({
      status: 'rotated',
      operator_email,
      previous_tier: profile.tier,
      new_tier,
      previous_path: profile.assigned_path,
      new_path,
      uplink_key: response.data.uplink_key,
      nexus_mode: response.data.nexus_mode,
      terminal_access: response.data.terminal_access,
      message: 'Uplink key rotated - operator must reconfigure TradingView webhook'
    });

  } catch (error) {
    console.error('Key rotation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});