import Stripe from 'npm:stripe@16.12.0';
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import { getMemberByEmail, patchMember, resolveIdentityEntity, entitlementsFromTier, toBillingStatus, tierFromPriceId, nowIso, PRICE_IDS, computeEntitlementState, nextGraceUntilIso } from './_billingShared.ts';

// Stripe webhook handler.
// Canon: subscription status is the single source of billing authority.

const stripe = (() => {
  const key = Deno.env.get('STRIPE_SECRET_KEY');
  if (!key) throw new Error('Missing STRIPE_SECRET_KEY');
  return new Stripe(key, { apiVersion: '2024-06-20' });
})();

const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

async function applyAuthority(base44: any, operatorEmail: string, authority: Record<string, unknown>) {
  const Ent = resolveIdentityEntity(base44);
  if (!Ent?.filter || !Ent?.update) throw new Error('Identity entity not available');
  const rows = await Ent.filter({ email: operatorEmail }, '-created_date', 1).catch(() => []);
  const rec = rows?.[0];
  if (!rec?.id) throw new Error('Member not found for authority update');
  await patchMember(Ent, rec.id, authority);
  return { id: rec.id, rec };
}


Deno.serve(async (req) => {
  try {
    if (!webhookSecret) {
      return Response.json({ error: 'Missing STRIPE_WEBHOOK_SECRET' }, { status: 500 });
    }

    const sig = req.headers.get('stripe-signature');
    if (!sig) return Response.json({ error: 'Missing stripe-signature' }, { status: 400 });

    // Raw body required for signature verification
    const rawBody = await req.text();
    const event = stripe.webhooks.constructEvent(rawBody, sig, webhookSecret);

    const base44 = createClientFromRequest(req);
    // Use service role for webhook writes
    const svc = base44.asServiceRole;

    const type = event.type;
    const obj: any = (event.data as any)?.object;

    // Resolve operator identity
    let operatorEmail: string | null = null;
    let tier: string | null = null;
    let sub: Stripe.Subscription | null = null;

    if (type === 'checkout.session.completed') {
      operatorEmail = obj?.customer_details?.email || obj?.metadata?.operator_email || null;
      const priceId = obj?.metadata?.billing_intent_price_id || obj?.metadata?.price_id || null;
      tier = obj?.metadata?.triarc_tier || (priceId ? tierFromPriceId(priceId) : null);
      if (obj?.subscription) {
        sub = await stripe.subscriptions.retrieve(obj.subscription);
      }
    }

    if (type.startsWith('customer.subscription.')) {
      sub = obj as Stripe.Subscription;
      operatorEmail = (sub?.metadata as any)?.operator_email || null;
      // Attempt fallback: look up customer email if not in metadata
      if (!operatorEmail && sub?.customer) {
        const cust = await stripe.customers.retrieve(sub.customer as string);
        if (cust && !('deleted' in cust)) operatorEmail = cust.email ?? null;
      }
      // Price → tier (first item)
      const priceId = (sub?.items?.data?.[0] as any)?.price?.id;
      tier = (sub?.metadata as any)?.triarc_tier || (priceId ? tierFromPriceId(priceId) : null);
    }
    if (type.startsWith('invoice.')) {
      // invoice.payment_failed, invoice.paid, etc.
      const invoice: any = obj;
      if (invoice?.subscription) {
        sub = await stripe.subscriptions.retrieve(invoice.subscription as string).catch(() => null);
      }
      if (!operatorEmail) {
        operatorEmail = invoice?.customer_email || null;
      }
      if (!operatorEmail && invoice?.customer) {
        const cust = await stripe.customers.retrieve(invoice.customer as string);
        if (cust && !('deleted' in cust)) operatorEmail = cust.email ?? null;
      }
      const priceId = (sub?.items?.data?.[0] as any)?.price?.id;
      tier = (sub?.metadata as any)?.triarc_tier || (priceId ? tierFromPriceId(priceId) : null);
    }


    // If we still can't resolve email, ignore (we can't safely map it)
    if (!operatorEmail) {
      return Response.json({ ok: true, ignored: true });
    }

    const billingStatus = toBillingStatus(sub);

    // Grace window policy:
    // Grace timer is started when we ENTER GRACE, and preserved while remaining in GRACE.
    // Execution locks immediately on GRACE; content may remain accessible until grace_until.

    // Fetch current record to preserve grace_until / detect transitions
    const Ent = resolveIdentityEntity(svc);
    const rows = await Ent.filter({ email: operatorEmail }, '-created_date', 1).catch(() => []);
    const current = rows?.[0] ?? null;
    const prevStatus = (current?.subscription_status || current?.billing_status || 'NONE').toString().toUpperCase();
    const prevGrace = current?.grace_until || null;

    let grace_until: string | null = null;
    if (billingStatus === 'GRACE') {
      // Start grace only if transitioning into GRACE or missing/expired grace timestamp
      const prevMs = (() => { try { return prevGrace ? new Date(String(prevGrace)).getTime() : 0; } catch { return 0; } })();
      const stillValid = prevMs && prevMs > Date.now();
      grace_until = (prevStatus !== 'GRACE' || !stillValid) ? nextGraceUntilIso() : String(prevGrace);
    } else {
      grace_until = null;
    }

    const entState = computeEntitlementState(billingStatus, grace_until);

    const effectiveTier = (tier || 'UNDECLARED').toUpperCase();
    const ent = entitlementsFromTier(effectiveTier);

    const authorityPatch: Record<string, unknown> = {
      subscription_status: billingStatus,
      billing_status: billingStatus,
      tier: effectiveTier,
      entitlement_playbooks: ent.playbooks,
      entitlement_suite: ent.suite,
      grace_until: grace_until,
      content_entitled: entState.contentEntitled,
      execution_entitled: entState.executionEntitled,
      in_grace: entState.inGrace,
      billing_authority_updated_at: nowIso(),
    };

    if (sub?.id) authorityPatch.stripe_subscription_id = sub.id;
    if (sub?.customer) authorityPatch.stripe_customer_id = sub.customer;

    // Mark revoked/ended
    if (type === 'customer.subscription.deleted' || billingStatus === 'CANCELED') {
      authorityPatch.entitlement_playbooks = [];
      authorityPatch.entitlement_suite = ['WEEKLY_CLASSIFIER'];
    }

    // Apply
    const applied = await applyAuthority(svc, operatorEmail, authorityPatch);

    // Optional incident logging
    try {
      const ents = (svc as any)?.entities ?? {};
      const Incident = ents.GovernanceIncident || ents.Incident || null;
      if (Incident?.create) {
        const isFailure = (type === 'invoice.payment_failed') || (billingStatus === 'SUSPENDED');
        const isCancel  = (type === 'customer.subscription.deleted') || (billingStatus === 'CANCELED');
        const enteredGrace = (billingStatus === 'GRACE' && prevStatus !== 'GRACE');
        if (isFailure || isCancel || enteredGrace) {
          await Incident.create({
            operator_email: operatorEmail,
            member_id: applied?.id,
            incident_type: isCancel ? 'BILLING_CANCELED' : enteredGrace ? 'BILLING_GRACE' : 'BILLING_FAILURE',
            severity: isCancel ? 'HIGH' : enteredGrace ? 'MEDIUM' : 'HIGH',
            status: 'OPEN',
            note: `Stripe event: ${type}`,
            created_at: nowIso(),
          });
        }
      }
    } catch (_) {}


    return Response.json({ ok: true });
  } catch (error) {
    console.error('stripeWebhook error:', error);
    return Response.json({ error: (error as Error).message }, { status: 500 });
  }
});
