import { createBase44, getMemberByEmail, patchMember, stripeClient, tierFromPriceId, PRICE_IDS, nowIso } from './_billingShared.ts';

// Creates a Stripe Checkout session for subscription purchase.
// Canon: checkout establishes subscription authority; entitlements flow from webhook + sync.

Deno.serve(async (req) => {
  try {
    const base44 = createBase44(req);
    const user = await base44.auth.me();
    if (!user?.email) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { price_id, return_path } = await req.json().catch(() => ({}));
    if (!price_id) return Response.json({ error: 'Missing price_id' }, { status: 400 });

    // Guard: only allow known prices (prevents arbitrary charge surfaces)
    const allowed = new Set(Object.values(PRICE_IDS));
    if (!allowed.has(price_id)) {
      return Response.json({ error: 'Invalid price_id' }, { status: 400 });
    }

    const stripe = stripeClient();
    const { Ent, rec } = await getMemberByEmail(base44, user.email);
    if (!rec?.id) return Response.json({ error: 'Member record not found' }, { status: 404 });

    // Ensure Stripe customer exists
    let customerId = rec?.stripe_customer_id || rec?.stripeCustomerId || null;
    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        name: user.name ?? undefined,
        metadata: {
          operator_email: user.email,
          base44_member_id: rec.id,
        },
      });
      customerId = customer.id;
      await patchMember(Ent, rec.id, {
        stripe_customer_id: customerId,
        billing_authority_updated_at: nowIso(),
      });
    }

    const appUrl = Deno.env.get('APP_BASE_URL') || Deno.env.get('APP_URL') || (req.headers.get('origin') ?? '');
    if (!appUrl) return Response.json({ error: 'Missing APP_BASE_URL/APP_URL' }, { status: 500 });
    const successUrl = `${appUrl}${return_path || '/portal'}?checkout=success`;
    const cancelUrl = `${appUrl}${return_path || '/portal/billing'}?checkout=cancel`;

    const tier = tierFromPriceId(price_id);

    // Gauntlet is approval-gated (governance approval required)
    const isGauntlet = price_id === PRICE_IDS.GAUNTLET;
    const role = (rec?.role || rec?.rbac_role || rec?.member_role || '').toString().toLowerCase();
    const isAdminBypass = ['admin','architect','controller','warden'].includes(role);
    const gauntletApproved = Boolean(rec?.gauntlet_approved || rec?.gauntletApproved || rec?.gauntlet_access_approved || (rec?.gauntlet_status || '').toString().toUpperCase() === 'APPROVED');

    if (isGauntlet && !isAdminBypass && !gauntletApproved) {
      return Response.json({ error: 'Gauntlet requires governance approval' }, { status: 403 });
    }


    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      customer: customerId,
      line_items: [{ price: price_id, quantity: 1 }],
      success_url: successUrl,
      cancel_url: cancelUrl,
      subscription_data: {
        metadata: {
          operator_email: user.email,
          triarc_tier: tier,
        },
      },
      metadata: {
        operator_email: user.email,
        triarc_tier: tier,
        base44_member_id: rec.id,
      },
    });

    // Persist last intended tier (useful for support)
    await patchMember(Ent, rec.id, {
      billing_intent_tier: tier,
      billing_intent_price_id: price_id,
      billing_intent_at: nowIso(),
    });

    return Response.json({ url: session.url, session_id: session.id });
  } catch (error) {
    console.error('createCheckoutSession error:', error);
    return Response.json({ error: (error as Error).message }, { status: 500 });
  }
});
